/***********************************************************************
Run the Pike-Hill generator used for part of random.c:Rand() to
determine its period.

	M. C. Pike and I. D. Hill
	ACM Algorithm 266: Pseudo-Random Numbers
	Comm. ACM 8(10) 605--606, October (1965)

	M. C. Pike and I. D. Hill
	Remark on {Algorithm 266 [G5]}: Pseudo-Random Numbers
	Comm. ACM 9(9) 687--687, September (1966).

[02-Aug-2004]
***********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

static unsigned long Rand_Seed = 100001UL;

double
log2(double x)
{
    return (log(x) / log(2.0));
}

double
rand_(void)
{
    double d;

    Rand_Seed = Rand_Seed * 3125UL;
    Rand_Seed = Rand_Seed - (Rand_Seed / 67108864UL) * 67108864UL;
    d = (double)Rand_Seed / (double)67108864UL;
    return (d);
}


int
main(int argc, char* argv[])
{
    unsigned long initial_seed = Rand_Seed;
    unsigned long period;
    unsigned long min_Rand_Seed;
    unsigned long max_Rand_Seed;
    unsigned long i_min_Rand_Seed;
    unsigned long i_max_Rand_Seed;

    (void)printf("Test of Pike-Hill generator\n");
    (void)printf("Initial seed = %lu\n", initial_seed);

    period = 0;
    max_Rand_Seed = Rand_Seed;
    min_Rand_Seed = Rand_Seed;
    do
    {
	period++;
	rand_();
	if (Rand_Seed > max_Rand_Seed)
	{
	    i_max_Rand_Seed = period;
	    max_Rand_Seed = Rand_Seed;
	}
	if (Rand_Seed < min_Rand_Seed)
	{
	    i_min_Rand_Seed = period;
	    min_Rand_Seed = Rand_Seed;
	}
    } while (initial_seed != Rand_Seed);

    (void)printf("Period       = %lu\n", period);
    (void)printf("log2(Period) = %.4g\n", log2(period));
    (void)printf("Minimum seed = %lu at step %lu\n", min_Rand_Seed, i_min_Rand_Seed);
    (void)printf("Maximum seed = %lu at step %lu\n", max_Rand_Seed, i_max_Rand_Seed);

    return (EXIT_SUCCESS);
}
