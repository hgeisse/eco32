#! /bin/sh
### ====================================================================
### Run the ELEFUNT tests for multiple compilers and optimization
### levels, automatically selecting them according to the host
### operating system.
###
### Usage:
###     ./elefunt.sh
###
### [30-May-2002] -- Revise for Fortran 77, 90, 95, and HPF compilation.
### [27-May-2002] -- Original version for C and C++
### ====================================================================

machine=`uname -m`
os=`uname -s`
MAKE='make distclean all'
MAKE3='make distclean all3'

case $os in
	AIX*)
		osmajor=`uname -v`
		osminor=`uname -r`
		$MAKE  FC=g77 NAME=ibm-aix${osmajor}${osminor}-g77-O3            OPT=-O3
		$MAKE  FC=g77 NAME=ibm-aix${osmajor}${osminor}-g77-g             OPT=-g
		$MAKE3 FC=xlf NAME=ibm-aix${osmajor}${osminor}-xlf-O4            OPT=-O4
		$MAKE3 FC=xlf NAME=ibm-aix${osmajor}${osminor}-xlf-g             OPT=-g
		$MAKE3 FC=xlf90 NAME=ibm-aix${osmajor}${osminor}-xlf90-O4        OPT=-O4 XFFLAGS=-qfixed
		$MAKE3 FC=xlf90 NAME=ibm-aix${osmajor}${osminor}-xlf90-g         OPT=-g  XFFLAGS=-qfixed
		$MAKE3 FC=xlf95 NAME=ibm-aix${osmajor}${osminor}-xlf95-O3        OPT=-O3 XFFLAGS=-qfixed
		$MAKE3 FC=xlf95 NAME=ibm-aix${osmajor}${osminor}-xlf95-g         OPT=-g  XFFLAGS=-qfixed
		;;

	Darwin*)
		## Apple Darwin does not come with a Fortran compiler (gcc is
		## included, but not g77, and GNU distributions of gcc do not
		## build on this system).  At the author's site, f77 is a
		## locally-installed wrapper for the AT&T/Lucent Bell Labs f2c
		## translator.
		$MAKE FC=f77 NAME=apple-powerpc-darwin-f77-O4 OPT=-O4
		$MAKE FC=f77 NAME=apple-powerpc-darwin-f77-g  OPT=-g
		;;

	FreeBSD*)
		## On this system f77 is really GNU g77.
		$MAKE FC=f77 NAME=intel-ia32-freebsd-f77-O4     OPT=-O4
		$MAKE FC=f77 NAME=intel-ia32-freebsd-f77-g      OPT=-g
		;;

	HP-UX*)
		;;

	IRIX*)
		$MAKE3 FC=f77 NAME=sgi-irix-f77-O3      OPT=-O3
		$MAKE3 FC=f77 NAME=sgi-irix-f77-g       OPT=-g
		$MAKE3 FC=f90 NAME=sgi-irix-f90-O3      OPT=-O3
		$MAKE3 FC=f90 NAME=sgi-irix-f90-g       OPT=-g
		$MAKE3 FC=g77 NAME=sgi-irix-g77-O4      OPT=-O4
		$MAKE3 FC=g77 NAME=sgi-irix-g77-g       OPT=-g
		;;

	Linux*)
		case $machine in
			alpha)
				## /usr/bin/fort is Compaq Fortran V1.2.0-1882, available free
				## for academic noncommercial use: see
				## http://www.compaq.com/fortran/linux/download-120.html
				$MAKE FC=fort NAME=dec-alpha-gnu-linux-fort-O3  OPT=-O3 XCFLAGS=-fpe3
				$MAKE FC=fort NAME=dec-alpha-gnu-linux-fort-g   OPT=-g  XCFLAGS=-fpe3
				$MAKE FC=g77 NAME=dec-alpha-gnu-linux-g77-O3    OPT=-O3 XCFLAGS=-mieee
				$MAKE FC=g77 NAME=dec-alpha-gnu-linux-g77-g     OPT=-g  XCFLAGS=-mieee
				;;
			i486 | i586 | i686)
				$MAKE FC=g77 NAME=intel-ia32-gnu-linux-g77-O3           OPT=-O3
				$MAKE FC=g77 NAME=intel-ia32-gnu-linux-g77-g            OPT=-g
				## ifc is the Intel Fortran 90 compiler, available free
				## for academic noncommercial use: see
				## http://developer.intel.com/software/products/compilers/downloads/l_fc_p_6.0.140.htm
				$MAKE3 FC=ifc NAME=intel-ia32-gnu-linux-ifc-O3           OPT=-O3 XFFLAGS=-w
				$MAKE3 FC=ifc NAME=intel-ia32-gnu-linux-ifc-g            OPT=-g  XFFLAGS=-w
				## Temporarily suppress Lahey/Fujitsu lf95: it no longer
				## works after an O/S upgrade from Red Hat 6.2 to 7.2
				## because it uses a no-longer supported C library
				## $MAKE FC=lf95 NAME=intel-ia32-gnu-linux-lf95-O3      OPT=-O3
				## $MAKE FC=lf95 NAME=intel-ia32-gnu-linux-lf95-g       OPT=-g
				## NAG compiler family (these translate to C, then compile natively)
				$MAKE FC=nagf90 NAME=intel-ia32-gnu-linux-nagf90-O3     OPT=-O3 XFFLAGS=-fixed
				$MAKE FC=nagf90 NAME=intel-ia32-gnu-linux-nagf90-g      OPT=-g  XFFLAGS=-fixed
				$MAKE FC=nagf95 NAME=intel-ia32-gnu-linux-nagf95-O3     OPT=-O3 XFFLAGS=-fixed
				$MAKE FC=nagf95 NAME=intel-ia32-gnu-linux-nagf95-g      OPT=-g  XFFLAGS=-fixed
				## Portland Group compiler family
				$MAKE FC=pgf77 NAME=intel-ia32-gnu-linux-pgf77-O3       OPT=-O3
				$MAKE FC=pgf77 NAME=intel-ia32-gnu-linux-pgf77-g        OPT=-g
				$MAKE FC=pgf90 NAME=intel-ia32-gnu-linux-pgf90-O3       OPT=-O3
				$MAKE FC=pgf90 NAME=intel-ia32-gnu-linux-pgf90-g        OPT=-g
				$MAKE FC=pgfhpf NAME=intel-ia32-gnu-linux-pgfhpf-O3     OPT=-O3
				$MAKE FC=pgfhpf NAME=intel-ia32-gnu-linux-pgfhpf-g      OPT=-g
				;;
			ppc)
				$MAKE FC=g77 NAME=apple-powerpc-gnu-linux-g77-O3        OPT=-O3
				$MAKE FC=g77 NAME=apple-powerpc-gnu-linux-g77-g         OPT=-g
				;;
			sparc)
				$MAKE FC=g77 NAME=sun-sparc-gnu-linux-g77-O3            OPT=-O3
				$MAKE FC=g77 NAME=sun-sparc-gnu-linux-g77-g             OPT=-g
				;;
			*)
				echo "Unknown machine = $machine"
				exit 1
				;;
		esac
		;;

	OSF1*)
		osversion=`uname -r`
		$MAKE FC=f77 NAME=dec-alpha-osf-${osversion}-f77-O3     OPT=-O3 XCFLAGS=-fpe3
		$MAKE FC=f77 NAME=dec-alpha-osf-${osversion}-f77-g      OPT=-g  XCFLAGS=-fpe3
		$MAKE FC=f90 NAME=dec-alpha-osf-${osversion}-f90-O3     OPT=-O3 XCFLAGS=-fpe3
		$MAKE FC=f90 NAME=dec-alpha-osf-${osversion}-f90-g      OPT=-g  XCFLAGS=-fpe3
		$MAKE FC=f95 NAME=dec-alpha-osf-${osversion}-f95-O3     OPT=-O3 XCFLAGS=-fpe3
		$MAKE FC=f95 NAME=dec-alpha-osf-${osversion}-f95-g      OPT=-g  XCFLAGS=-fpe3
		$MAKE FC=g77 NAME=dec-alpha-osf-${osversion}-g77-O3     OPT=-O3 XCFLAGS=-mieee
		$MAKE FC=g77 NAME=dec-alpha-osf-${osversion}-g77-g      OPT=-g  XCFLAGS=-mieee
		;;

	Rhapsody*)
		## Apple Rhapsody does not come with a Fortran compiler (gcc is
		## included, but not g77, and GNU distributions of gcc do not
		## build on this system).  At the author's site, f77 is a
		## locally-installed wrapper for the AT&T/Lucent Bell Labs f2c
		## translator.
		$MAKE FC=f77 NAME=apple-powerpc-rhapsody-f77-O4 OPT=-O4
		$MAKE FC=f77 NAME=apple-powerpc-rhapsody-f77-g  OPT=-g
		;;

	SunOS*)
		## Solaris runs on Intel IA-32 (x86) as well, but I don't have
		## access to such a system.
		osversion=`uname -r`
		sunmath=`find /opt/SUNWspro/ -name sunmath.h | head -1`
		incdir=`dirname ${sunmath}`
		libdir=${incdir}/../../lib
		$MAKE3 FC=f77 NAME=sun-sparc-solaris-${osversion}-f77-O5 OPT=-xO5
		$MAKE3 FC=f77 NAME=sun-sparc-solaris-${osversion}-f77-g  OPT=-g
		$MAKE3 FC=f90 NAME=sun-sparc-solaris-${osversion}-f90-O5 OPT=-xO5 XFFLAGS='-ftrap=%none'
		$MAKE3 FC=f90 NAME=sun-sparc-solaris-${osversion}-f90-g  OPT=-g   XFFLAGS='-ftrap=%none'
		$MAKE3 FC=f95 NAME=sun-sparc-solaris-${osversion}-f95-O5 OPT=-O5  XFFLAGS='-ftrap=%none'
		$MAKE3 FC=f95 NAME=sun-sparc-solaris-${osversion}-f95-g  OPT=-g   XFFLAGS='-ftrap=%none'
		$MAKE  FC=g77 NAME=sun-sparc-solaris-${osversion}-g77-O5 OPT=-O5
		$MAKE  FC=g77 NAME=sun-sparc-solaris-${osversion}-g77-g  OPT=-g
		;;

	*)
		echo "Unknown O/S = $os"
		exit 1
		;;

esac
echo ""
echo "Output files:"
ls -l tall[dsq]p.lst*
echo ""
for f in tall[dsq]p.lst*
do
	echo ==================== $f
	awk -f elefunt.awk $f
done
