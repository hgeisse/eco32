#line 1 "talldp.f"
/* talldp.f -- translated by f2c (version 20020314).
   You must link the resulting object file with the libraries:
	-lf2c -lm   (in that order)
*/

#include "f2c.h"

#line 1 "talldp.f"
/* Table of constant values */

static integer c__1 = 1;

/* Main program */ int MAIN__(void)
{
    /* Initialized data */

    static integer iout = 6;

    /* Builtin functions */
    /* Subroutine */ int s_stop(char *, ftnlen);

    /* Local variables */
    extern /* Subroutine */ int tdlog_(integer *), tdtan_(integer *), tdsin_(
	    integer *), tdexp_(integer *), tdatan_(integer *), tsmach_(
	    integer *), tdasin_(integer *), tdtanh_(integer *), tdsinh_(
	    integer *), tpower_(integer *), tdsqrt_(integer *);

/*     (ELEFUNT Test) */
/*     Master program to run all of the FORTRAN ELEFUNT ELEmentary */
/*     FUNction Tests.  This version diverts error messages to the */
/*     listing file so that they are interspersed with the  normal */
/*     output, and requests  output of all  error messages. */

/*     The original  main  programs  have all  been  converted  to */
/*     subroutines.  All magic floating-point constants have  been */
/*     identified and  recomputed  to  55 figures  in  REDUCE  and */
/*     inserted in  place of  existing constants.   Comment  lines */
/*     beginning "C#" flag their occurrence. */
/*     (17-JAN-86) */
/*     DOUBLE PRECISION DFLMAX */


/*     CALL ERRSET (MSGLIM,I), where i = */
/*       0       integer overflow */
/*       1       integer divide check */
/*       4       floating overflow */
/*       5       floating divide check */
/*       6       floating underflow */
/*       8       library routine error */
/*       9       output field width too small */

/*     CALL ERRSET (MSGLIM,0) */
/*     CALL ERRSET (MSGLIM,1) */
/*     CALL ERRSET (MSGLIM,4) */
/*     CALL ERRSET (MSGLIM,5) */
/*     CALL ERRSET (MSGLIM,6) */
/*     CALL ERRSET (MSGLIM,8) */
/*     CALL ERRSET (MSGLIM,9) */

/*     OPEN (UNIT=IOUT,ACCESS='SEQUENTIAL',FORM='FORMATTED', */
/*    X     STATUS='UNKNOWN') */

/*     Divert error messages to unit 6 as well (TOPS-20 only). */

/*     CALL DIVERT (6) */

/*     CALL TRPFPE (999999,dflmax()) */

#line 46 "talldp.f"
    tsmach_(&iout);
#line 47 "talldp.f"
    tdlog_(&iout);
#line 48 "talldp.f"
    tdasin_(&iout);
#line 49 "talldp.f"
    tdatan_(&iout);
#line 50 "talldp.f"
    tdexp_(&iout);
#line 51 "talldp.f"
    tpower_(&iout);
#line 52 "talldp.f"
    tdsin_(&iout);
#line 53 "talldp.f"
    tdsinh_(&iout);
#line 54 "talldp.f"
    tdsqrt_(&iout);
#line 55 "talldp.f"
    tdtan_(&iout);
#line 56 "talldp.f"
    tdtanh_(&iout);
#line 57 "talldp.f"
    s_stop("", (ftnlen)0);
#line 58 "talldp.f"
    return 0;
} /* MAIN__ */

/* Subroutine */ int tdasin_(integer *iout)
{
    /* Format strings */
    static char fmt_1000[] = "(\0021TEST OF DASIN(X) VS TAYLOR SERIES \002//)"
	    ;
    static char fmt_1010[] = "(i7,\002 RANDOM ARGUMENTS WERE TESTED FROM THE"
	    " INTERVAL\002/6x,\002(\002,d15.4,\002,\002,d15.4,\002)\002//)";
    static char fmt_1011[] = "(\002 DASIN(X) WAS LARGER\002,i6,\002 TIMES"
	    ",\002/13x,\002 AGREED\002,i6,\002 TIMES, AND\002/9x,\002WAS SMAL"
	    "LER\002,i6,\002 TIMES.\002//)";
    static char fmt_1005[] = "(\0021TEST OF DACOS(X) VS TAYLOR SERIES \002//)"
	    ;
    static char fmt_1012[] = "(\002 DACOS(X) WAS LARGER\002,i6,\002 TIMES"
	    ",\002/12x,\002 AGREED\002,i6,\002 TIMES, AND\002/8x,\002WAS SMAL"
	    "LER\002,i6,\002 TIMES.\002//)";
    static char fmt_1020[] = "(\002 THERE ARE\002,i4,\002 BASE\002,i4,\002 S"
	    "IGNIFICANT DIGITS IN A FLOATING-POINT NUMBER\002//)";
    static char fmt_1021[] = "(\002 THE MAXIMUM RELATIVE ERROR OF\002,d15.4"
	    ",\002 = \002,i4,\002 **\002,f7.2/4x,\002OCCURRED FOR X =\002,d17"
	    ".6)";
    static char fmt_1022[] = "(\002 THE ESTIMATED LOSS OF BASE\002,i4,\002 S"
	    "IGNIFICANT DIGITS IS\002,f7.2//)";
    static char fmt_1023[] = "(\002 THE ROOT MEAN SQUARE RELATIVE ERROR WA"
	    "S\002,d15.4,\002 = \002,i4,\002 **\002,f7.2)";
    static char fmt_1025[] = "(\0021SPECIAL TESTS\002//)";
    static char fmt_1030[] = "(\002 THE IDENTITY  DASIN(-X) = -DASIN(X)  WIL"
	    "L BE TESTED.\002//8x,\002X\002,9x,\002F(X) + F(-X)\002/)";
    static char fmt_1060[] = "(d15.7,d25.17/)";
    static char fmt_1031[] = "(\002 THE IDENTITY DASIN(X) = X , X SMALL, WIL"
	    "L BE TESTED.\002//8x,\002X\002,9x,\002X - F(X)\002/)";
    static char fmt_1035[] = "(\002 TEST OF UNDERFLOW FOR VERY SMALL ARGUMEN"
	    "T.\002/)";
    static char fmt_1061[] = "(6x,\002 DASIN(\002,d13.6,\002) =\002,d13.6/)";
    static char fmt_1050[] = "(\0021TEST OF ERROR RETURNS\002//)";
    static char fmt_1052[] = "(\002 DASIN WILL BE CALLED WITH THE ARGUMEN"
	    "T\002,d15.4/\002 THIS SHOULD TRIGGER AN ERROR MESSAGE\002//)";
    static char fmt_1055[] = "(\002 DASIN RETURNED THE VALUE\002,d15.4///)";
    static char fmt_1100[] = "(\002 THIS CONCLUDES THE TESTS\002)";

    /* System generated locals */
    integer i__1, i__2;
    doublereal d__1;

    /* Builtin functions */
    double log(doublereal), pow_di(doublereal *, integer *), d_lg10(
	    doublereal *), sqrt(doublereal), asin(doublereal), acos(
	    doublereal);
    integer s_wsfe(cilist *), e_wsfe(void), do_fio(integer *, char *, ftnlen);
    double pow_dd(doublereal *, doublereal *);

    /* Local variables */
    static doublereal a, b;
    static integer i__, j, k, l, m, n;
    static doublereal s, w, x, y, z__, c1, c2;
    static integer i1, k1, k2, k3;
    static doublereal r6, r7, x1;
    static integer it;
    static doublereal xl, xm, xn, zz, del, ait, eps, sum, ysq, half, beta;
    extern doublereal dran_(integer *);
    static integer ngrd, irnd, iexp;
    static doublereal xmin, xmax, zero;
    static integer ibeta;
    static doublereal betap;
    static integer negep;
    static doublereal albeta;
    extern /* Subroutine */ int machar_(integer *, integer *, integer *, 
	    integer *, integer *, integer *, integer *, integer *, integer *, 
	    doublereal *, doublereal *, doublereal *, doublereal *);
    static integer machep;
    static doublereal epsneg;
    static integer minexp, maxexp;

    /* Fortran I/O blocks */
    static cilist io___50 = { 0, 0, 0, fmt_1000, 0 };
    static cilist io___51 = { 0, 0, 0, fmt_1010, 0 };
    static cilist io___52 = { 0, 0, 0, fmt_1011, 0 };
    static cilist io___53 = { 0, 0, 0, fmt_1005, 0 };
    static cilist io___54 = { 0, 0, 0, fmt_1010, 0 };
    static cilist io___55 = { 0, 0, 0, fmt_1012, 0 };
    static cilist io___56 = { 0, 0, 0, fmt_1020, 0 };
    static cilist io___57 = { 0, 0, 0, fmt_1021, 0 };
    static cilist io___58 = { 0, 0, 0, fmt_1022, 0 };
    static cilist io___59 = { 0, 0, 0, fmt_1023, 0 };
    static cilist io___60 = { 0, 0, 0, fmt_1022, 0 };
    static cilist io___61 = { 0, 0, 0, fmt_1025, 0 };
    static cilist io___62 = { 0, 0, 0, fmt_1030, 0 };
    static cilist io___63 = { 0, 0, 0, fmt_1060, 0 };
    static cilist io___64 = { 0, 0, 0, fmt_1031, 0 };
    static cilist io___66 = { 0, 0, 0, fmt_1060, 0 };
    static cilist io___67 = { 0, 0, 0, fmt_1035, 0 };
    static cilist io___68 = { 0, 0, 0, fmt_1061, 0 };
    static cilist io___69 = { 0, 0, 0, fmt_1050, 0 };
    static cilist io___70 = { 0, 0, 0, fmt_1052, 0 };
    static cilist io___71 = { 0, 0, 0, fmt_1055, 0 };
    static cilist io___72 = { 0, 0, 0, fmt_1100, 0 };


/*     PROGRAM TO TEST DASIN/DACOS */

/*     DATA REQUIRED */

/*        NONE */

/*     SUBPROGRAMS REQUIRED FROM THIS PACKAGE */

/*        MACHAR - AN ENVIRONMENTAL INQUIRY PROGRAM PROVIDING */
/*                 INFORMATION ON THE FLOATING-POINT ARITHMETIC */
/*                 SYSTEM.  NOTE THAT THE CALL TO MACHAR CAN */
/*                 BE DELETED PROVIDED THE FOLLOWING FOUR */
/*                 PARAMETERS ARE ASSIGNED THE VALUES INDICATED */

/*                 IBETA  - THE RADIX OF THE FLOATING-POINT SYSTEM */
/*                 IT     - THE NUMBER OF BASE-IBETA DIGITS IN THE */
/*                          SIGNIFICAND OF A FLOATING-POINT NUMBER */
/*                 IRND   - 0 IF FLOATING-POINT ADDITION CHOPS, */
/*                          1 IF FLOATING-POINT ADDITION ROUNDS */
/*                 MINEXP - THE LARGEST IN MAGNITUDE NEGATIVE */
/*                          INTEGER SUCH THAT DFLOAT(IBETA)**MINEXP */
/*                          IS A POSITIVE FLOATING-POINT NUMBER */

/*        DRAN(K) - A FUNCTION SUBPROGRAM RETURNING RANDOM DOUBLE */
/*                 PRECISION NUMBERS UNIFORMLY DISTRIBUTED OVER */
/*                 (0,1) */


/*     STANDARD FORTRAN SUBPROGRAMS REQUIRED */

/*         DABS, DACOS, DLOG, DLOG10, DMAX1, DASIN, DFLOAT, IDINT, DSQRT */


/*     LATEST REVISION - DECEMBER 6, 1979 */

/*     AUTHOR - W. J. CODY */
/*              ARGONNE NATIONAL LABORATORY */



/*     IOUT = 6 */
#line 106 "talldp.f"
    machar_(&ibeta, &it, &irnd, &ngrd, &machep, &negep, &iexp, &minexp, &
	    maxexp, &eps, &epsneg, &xmin, &xmax);
#line 108 "talldp.f"
    beta = (doublereal) ((real) ibeta);
#line 109 "talldp.f"
    albeta = log(beta);
#line 110 "talldp.f"
    zero = 0.;
#line 111 "talldp.f"
    half = .5;
#line 112 "talldp.f"
    ait = (doublereal) ((real) it);
#line 113 "talldp.f"
    d__1 = pow_di(&beta, &it);
#line 113 "talldp.f"
    k = (integer) d_lg10(&d__1) + 1;
#line 114 "talldp.f"
    if (ibeta != 10) {
#line 114 "talldp.f"
	goto L20;
#line 114 "talldp.f"
    }
#line 115 "talldp.f"
    c1 = 1.57;
/* #    C2 = 7.9632679489661923132D-4 */
/* #    C2 = (PI/2) - 1.57 */
#line 118 "talldp.f"
    c2 = 7.9632679489661923132169163975144209858469968755291049e-4;
#line 119 "talldp.f"
    goto L30;
#line 120 "talldp.f"
L20:
#line 120 "talldp.f"
    c1 = 1.5703125;
/* #    C2 = 4.8382679489661923132D-4 */
/* #    C2 = (PI/2) - 201/128 */
#line 123 "talldp.f"
    c2 = 4.8382679489661923132169163975144209858469968755291049e-4;
#line 124 "talldp.f"
L30:
#line 124 "talldp.f"
    a = -.125;
#line 125 "talldp.f"
    b = -a;
#line 126 "talldp.f"
    n = 2000;
#line 127 "talldp.f"
    xn = (doublereal) ((real) n);
#line 128 "talldp.f"
    i1 = 0;
#line 129 "talldp.f"
    l = -1;
/* ----------------------------------------------------------------- */
/*     RANDOM ARGUMENT ACCURACY TESTS */
/* ----------------------------------------------------------------- */
#line 133 "talldp.f"
    for (j = 1; j <= 5; ++j) {
#line 134 "talldp.f"
	k1 = 0;
#line 135 "talldp.f"
	k3 = 0;
#line 136 "talldp.f"
	l = -l;
#line 137 "talldp.f"
	x1 = zero;
#line 138 "talldp.f"
	r6 = zero;
#line 139 "talldp.f"
	r7 = zero;
#line 140 "talldp.f"
	del = (b - a) / xn;
#line 141 "talldp.f"
	xl = a;

#line 143 "talldp.f"
	i__1 = n;
#line 143 "talldp.f"
	for (i__ = 1; i__ <= i__1; ++i__) {
#line 144 "talldp.f"
	    x = del * dran_(&i1) + xl;
#line 145 "talldp.f"
	    if (j <= 2) {
#line 145 "talldp.f"
		goto L40;
#line 145 "talldp.f"
	    }
#line 146 "talldp.f"
	    ysq = half - half * abs(x);
#line 147 "talldp.f"
	    x = half - (ysq + ysq) + half;
#line 148 "talldp.f"
	    if (j == 5) {
#line 148 "talldp.f"
		x = -x;
#line 148 "talldp.f"
	    }
#line 149 "talldp.f"
	    y = sqrt(ysq);
#line 150 "talldp.f"
	    y += y;
#line 151 "talldp.f"
	    goto L50;
#line 152 "talldp.f"
L40:
#line 152 "talldp.f"
	    y = x;
#line 153 "talldp.f"
	    ysq = y * y;
#line 154 "talldp.f"
L50:
#line 154 "talldp.f"
	    sum = zero;
#line 155 "talldp.f"
	    xm = (doublereal) ((real) (k + k + 1));
#line 156 "talldp.f"
	    if (l > 0) {
#line 156 "talldp.f"
		z__ = asin(x);
#line 156 "talldp.f"
	    }
#line 157 "talldp.f"
	    if (l < 0) {
#line 157 "talldp.f"
		z__ = acos(x);
#line 157 "talldp.f"
	    }

#line 159 "talldp.f"
	    i__2 = k;
#line 159 "talldp.f"
	    for (m = 1; m <= i__2; ++m) {
#line 160 "talldp.f"
		sum = ysq * (sum + 1. / xm);
#line 161 "talldp.f"
		xm += -2.;
#line 162 "talldp.f"
		sum *= xm / (xm + 1.);
#line 163 "talldp.f"
/* L60: */
#line 163 "talldp.f"
	    }

#line 165 "talldp.f"
	    sum *= y;
#line 166 "talldp.f"
	    if (j != 1 && j != 4) {
#line 166 "talldp.f"
		goto L70;
#line 166 "talldp.f"
	    }
#line 167 "talldp.f"
	    zz = y + sum;
#line 168 "talldp.f"
	    sum = y - zz + sum;
#line 169 "talldp.f"
	    if (irnd != 1) {
#line 169 "talldp.f"
		zz += sum + sum;
#line 169 "talldp.f"
	    }
#line 170 "talldp.f"
	    goto L110;
#line 171 "talldp.f"
L70:
#line 171 "talldp.f"
	    s = c1 + c2;
#line 172 "talldp.f"
	    sum = c1 - s + c2 - sum;
#line 173 "talldp.f"
	    zz = s + sum;
#line 174 "talldp.f"
	    sum = s - zz + sum - y;
#line 175 "talldp.f"
	    s = zz;
#line 176 "talldp.f"
	    zz = s + sum;
#line 177 "talldp.f"
	    sum = s - zz + sum;
#line 178 "talldp.f"
	    if (irnd != 1) {
#line 178 "talldp.f"
		zz += sum + sum;
#line 178 "talldp.f"
	    }
#line 179 "talldp.f"
L110:
#line 179 "talldp.f"
	    w = 1.;
#line 180 "talldp.f"
	    if (z__ != zero) {
#line 180 "talldp.f"
		w = (z__ - zz) / z__;
#line 180 "talldp.f"
	    }
#line 181 "talldp.f"
	    if (w > zero) {
#line 181 "talldp.f"
		++k1;
#line 181 "talldp.f"
	    }
#line 182 "talldp.f"
	    if (w < zero) {
#line 182 "talldp.f"
		++k3;
#line 182 "talldp.f"
	    }
#line 183 "talldp.f"
	    w = abs(w);
#line 184 "talldp.f"
	    if (w <= r6) {
#line 184 "talldp.f"
		goto L120;
#line 184 "talldp.f"
	    }
#line 185 "talldp.f"
	    r6 = w;
#line 186 "talldp.f"
	    x1 = x;
#line 187 "talldp.f"
L120:
#line 187 "talldp.f"
	    r7 += w * w;
#line 188 "talldp.f"
	    xl += del;
#line 189 "talldp.f"
/* L200: */
#line 189 "talldp.f"
	}

#line 191 "talldp.f"
	k2 = n - k3 - k1;
#line 192 "talldp.f"
	r7 = sqrt(r7 / xn);
#line 193 "talldp.f"
	if (l < 0) {
#line 193 "talldp.f"
	    goto L210;
#line 193 "talldp.f"
	}
#line 194 "talldp.f"
	io___50.ciunit = *iout;
#line 194 "talldp.f"
	s_wsfe(&io___50);
#line 194 "talldp.f"
	e_wsfe();
#line 195 "talldp.f"
	io___51.ciunit = *iout;
#line 195 "talldp.f"
	s_wsfe(&io___51);
#line 195 "talldp.f"
	do_fio(&c__1, (char *)&n, (ftnlen)sizeof(integer));
#line 195 "talldp.f"
	do_fio(&c__1, (char *)&a, (ftnlen)sizeof(doublereal));
#line 195 "talldp.f"
	do_fio(&c__1, (char *)&b, (ftnlen)sizeof(doublereal));
#line 195 "talldp.f"
	e_wsfe();
#line 196 "talldp.f"
	io___52.ciunit = *iout;
#line 196 "talldp.f"
	s_wsfe(&io___52);
#line 196 "talldp.f"
	do_fio(&c__1, (char *)&k1, (ftnlen)sizeof(integer));
#line 196 "talldp.f"
	do_fio(&c__1, (char *)&k2, (ftnlen)sizeof(integer));
#line 196 "talldp.f"
	do_fio(&c__1, (char *)&k3, (ftnlen)sizeof(integer));
#line 196 "talldp.f"
	e_wsfe();
#line 197 "talldp.f"
	goto L220;
#line 198 "talldp.f"
L210:
#line 198 "talldp.f"
	io___53.ciunit = *iout;
#line 198 "talldp.f"
	s_wsfe(&io___53);
#line 198 "talldp.f"
	e_wsfe();
#line 199 "talldp.f"
	io___54.ciunit = *iout;
#line 199 "talldp.f"
	s_wsfe(&io___54);
#line 199 "talldp.f"
	do_fio(&c__1, (char *)&n, (ftnlen)sizeof(integer));
#line 199 "talldp.f"
	do_fio(&c__1, (char *)&a, (ftnlen)sizeof(doublereal));
#line 199 "talldp.f"
	do_fio(&c__1, (char *)&b, (ftnlen)sizeof(doublereal));
#line 199 "talldp.f"
	e_wsfe();
#line 200 "talldp.f"
	io___55.ciunit = *iout;
#line 200 "talldp.f"
	s_wsfe(&io___55);
#line 200 "talldp.f"
	do_fio(&c__1, (char *)&k1, (ftnlen)sizeof(integer));
#line 200 "talldp.f"
	do_fio(&c__1, (char *)&k2, (ftnlen)sizeof(integer));
#line 200 "talldp.f"
	do_fio(&c__1, (char *)&k3, (ftnlen)sizeof(integer));
#line 200 "talldp.f"
	e_wsfe();
#line 201 "talldp.f"
L220:
#line 201 "talldp.f"
	io___56.ciunit = *iout;
#line 201 "talldp.f"
	s_wsfe(&io___56);
#line 201 "talldp.f"
	do_fio(&c__1, (char *)&it, (ftnlen)sizeof(integer));
#line 201 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 201 "talldp.f"
	e_wsfe();
#line 202 "talldp.f"
	w = -999.;
#line 203 "talldp.f"
	if (r6 != zero) {
#line 203 "talldp.f"
	    w = log((abs(r6))) / albeta;
#line 203 "talldp.f"
	}
#line 204 "talldp.f"
	io___57.ciunit = *iout;
#line 204 "talldp.f"
	s_wsfe(&io___57);
#line 204 "talldp.f"
	do_fio(&c__1, (char *)&r6, (ftnlen)sizeof(doublereal));
#line 204 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 204 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 204 "talldp.f"
	do_fio(&c__1, (char *)&x1, (ftnlen)sizeof(doublereal));
#line 204 "talldp.f"
	e_wsfe();
/* Computing MAX */
#line 205 "talldp.f"
	d__1 = ait + w;
#line 205 "talldp.f"
	w = max(d__1,zero);
#line 206 "talldp.f"
	io___58.ciunit = *iout;
#line 206 "talldp.f"
	s_wsfe(&io___58);
#line 206 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 206 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 206 "talldp.f"
	e_wsfe();
#line 207 "talldp.f"
	w = -999.;
#line 208 "talldp.f"
	if (r7 != zero) {
#line 208 "talldp.f"
	    w = log((abs(r7))) / albeta;
#line 208 "talldp.f"
	}
#line 209 "talldp.f"
	io___59.ciunit = *iout;
#line 209 "talldp.f"
	s_wsfe(&io___59);
#line 209 "talldp.f"
	do_fio(&c__1, (char *)&r7, (ftnlen)sizeof(doublereal));
#line 209 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 209 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 209 "talldp.f"
	e_wsfe();
/* Computing MAX */
#line 210 "talldp.f"
	d__1 = ait + w;
#line 210 "talldp.f"
	w = max(d__1,zero);
#line 211 "talldp.f"
	io___60.ciunit = *iout;
#line 211 "talldp.f"
	s_wsfe(&io___60);
#line 211 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 211 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 211 "talldp.f"
	e_wsfe();
#line 212 "talldp.f"
	if (j != 2) {
#line 212 "talldp.f"
	    goto L250;
#line 212 "talldp.f"
	}
#line 213 "talldp.f"
	a = .75;
#line 214 "talldp.f"
	b = 1.;
#line 215 "talldp.f"
L250:
#line 215 "talldp.f"
	if (j != 4) {
#line 215 "talldp.f"
	    goto L300;
#line 215 "talldp.f"
	}
#line 216 "talldp.f"
	b = -a;
#line 217 "talldp.f"
	a = -1.;
#line 218 "talldp.f"
	c1 += c1;
#line 219 "talldp.f"
	c2 += c2;
#line 220 "talldp.f"
	l = -l;
#line 221 "talldp.f"
L300:
#line 221 "talldp.f"
	;
#line 221 "talldp.f"
    }
/* ----------------------------------------------------------------- */
/*     SPECIAL TESTS */
/* ----------------------------------------------------------------- */
#line 225 "talldp.f"
    io___61.ciunit = *iout;
#line 225 "talldp.f"
    s_wsfe(&io___61);
#line 225 "talldp.f"
    e_wsfe();
#line 226 "talldp.f"
    io___62.ciunit = *iout;
#line 226 "talldp.f"
    s_wsfe(&io___62);
#line 226 "talldp.f"
    e_wsfe();

#line 228 "talldp.f"
    for (i__ = 1; i__ <= 5; ++i__) {
#line 229 "talldp.f"
	x = dran_(&i1) * a;
#line 230 "talldp.f"
	z__ = asin(x) + asin(-x);
#line 231 "talldp.f"
	io___63.ciunit = *iout;
#line 231 "talldp.f"
	s_wsfe(&io___63);
#line 231 "talldp.f"
	do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 231 "talldp.f"
	do_fio(&c__1, (char *)&z__, (ftnlen)sizeof(doublereal));
#line 231 "talldp.f"
	e_wsfe();
#line 232 "talldp.f"
/* L320: */
#line 232 "talldp.f"
    }

#line 234 "talldp.f"
    io___64.ciunit = *iout;
#line 234 "talldp.f"
    s_wsfe(&io___64);
#line 234 "talldp.f"
    e_wsfe();
#line 235 "talldp.f"
    betap = pow_di(&beta, &it);
#line 236 "talldp.f"
    x = dran_(&i1) / betap;

#line 238 "talldp.f"
    for (i__ = 1; i__ <= 5; ++i__) {
#line 239 "talldp.f"
	z__ = x - asin(x);
#line 240 "talldp.f"
	io___66.ciunit = *iout;
#line 240 "talldp.f"
	s_wsfe(&io___66);
#line 240 "talldp.f"
	do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 240 "talldp.f"
	do_fio(&c__1, (char *)&z__, (ftnlen)sizeof(doublereal));
#line 240 "talldp.f"
	e_wsfe();
#line 241 "talldp.f"
	x /= beta;
#line 242 "talldp.f"
/* L330: */
#line 242 "talldp.f"
    }

#line 244 "talldp.f"
    io___67.ciunit = *iout;
#line 244 "talldp.f"
    s_wsfe(&io___67);
#line 244 "talldp.f"
    e_wsfe();
#line 245 "talldp.f"
    d__1 = (doublereal) ((real) minexp) * .75;
#line 245 "talldp.f"
    x = pow_dd(&beta, &d__1);
#line 246 "talldp.f"
    y = asin(x);
#line 247 "talldp.f"
    io___68.ciunit = *iout;
#line 247 "talldp.f"
    s_wsfe(&io___68);
#line 247 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 247 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 247 "talldp.f"
    e_wsfe();
/* ----------------------------------------------------------------- */
/*     TEST OF ERROR RETURNS */
/* ----------------------------------------------------------------- */
#line 251 "talldp.f"
    io___69.ciunit = *iout;
#line 251 "talldp.f"
    s_wsfe(&io___69);
#line 251 "talldp.f"
    e_wsfe();
#line 252 "talldp.f"
    x = 1.2;
#line 253 "talldp.f"
    io___70.ciunit = *iout;
#line 253 "talldp.f"
    s_wsfe(&io___70);
#line 253 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 253 "talldp.f"
    e_wsfe();
#line 254 "talldp.f"
    y = asin(x);
#line 255 "talldp.f"
    io___71.ciunit = *iout;
#line 255 "talldp.f"
    s_wsfe(&io___71);
#line 255 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 255 "talldp.f"
    e_wsfe();
#line 256 "talldp.f"
    io___72.ciunit = *iout;
#line 256 "talldp.f"
    s_wsfe(&io___72);
#line 256 "talldp.f"
    e_wsfe();
#line 257 "talldp.f"
    return 0;
/*     ---------- LAST CARD OF DASIN/DACOS TEST PROGRAM ---------- */
} /* tdasin_ */

/* Subroutine */ int tdatan_(integer *iout)
{
    /* Format strings */
    static char fmt_1000[] = "(\0021TEST OF DATAN(X) VS TRUNCATED TAYLOR SER"
	    "IES  \002//)";
    static char fmt_1001[] = "(\0021TEST OF DATAN(X) VS \002,\002DATAN(1/16)"
	    " + DATAN((X-1/16)/(1+X/16))   \002//)";
    static char fmt_1002[] = "(\0021TEST OF 2*DATAN(X) VS DATAN(2X/(1-X*X)) "
	    "   \002//)";
    static char fmt_1010[] = "(i7,\002 RANDOM ARGUMENTS WERE TESTED FROM THE"
	    " INTERVAL\002/6x,\002(\002,d15.4,\002,\002,d15.4,\002)\002//)";
    static char fmt_1011[] = "(\002 DATAN(X) WAS LARGER\002,i6,\002 TIMES"
	    ",\002/13x,\002 AGREED\002,i6,\002 TIMES, AND\002/9x,\002WAS SMAL"
	    "LER\002,i6,\002 TIMES.\002//)";
    static char fmt_1020[] = "(\002 THERE ARE\002,i4,\002 BASE\002,i4,\002 S"
	    "IGNIFICANT DIGITS IN A FLOATING-POINT NUMBER\002//)";
    static char fmt_1021[] = "(\002 THE MAXIMUM RELATIVE ERROR OF\002,d15.4"
	    ",\002 = \002,i4,\002 **\002,f7.2/4x,\002OCCURRED FOR X =\002,d17"
	    ".6)";
    static char fmt_1022[] = "(\002 THE ESTIMATED LOSS OF BASE\002,i4,\002 S"
	    "IGNIFICANT DIGITS IS\002,f7.2//)";
    static char fmt_1023[] = "(\002 THE ROOT MEAN SQUARE RELATIVE ERROR WA"
	    "S\002,d15.4,\002 = \002,i4,\002 **\002,f7.2)";
    static char fmt_1025[] = "(\0021SPECIAL TESTS\002//)";
    static char fmt_1030[] = "(\002 THE IDENTITY   DATAN(-X) = -DATAN(X)   W"
	    "ILL BE TESTED.\002//8x,\002X\002,9x,\002F(X) + F(-X)\002/)";
    static char fmt_1060[] = "(d15.7,d25.17/)";
    static char fmt_1031[] = "(\002 THE IDENTITY DATAN(X) = X , X SMALL, WIL"
	    "L BE TESTED.\002//8x,\002X\002,9x,\002X - F(X)\002/)";
    static char fmt_1032[] = "(\002 THE IDENTITY DATAN(X/Y) = DATAN2(X,Y) WI"
	    "LL BE TESTED \002/\002 THE FIRST COLUMN OF RESULTS SHOULD BE 0, "
	    "THE SECOND +-PI\002//8x,\002X\002,13x,\002Y\002,7x,\002F1(X/Y)-F"
	    "2(X,Y)\002,5x,\002F1(X/Y)-F2(X/(-Y))\002/)";
    static char fmt_1059[] = "(2d15.7,2d25.17/)";
    static char fmt_1035[] = "(\002 TEST OF UNDERFLOW FOR VERY SMALL ARGUMEN"
	    "T.\002/)";
    static char fmt_1061[] = "(6x,\002 DATAN(\002,d13.6,\002) =\002,d13.6/)";
    static char fmt_1050[] = "(\0021TEST OF ERROR RETURNS\002//)";
    static char fmt_1051[] = "(\002 DATAN WILL BE CALLED WITH THE ARGUMEN"
	    "T\002,d15.7/\002 THIS SHOULD NOT TRIGGER AN ERROR MESSAGE\002/)";
    static char fmt_1053[] = "(\002 DATAN2 WILL BE CALLED WITH THE ARGUMENT"
	    "S\002/2d15.7/\002 THIS SHOULD NOT TRIGGER AN ERROR MESSAGE\002/)";
    static char fmt_1062[] = "(6x,\002 DATAN2(\002,2d13.6,\002) =\002,d13.6/)"
	    ;
    static char fmt_1054[] = "(\002 DATAN2 WILL BE CALLED WITH THE ARGUMENT"
	    "S\002/2d15.7/\002 THIS SHOULD TRIGGER AN ERROR MESSAGE\002//)";
    static char fmt_1100[] = "(\002 THIS CONCLUDES THE TESTS\002)";

    /* System generated locals */
    integer i__1;
    doublereal d__1;

    /* Builtin functions */
    double log(doublereal), atan(doublereal), sqrt(doublereal);
    integer s_wsfe(cilist *), e_wsfe(void), do_fio(integer *, char *, ftnlen);
    double pow_di(doublereal *, integer *), atan2(doublereal, doublereal), 
	    pow_dd(doublereal *, doublereal *);

    /* Local variables */
    static doublereal a, b;
    static integer i__, j, n;
    static doublereal w, x, y, z__;
    static integer i1, k1, k2, k3;
    static doublereal r6, r7, x1;
    static integer ii;
    static doublereal em;
    static integer it;
    static doublereal xl, xn, zz, del, ob32, ait, one, eps, sum, two, xsq, 
	    half, beta;
    extern doublereal dran_(integer *);
    static integer ngrd, irnd, iexp;
    static doublereal xmin, xmax, zero;
    static integer ibeta;
    static doublereal betap;
    static integer negep;
    static doublereal expon, albeta;
    extern /* Subroutine */ int machar_(integer *, integer *, integer *, 
	    integer *, integer *, integer *, integer *, integer *, integer *, 
	    doublereal *, doublereal *, doublereal *, doublereal *);
    static integer machep;
    static doublereal epsneg;
    static integer minexp, maxexp;

    /* Fortran I/O blocks */
    static cilist io___118 = { 0, 0, 0, fmt_1000, 0 };
    static cilist io___119 = { 0, 0, 0, fmt_1001, 0 };
    static cilist io___120 = { 0, 0, 0, fmt_1002, 0 };
    static cilist io___121 = { 0, 0, 0, fmt_1010, 0 };
    static cilist io___122 = { 0, 0, 0, fmt_1011, 0 };
    static cilist io___123 = { 0, 0, 0, fmt_1020, 0 };
    static cilist io___124 = { 0, 0, 0, fmt_1021, 0 };
    static cilist io___125 = { 0, 0, 0, fmt_1022, 0 };
    static cilist io___126 = { 0, 0, 0, fmt_1023, 0 };
    static cilist io___127 = { 0, 0, 0, fmt_1022, 0 };
    static cilist io___128 = { 0, 0, 0, fmt_1025, 0 };
    static cilist io___129 = { 0, 0, 0, fmt_1030, 0 };
    static cilist io___130 = { 0, 0, 0, fmt_1060, 0 };
    static cilist io___131 = { 0, 0, 0, fmt_1031, 0 };
    static cilist io___133 = { 0, 0, 0, fmt_1060, 0 };
    static cilist io___134 = { 0, 0, 0, fmt_1032, 0 };
    static cilist io___135 = { 0, 0, 0, fmt_1059, 0 };
    static cilist io___136 = { 0, 0, 0, fmt_1035, 0 };
    static cilist io___138 = { 0, 0, 0, fmt_1061, 0 };
    static cilist io___139 = { 0, 0, 0, fmt_1050, 0 };
    static cilist io___140 = { 0, 0, 0, fmt_1051, 0 };
    static cilist io___141 = { 0, 0, 0, fmt_1061, 0 };
    static cilist io___142 = { 0, 0, 0, fmt_1053, 0 };
    static cilist io___143 = { 0, 0, 0, fmt_1062, 0 };
    static cilist io___144 = { 0, 0, 0, fmt_1053, 0 };
    static cilist io___145 = { 0, 0, 0, fmt_1062, 0 };
    static cilist io___146 = { 0, 0, 0, fmt_1053, 0 };
    static cilist io___147 = { 0, 0, 0, fmt_1062, 0 };
    static cilist io___148 = { 0, 0, 0, fmt_1054, 0 };
    static cilist io___149 = { 0, 0, 0, fmt_1062, 0 };
    static cilist io___150 = { 0, 0, 0, fmt_1100, 0 };


/*     PROGRAM TO TEST DATAN, DATAN2 */

/*     DATA REQUIRED */

/*        NONE */

/*     SUBPROGRAMS REQUIRED FROM THIS PACKAGE */

/*        MACHAR - AN ENVIRONMENTAL INQUIRY PROGRAM PROVIDING */
/*                 INFORMATION ON THE FLOATING-POINT ARITHMETIC */
/*                 SYSTEM.  NOTE THAT THE CALL TO MACHAR CAN */
/*                 BE DELETED PROVIDED THE FOLLOWING SIX */
/*                 PARAMETERS ARE ASSIGNED THE VALUES INDICATED */

/*                 IBETA  - THE RADIX OF THE FLOATING-POINT SYSTEM */
/*                 IT     - THE NUMBER OF BASE-IBETA DIGITS IN THE */
/*                          SIGNIFICAND OF A FLOATING-POINT NUMBER */
/*                 IRND   - 0 IF FLOATING-POINT ADDITION CHOPS, */
/*                          1 IF FLOATING-POINT ADDITION ROUNDS */
/*                 MINEXP - THE LARGEST IN MAGNITUDE NEGATIVE */
/*                          INTEGER SUCH THAT DFLOAT(IBETA)**MINEXP */
/*                          IS A POSITIVE FLOATING-POINT NUMBER */
/*                 XMIN   - THE SMALLEST NON-VANISHING FLOATING-POINT */
/*                          POWER OF THE RADIX */
/*                 XMAX   - THE LARGEST FINITE FLOATING-POINT NO. */

/*        DRAN(K) - A FUNCTION SUBPROGRAM RETURNING RANDOM DOUBLE */
/*                 PRECISION NUMBERS UNIFORMLY DISTRIBUTED OVER */
/*                 (0,1) */

/*     STANDARD FORTRAN SUBPROGRAMS REQUIRED */

/*         DABS, DLOG, DMAX1, DATAN, DATAN2, DFLOAT, DSQRT */


/*     LATEST REVISION - DECEMBER 6, 1979 */

/*     AUTHOR - W. J. CODY */
/*              ARGONNE NATIONAL LABORATORY */



/*     IOUT = 6 */
#line 340 "talldp.f"
    machar_(&ibeta, &it, &irnd, &ngrd, &machep, &negep, &iexp, &minexp, &
	    maxexp, &eps, &epsneg, &xmin, &xmax);
#line 342 "talldp.f"
    beta = (doublereal) ((real) ibeta);
#line 343 "talldp.f"
    albeta = log(beta);
#line 344 "talldp.f"
    ait = (doublereal) ((real) it);
#line 345 "talldp.f"
    one = 1.;
#line 346 "talldp.f"
    half = .5;
#line 347 "talldp.f"
    two = 2.;
#line 348 "talldp.f"
    zero = 0.;
#line 349 "talldp.f"
    a = -.0625;
#line 350 "talldp.f"
    b = -a;
#line 351 "talldp.f"
    ob32 = b * half;
#line 352 "talldp.f"
    n = 2000;
#line 353 "talldp.f"
    xn = (doublereal) ((real) n);
#line 354 "talldp.f"
    i1 = 0;
/* ----------------------------------------------------------------- */
/*     RANDOM ARGUMENT ACCURACY TESTS */
/* ----------------------------------------------------------------- */
#line 358 "talldp.f"
    for (j = 1; j <= 4; ++j) {
#line 359 "talldp.f"
	k1 = 0;
#line 360 "talldp.f"
	k3 = 0;
#line 361 "talldp.f"
	x1 = zero;
#line 362 "talldp.f"
	r6 = zero;
#line 363 "talldp.f"
	r7 = zero;
#line 364 "talldp.f"
	del = (b - a) / xn;
#line 365 "talldp.f"
	xl = a;

#line 367 "talldp.f"
	i__1 = n;
#line 367 "talldp.f"
	for (i__ = 1; i__ <= i__1; ++i__) {
#line 368 "talldp.f"
	    x = del * dran_(&i1) + xl;
#line 369 "talldp.f"
	    if (j == 2) {
#line 369 "talldp.f"
		x = (x * a + 1. - one) * 16.;
#line 369 "talldp.f"
	    }
#line 370 "talldp.f"
	    z__ = atan(x);
#line 371 "talldp.f"
	    if (j != 1) {
#line 371 "talldp.f"
		goto L100;
#line 371 "talldp.f"
	    }
#line 372 "talldp.f"
	    xsq = x * x;
#line 373 "talldp.f"
	    em = 17.;
#line 374 "talldp.f"
	    sum = xsq / em;

#line 376 "talldp.f"
	    for (ii = 1; ii <= 7; ++ii) {
#line 377 "talldp.f"
		em -= two;
#line 378 "talldp.f"
		sum = (one / em - sum) * xsq;
#line 379 "talldp.f"
/* L80: */
#line 379 "talldp.f"
	    }

#line 381 "talldp.f"
	    sum = -x * sum;
#line 382 "talldp.f"
	    zz = x + sum;
#line 383 "talldp.f"
	    sum = x - zz + sum;
#line 384 "talldp.f"
	    if (irnd == 0) {
#line 384 "talldp.f"
		zz += sum + sum;
#line 384 "talldp.f"
	    }
#line 385 "talldp.f"
	    goto L110;
#line 386 "talldp.f"
L100:
#line 386 "talldp.f"
	    if (j != 2) {
#line 386 "talldp.f"
		goto L105;
#line 386 "talldp.f"
	    }
#line 387 "talldp.f"
	    y = x - .0625;
#line 388 "talldp.f"
	    y /= one + x * a;
/* #          ZZ = (DATAN(Y) - 8.1190004042651526021D-5) + OB32 */
/* #          ZZ = (DATAN(Y) - ((1/16) - ATAN(1/16))) + OB32 */
#line 391 "talldp.f"
	    zz = atan(y) - 
		    8.11900040426515260208870144948863937261122025008053925e-5
		     + ob32;
#line 394 "talldp.f"
	    zz += ob32;
#line 395 "talldp.f"
	    goto L110;
#line 396 "talldp.f"
L105:
#line 396 "talldp.f"
	    z__ += z__;
#line 397 "talldp.f"
	    y = x / ((half + x * half) * (half - x + half));
#line 398 "talldp.f"
	    zz = atan(y);
#line 399 "talldp.f"
L110:
#line 399 "talldp.f"
	    w = one;
#line 400 "talldp.f"
	    if (z__ != zero) {
#line 400 "talldp.f"
		w = (z__ - zz) / z__;
#line 400 "talldp.f"
	    }
#line 401 "talldp.f"
	    if (w > zero) {
#line 401 "talldp.f"
		++k1;
#line 401 "talldp.f"
	    }
#line 402 "talldp.f"
	    if (w < zero) {
#line 402 "talldp.f"
		++k3;
#line 402 "talldp.f"
	    }
#line 403 "talldp.f"
	    w = abs(w);
#line 404 "talldp.f"
	    if (w <= r6) {
#line 404 "talldp.f"
		goto L120;
#line 404 "talldp.f"
	    }
#line 405 "talldp.f"
	    r6 = w;
#line 406 "talldp.f"
	    x1 = x;
#line 407 "talldp.f"
L120:
#line 407 "talldp.f"
	    r7 += w * w;
#line 408 "talldp.f"
	    xl += del;
#line 409 "talldp.f"
/* L200: */
#line 409 "talldp.f"
	}

#line 411 "talldp.f"
	k2 = n - k3 - k1;
#line 412 "talldp.f"
	r7 = sqrt(r7 / xn);
#line 413 "talldp.f"
	if (j == 1) {
#line 413 "talldp.f"
	    io___118.ciunit = *iout;
#line 413 "talldp.f"
	    s_wsfe(&io___118);
#line 413 "talldp.f"
	    e_wsfe();
#line 413 "talldp.f"
	}
#line 414 "talldp.f"
	if (j == 2) {
#line 414 "talldp.f"
	    io___119.ciunit = *iout;
#line 414 "talldp.f"
	    s_wsfe(&io___119);
#line 414 "talldp.f"
	    e_wsfe();
#line 414 "talldp.f"
	}
#line 415 "talldp.f"
	if (j > 2) {
#line 415 "talldp.f"
	    io___120.ciunit = *iout;
#line 415 "talldp.f"
	    s_wsfe(&io___120);
#line 415 "talldp.f"
	    e_wsfe();
#line 415 "talldp.f"
	}
#line 416 "talldp.f"
	io___121.ciunit = *iout;
#line 416 "talldp.f"
	s_wsfe(&io___121);
#line 416 "talldp.f"
	do_fio(&c__1, (char *)&n, (ftnlen)sizeof(integer));
#line 416 "talldp.f"
	do_fio(&c__1, (char *)&a, (ftnlen)sizeof(doublereal));
#line 416 "talldp.f"
	do_fio(&c__1, (char *)&b, (ftnlen)sizeof(doublereal));
#line 416 "talldp.f"
	e_wsfe();
#line 417 "talldp.f"
	io___122.ciunit = *iout;
#line 417 "talldp.f"
	s_wsfe(&io___122);
#line 417 "talldp.f"
	do_fio(&c__1, (char *)&k1, (ftnlen)sizeof(integer));
#line 417 "talldp.f"
	do_fio(&c__1, (char *)&k2, (ftnlen)sizeof(integer));
#line 417 "talldp.f"
	do_fio(&c__1, (char *)&k3, (ftnlen)sizeof(integer));
#line 417 "talldp.f"
	e_wsfe();
#line 418 "talldp.f"
	io___123.ciunit = *iout;
#line 418 "talldp.f"
	s_wsfe(&io___123);
#line 418 "talldp.f"
	do_fio(&c__1, (char *)&it, (ftnlen)sizeof(integer));
#line 418 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 418 "talldp.f"
	e_wsfe();
#line 419 "talldp.f"
	w = -999.;
#line 420 "talldp.f"
	if (r6 != zero) {
#line 420 "talldp.f"
	    w = log((abs(r6))) / albeta;
#line 420 "talldp.f"
	}
#line 421 "talldp.f"
	io___124.ciunit = *iout;
#line 421 "talldp.f"
	s_wsfe(&io___124);
#line 421 "talldp.f"
	do_fio(&c__1, (char *)&r6, (ftnlen)sizeof(doublereal));
#line 421 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 421 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 421 "talldp.f"
	do_fio(&c__1, (char *)&x1, (ftnlen)sizeof(doublereal));
#line 421 "talldp.f"
	e_wsfe();
/* Computing MAX */
#line 422 "talldp.f"
	d__1 = ait + w;
#line 422 "talldp.f"
	w = max(d__1,zero);
#line 423 "talldp.f"
	io___125.ciunit = *iout;
#line 423 "talldp.f"
	s_wsfe(&io___125);
#line 423 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 423 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 423 "talldp.f"
	e_wsfe();
#line 424 "talldp.f"
	w = -999.;
#line 425 "talldp.f"
	if (r7 != zero) {
#line 425 "talldp.f"
	    w = log((abs(r7))) / albeta;
#line 425 "talldp.f"
	}
#line 426 "talldp.f"
	io___126.ciunit = *iout;
#line 426 "talldp.f"
	s_wsfe(&io___126);
#line 426 "talldp.f"
	do_fio(&c__1, (char *)&r7, (ftnlen)sizeof(doublereal));
#line 426 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 426 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 426 "talldp.f"
	e_wsfe();
/* Computing MAX */
#line 427 "talldp.f"
	d__1 = ait + w;
#line 427 "talldp.f"
	w = max(d__1,zero);
#line 428 "talldp.f"
	io___127.ciunit = *iout;
#line 428 "talldp.f"
	s_wsfe(&io___127);
#line 428 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 428 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 428 "talldp.f"
	e_wsfe();
#line 429 "talldp.f"
	a = b;
#line 430 "talldp.f"
	if (j == 1) {
#line 430 "talldp.f"
	    b = two - sqrt(3.);
#line 430 "talldp.f"
	}
#line 431 "talldp.f"
	if (j == 2) {
#line 431 "talldp.f"
	    b = sqrt(two) - one;
#line 431 "talldp.f"
	}
#line 432 "talldp.f"
	if (j == 3) {
#line 432 "talldp.f"
	    b = one;
#line 432 "talldp.f"
	}
#line 433 "talldp.f"
/* L300: */
#line 433 "talldp.f"
    }
/* ----------------------------------------------------------------- */
/*     SPECIAL TESTS */
/* ----------------------------------------------------------------- */
#line 437 "talldp.f"
    io___128.ciunit = *iout;
#line 437 "talldp.f"
    s_wsfe(&io___128);
#line 437 "talldp.f"
    e_wsfe();
#line 438 "talldp.f"
    io___129.ciunit = *iout;
#line 438 "talldp.f"
    s_wsfe(&io___129);
#line 438 "talldp.f"
    e_wsfe();
#line 439 "talldp.f"
    a = 5.;

#line 441 "talldp.f"
    for (i__ = 1; i__ <= 5; ++i__) {
#line 442 "talldp.f"
	x = dran_(&i1) * a;
#line 443 "talldp.f"
	z__ = atan(x) + atan(-x);
#line 444 "talldp.f"
	io___130.ciunit = *iout;
#line 444 "talldp.f"
	s_wsfe(&io___130);
#line 444 "talldp.f"
	do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 444 "talldp.f"
	do_fio(&c__1, (char *)&z__, (ftnlen)sizeof(doublereal));
#line 444 "talldp.f"
	e_wsfe();
#line 445 "talldp.f"
/* L320: */
#line 445 "talldp.f"
    }

#line 447 "talldp.f"
    io___131.ciunit = *iout;
#line 447 "talldp.f"
    s_wsfe(&io___131);
#line 447 "talldp.f"
    e_wsfe();
#line 448 "talldp.f"
    betap = pow_di(&beta, &it);
#line 449 "talldp.f"
    x = dran_(&i1) / betap;

#line 451 "talldp.f"
    for (i__ = 1; i__ <= 5; ++i__) {
#line 452 "talldp.f"
	z__ = x - atan(x);
#line 453 "talldp.f"
	io___133.ciunit = *iout;
#line 453 "talldp.f"
	s_wsfe(&io___133);
#line 453 "talldp.f"
	do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 453 "talldp.f"
	do_fio(&c__1, (char *)&z__, (ftnlen)sizeof(doublereal));
#line 453 "talldp.f"
	e_wsfe();
#line 454 "talldp.f"
	x /= beta;
#line 455 "talldp.f"
/* L330: */
#line 455 "talldp.f"
    }

#line 457 "talldp.f"
    io___134.ciunit = *iout;
#line 457 "talldp.f"
    s_wsfe(&io___134);
#line 457 "talldp.f"
    e_wsfe();
#line 458 "talldp.f"
    a = -two;
#line 459 "talldp.f"
    b = 4.;

#line 461 "talldp.f"
    for (i__ = 1; i__ <= 5; ++i__) {
#line 462 "talldp.f"
	x = dran_(&i1) * b + a;
#line 463 "talldp.f"
	y = dran_(&i1);
#line 464 "talldp.f"
	w = -y;
#line 465 "talldp.f"
	z__ = atan(x / y) - atan2(x, y);
#line 466 "talldp.f"
	zz = atan(x / w) - atan2(x, w);
#line 467 "talldp.f"
	io___135.ciunit = *iout;
#line 467 "talldp.f"
	s_wsfe(&io___135);
#line 467 "talldp.f"
	do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 467 "talldp.f"
	do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 467 "talldp.f"
	do_fio(&c__1, (char *)&z__, (ftnlen)sizeof(doublereal));
#line 467 "talldp.f"
	do_fio(&c__1, (char *)&zz, (ftnlen)sizeof(doublereal));
#line 467 "talldp.f"
	e_wsfe();
#line 468 "talldp.f"
/* L340: */
#line 468 "talldp.f"
    }

#line 470 "talldp.f"
    io___136.ciunit = *iout;
#line 470 "talldp.f"
    s_wsfe(&io___136);
#line 470 "talldp.f"
    e_wsfe();
#line 471 "talldp.f"
    expon = (doublereal) ((real) minexp) * .75;
#line 472 "talldp.f"
    x = pow_dd(&beta, &expon);
#line 473 "talldp.f"
    y = atan(x);
#line 474 "talldp.f"
    io___138.ciunit = *iout;
#line 474 "talldp.f"
    s_wsfe(&io___138);
#line 474 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 474 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 474 "talldp.f"
    e_wsfe();
/* ----------------------------------------------------------------- */
/*     TEST OF ERROR RETURNS */
/* ----------------------------------------------------------------- */
#line 478 "talldp.f"
    io___139.ciunit = *iout;
#line 478 "talldp.f"
    s_wsfe(&io___139);
#line 478 "talldp.f"
    e_wsfe();
#line 479 "talldp.f"
    io___140.ciunit = *iout;
#line 479 "talldp.f"
    s_wsfe(&io___140);
#line 479 "talldp.f"
    do_fio(&c__1, (char *)&xmax, (ftnlen)sizeof(doublereal));
#line 479 "talldp.f"
    e_wsfe();
#line 480 "talldp.f"
    z__ = atan(xmax);
#line 481 "talldp.f"
    io___141.ciunit = *iout;
#line 481 "talldp.f"
    s_wsfe(&io___141);
#line 481 "talldp.f"
    do_fio(&c__1, (char *)&xmax, (ftnlen)sizeof(doublereal));
#line 481 "talldp.f"
    do_fio(&c__1, (char *)&z__, (ftnlen)sizeof(doublereal));
#line 481 "talldp.f"
    e_wsfe();
#line 482 "talldp.f"
    x = one;
#line 483 "talldp.f"
    y = zero;
#line 484 "talldp.f"
    io___142.ciunit = *iout;
#line 484 "talldp.f"
    s_wsfe(&io___142);
#line 484 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 484 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 484 "talldp.f"
    e_wsfe();
#line 485 "talldp.f"
    z__ = atan2(x, y);
#line 486 "talldp.f"
    io___143.ciunit = *iout;
#line 486 "talldp.f"
    s_wsfe(&io___143);
#line 486 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 486 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 486 "talldp.f"
    do_fio(&c__1, (char *)&z__, (ftnlen)sizeof(doublereal));
#line 486 "talldp.f"
    e_wsfe();
#line 487 "talldp.f"
    io___144.ciunit = *iout;
#line 487 "talldp.f"
    s_wsfe(&io___144);
#line 487 "talldp.f"
    do_fio(&c__1, (char *)&xmin, (ftnlen)sizeof(doublereal));
#line 487 "talldp.f"
    do_fio(&c__1, (char *)&xmax, (ftnlen)sizeof(doublereal));
#line 487 "talldp.f"
    e_wsfe();
#line 488 "talldp.f"
    z__ = atan2(xmin, xmax);
#line 489 "talldp.f"
    io___145.ciunit = *iout;
#line 489 "talldp.f"
    s_wsfe(&io___145);
#line 489 "talldp.f"
    do_fio(&c__1, (char *)&xmin, (ftnlen)sizeof(doublereal));
#line 489 "talldp.f"
    do_fio(&c__1, (char *)&xmax, (ftnlen)sizeof(doublereal));
#line 489 "talldp.f"
    do_fio(&c__1, (char *)&z__, (ftnlen)sizeof(doublereal));
#line 489 "talldp.f"
    e_wsfe();
#line 490 "talldp.f"
    io___146.ciunit = *iout;
#line 490 "talldp.f"
    s_wsfe(&io___146);
#line 490 "talldp.f"
    do_fio(&c__1, (char *)&xmax, (ftnlen)sizeof(doublereal));
#line 490 "talldp.f"
    do_fio(&c__1, (char *)&xmin, (ftnlen)sizeof(doublereal));
#line 490 "talldp.f"
    e_wsfe();
#line 491 "talldp.f"
    z__ = atan2(xmax, xmin);
#line 492 "talldp.f"
    io___147.ciunit = *iout;
#line 492 "talldp.f"
    s_wsfe(&io___147);
#line 492 "talldp.f"
    do_fio(&c__1, (char *)&xmax, (ftnlen)sizeof(doublereal));
#line 492 "talldp.f"
    do_fio(&c__1, (char *)&xmin, (ftnlen)sizeof(doublereal));
#line 492 "talldp.f"
    do_fio(&c__1, (char *)&z__, (ftnlen)sizeof(doublereal));
#line 492 "talldp.f"
    e_wsfe();
#line 493 "talldp.f"
    x = zero;
#line 494 "talldp.f"
    io___148.ciunit = *iout;
#line 494 "talldp.f"
    s_wsfe(&io___148);
#line 494 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 494 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 494 "talldp.f"
    e_wsfe();
#line 495 "talldp.f"
    z__ = atan2(x, y);
#line 496 "talldp.f"
    io___149.ciunit = *iout;
#line 496 "talldp.f"
    s_wsfe(&io___149);
#line 496 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 496 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 496 "talldp.f"
    do_fio(&c__1, (char *)&z__, (ftnlen)sizeof(doublereal));
#line 496 "talldp.f"
    e_wsfe();
#line 497 "talldp.f"
    io___150.ciunit = *iout;
#line 497 "talldp.f"
    s_wsfe(&io___150);
#line 497 "talldp.f"
    e_wsfe();
#line 498 "talldp.f"
    return 0;
/*     ---------- LAST CARD OF DATAN/DATAN2 TEST PROGRAM ---------- */
} /* tdatan_ */

/* Subroutine */ int tdexp_(integer *iout)
{
    /* Format strings */
    static char fmt_1000[] = "(\0021TEST OF DEXP(X-\002,f7.4,\002) VS DEXP(X"
	    ")/DEXP(\002,f7.4,\002)\002//)";
    static char fmt_1010[] = "(i7,\002 RANDOM ARGUMENTS WERE TESTED FROM THE"
	    " INTERVAL\002/6x,\002(\002,d15.4,\002,\002,d15.4,\002)\002//)";
    static char fmt_1011[] = "(\002 DEXP(X-V) WAS LARGER\002,i6,\002 TIMES"
	    ",\002/13x,\002 AGREED\002,i6,\002 TIMES, AND\002/9x,\002WAS SMAL"
	    "LER\002,i6,\002 TIMES.\002//)";
    static char fmt_1020[] = "(\002 THERE ARE\002,i4,\002 BASE\002,i4,\002 S"
	    "IGNIFICANT DIGITS IN A FLOATING-POINT NUMBER\002//)";
    static char fmt_1021[] = "(\002 THE MAXIMUM RELATIVE ERROR OF\002,d15.4"
	    ",\002 = \002,i4,\002 **\002,f7.2/4x,\002OCCURRED FOR X =\002,d17"
	    ".6)";
    static char fmt_1022[] = "(\002 THE ESTIMATED LOSS OF BASE\002,i4,\002 S"
	    "IGNIFICANT DIGITS IS\002,f7.2//)";
    static char fmt_1023[] = "(\002 THE ROOT MEAN SQUARE RELATIVE ERROR WA"
	    "S\002,d15.4,\002 = \002,i4,\002 **\002,f7.2)";
    static char fmt_1025[] = "(\0021SPECIAL TESTS\002//)";
    static char fmt_1030[] = "(\002 THE IDENTITY  DEXP(X)*DEXP(-X) = 1.0  WI"
	    "LL BE TESTED.\002//8x,\002X\002,9x,\002F(X)*F(-X) - 1\002/)";
    static char fmt_1060[] = "(d15.7,d25.17/)";
    static char fmt_1040[] = "(//\002 TEST OF SPECIAL ARGUMENTS\002//)";
    static char fmt_1041[] = "(\002 DEXP(0.0) - 1.0D+00 = \002,d15.7/)";
    static char fmt_1042[] = "(\002 DEXP(\002,d13.6,\002) =\002,d13.6/)";
    static char fmt_1043[] = "(\0020IF DEXP(\002,d13.6,\002) = \002,d23.16"
	    ",\002 IS NOT ABOUT\002/\002 DEXP(\002,d13.6,\002)**2 = \002,d23."
	    "16,\002 THERE IS AN ARG RED ERROR\002)";
    static char fmt_1050[] = "(\0021TEST OF ERROR RETURNS\002//)";
    static char fmt_1052[] = "(\0020EXP WILL BE CALLED WITH THE ARGUMENT\002"
	    ",d15.4/\002 THIS SHOULD TRIGGER AN ERROR MESSAGE\002//)";
    static char fmt_1061[] = "(\002 DEXP RETURNED THE VALUE\002,d15.4///)";
    static char fmt_1100[] = "(\002 THIS CONCLUDES THE TESTS\002)";

    /* System generated locals */
    integer i__1;
    real r__1;
    doublereal d__1;

    /* Builtin functions */
    double log(doublereal), exp(doublereal), sqrt(doublereal);
    integer s_wsfe(cilist *), do_fio(integer *, char *, ftnlen), e_wsfe(void);
    double pow_di(doublereal *, integer *), r_int(real *);

    /* Local variables */
    static doublereal a, b, d__;
    static integer i__, j, n;
    static doublereal v, w, x, y, z__;
    static integer i1, k1, k2, k3;
    static doublereal r6, r7, x1;
    static integer it;
    static doublereal xl, xn, zz, del, ait, one, ten, eps, two, beta;
    extern doublereal dran_(integer *);
    static integer ngrd, irnd, iexp;
    static doublereal xmin, xmax, zero;
    static integer ibeta, negep;
    static doublereal albeta;
    extern /* Subroutine */ int machar_(integer *, integer *, integer *, 
	    integer *, integer *, integer *, integer *, integer *, integer *, 
	    doublereal *, doublereal *, doublereal *, doublereal *);
    static integer machep;
    static doublereal epsneg;
    static integer minexp, maxexp;

    /* Fortran I/O blocks */
    static cilist io___193 = { 0, 0, 0, fmt_1000, 0 };
    static cilist io___194 = { 0, 0, 0, fmt_1010, 0 };
    static cilist io___195 = { 0, 0, 0, fmt_1011, 0 };
    static cilist io___196 = { 0, 0, 0, fmt_1020, 0 };
    static cilist io___197 = { 0, 0, 0, fmt_1021, 0 };
    static cilist io___198 = { 0, 0, 0, fmt_1022, 0 };
    static cilist io___199 = { 0, 0, 0, fmt_1023, 0 };
    static cilist io___200 = { 0, 0, 0, fmt_1022, 0 };
    static cilist io___201 = { 0, 0, 0, fmt_1025, 0 };
    static cilist io___202 = { 0, 0, 0, fmt_1030, 0 };
    static cilist io___203 = { 0, 0, 0, fmt_1060, 0 };
    static cilist io___204 = { 0, 0, 0, fmt_1040, 0 };
    static cilist io___205 = { 0, 0, 0, fmt_1041, 0 };
    static cilist io___206 = { 0, 0, 0, fmt_1042, 0 };
    static cilist io___207 = { 0, 0, 0, fmt_1042, 0 };
    static cilist io___208 = { 0, 0, 0, fmt_1043, 0 };
    static cilist io___209 = { 0, 0, 0, fmt_1050, 0 };
    static cilist io___210 = { 0, 0, 0, fmt_1052, 0 };
    static cilist io___211 = { 0, 0, 0, fmt_1061, 0 };
    static cilist io___212 = { 0, 0, 0, fmt_1052, 0 };
    static cilist io___213 = { 0, 0, 0, fmt_1061, 0 };
    static cilist io___214 = { 0, 0, 0, fmt_1100, 0 };


/*     PROGRAM TO TEST DEXP */

/*     DATA REQUIRED */

/*        NONE */

/*     SUBPROGRAMS REQUIRED FROM THIS PACKAGE */

/*        MACHAR - AN ENVIRONMENTAL INQUIRY PROGRAM PROVIDING */
/*                 INFORMATION ON THE FLOATING-POINT ARITHMETIC */
/*                 SYSTEM.  NOTE THAT THE CALL TO MACHAR CAN */
/*                 BE DELETED PROVIDED THE FOLLOWING FOUR */
/*                 PARAMETERS ARE ASSIGNED THE VALUES INDICATED */

/*                 IBETA - THE RADIX OF THE FLOATING-POINT SYSTEM */
/*                 IT    - THE NUMBER OF BASE-IBETA DIGITS IN THE */
/*                         SIGNIFICAND OF A FLOATING-POINT NUMBER */
/*                 XMIN  - THE SMALLEST NON-VANISHING FLOATING-POINT */
/*                         POWER OF THE RADIX */
/*                 XMAX  - THE LARGEST FINITE FLOATING-POINT NO. */

/*        DRAN(K) - A FUNCTION SUBPROGRAM RETURNING RANDOM DOUBLE */
/*                 PRECISION NUMBERS UNIFORMLY DISTRIBUTED OVER */
/*                 (0,1) */


/*     STANDARD FORTRAN SUBPROGRAMS REQUIRED */

/*         DABS, AINT, DLOG, DMAX1, DEXP, DFLOAT, DSQRT, SNGL */


/*     LATEST REVISION - DECEMBER 6, 1979 */

/*     AUTHOR - W. J. CODY */
/*              ARGONNE NATIONAL LABORATORY */



/*     IOUT = 6 */
#line 584 "talldp.f"
    machar_(&ibeta, &it, &irnd, &ngrd, &machep, &negep, &iexp, &minexp, &
	    maxexp, &eps, &epsneg, &xmin, &xmax);
#line 586 "talldp.f"
    beta = (doublereal) ((real) ibeta);
#line 587 "talldp.f"
    albeta = log(beta);
#line 588 "talldp.f"
    ait = (doublereal) ((real) it);
#line 589 "talldp.f"
    one = 1.;
#line 590 "talldp.f"
    two = 2.;
#line 591 "talldp.f"
    ten = 10.;
#line 592 "talldp.f"
    zero = 0.;
#line 593 "talldp.f"
    v = .0625;
#line 594 "talldp.f"
    a = two;
#line 595 "talldp.f"
    b = log(a) * .5;
#line 596 "talldp.f"
    a = -b + v;
#line 597 "talldp.f"
    d__ = log(xmax * .9);
#line 598 "talldp.f"
    n = 2000;
#line 599 "talldp.f"
    xn = (doublereal) ((real) n);
#line 600 "talldp.f"
    i1 = 0;
/* --------------------------------------------------------------------- */
/*     RANDOM ARGUMENT ACCURACY TESTS */
/* --------------------------------------------------------------------- */
#line 604 "talldp.f"
    for (j = 1; j <= 3; ++j) {
#line 605 "talldp.f"
	k1 = 0;
#line 606 "talldp.f"
	k3 = 0;
#line 607 "talldp.f"
	x1 = zero;
#line 608 "talldp.f"
	r6 = zero;
#line 609 "talldp.f"
	r7 = zero;
#line 610 "talldp.f"
	del = (b - a) / xn;
#line 611 "talldp.f"
	xl = a;

#line 613 "talldp.f"
	i__1 = n;
#line 613 "talldp.f"
	for (i__ = 1; i__ <= i__1; ++i__) {
#line 614 "talldp.f"
	    x = del * dran_(&i1) + xl;
/* --------------------------------------------------------------------- */
/*     PURIFY ARGUMENTS */
/* --------------------------------------------------------------------- */
#line 618 "talldp.f"
	    y = x - v;
#line 619 "talldp.f"
	    if (y < zero) {
#line 619 "talldp.f"
		x = y + v;
#line 619 "talldp.f"
	    }
#line 620 "talldp.f"
	    z__ = exp(x);
#line 621 "talldp.f"
	    zz = exp(y);
#line 622 "talldp.f"
	    if (j == 1) {
#line 622 "talldp.f"
		goto L100;
#line 622 "talldp.f"
	    }
/* #          IF (IBETA .NE. 10) Z = Z * 0.0625D+00 - */
/* #   1                             Z * 2.4453321046920570389D-3 */
/* #          IF (IBETA .NE. 10) Z = Z * 0.0625D+00 - Z * */
/* #   1           (0.0625 - 1/EXP(45/16)) */
#line 627 "talldp.f"
	    if (ibeta != 10) {
#line 627 "talldp.f"
		z__ = z__ * .0625 - z__ * 
			.002445332104692057038944386692209648655994744180777192315
			;
#line 627 "talldp.f"
	    }
/* #          IF (IBETA .EQ. 10) Z = Z * 6.0D-2 + */
/* #   1                             Z * 5.466789530794296106D-5 */
/* #          IF (IBETA .EQ. 10) Z = Z * 6.0D-2 + Z * */
/* #   X           (1/EXP(45/16) - 0.06) */
#line 633 "talldp.f"
	    if (ibeta == 10) {
#line 633 "talldp.f"
		z__ = z__ * .06 + z__ * 
			5.46678953079429610556133077903513440052558192228076851e-5
			;
#line 633 "talldp.f"
	    }
#line 635 "talldp.f"
	    goto L110;
/* #100       Z = Z - Z * 6.058693718652421388D-2 */
/* #          Z = Z - Z * (1 - 1/EXP(1/16)) */
#line 638 "talldp.f"
L100:
#line 638 "talldp.f"
	    z__ -= z__ * 
		    .06058693718652421388028917537769491547531910945055817799;
#line 640 "talldp.f"
L110:
#line 640 "talldp.f"
	    w = one;
#line 641 "talldp.f"
	    if (zz != zero) {
#line 641 "talldp.f"
		w = (z__ - zz) / zz;
#line 641 "talldp.f"
	    }
#line 642 "talldp.f"
	    if (w < zero) {
#line 642 "talldp.f"
		++k1;
#line 642 "talldp.f"
	    }
#line 643 "talldp.f"
	    if (w > zero) {
#line 643 "talldp.f"
		++k3;
#line 643 "talldp.f"
	    }
#line 644 "talldp.f"
	    w = abs(w);
#line 645 "talldp.f"
	    if (w <= r6) {
#line 645 "talldp.f"
		goto L120;
#line 645 "talldp.f"
	    }
#line 646 "talldp.f"
	    r6 = w;
#line 647 "talldp.f"
	    x1 = x;
#line 648 "talldp.f"
L120:
#line 648 "talldp.f"
	    r7 += w * w;
#line 649 "talldp.f"
	    xl += del;
#line 650 "talldp.f"
/* L200: */
#line 650 "talldp.f"
	}

#line 652 "talldp.f"
	k2 = n - k3 - k1;
#line 653 "talldp.f"
	r7 = sqrt(r7 / xn);
#line 654 "talldp.f"
	io___193.ciunit = *iout;
#line 654 "talldp.f"
	s_wsfe(&io___193);
#line 654 "talldp.f"
	do_fio(&c__1, (char *)&v, (ftnlen)sizeof(doublereal));
#line 654 "talldp.f"
	do_fio(&c__1, (char *)&v, (ftnlen)sizeof(doublereal));
#line 654 "talldp.f"
	e_wsfe();
#line 655 "talldp.f"
	io___194.ciunit = *iout;
#line 655 "talldp.f"
	s_wsfe(&io___194);
#line 655 "talldp.f"
	do_fio(&c__1, (char *)&n, (ftnlen)sizeof(integer));
#line 655 "talldp.f"
	do_fio(&c__1, (char *)&a, (ftnlen)sizeof(doublereal));
#line 655 "talldp.f"
	do_fio(&c__1, (char *)&b, (ftnlen)sizeof(doublereal));
#line 655 "talldp.f"
	e_wsfe();
#line 656 "talldp.f"
	io___195.ciunit = *iout;
#line 656 "talldp.f"
	s_wsfe(&io___195);
#line 656 "talldp.f"
	do_fio(&c__1, (char *)&k1, (ftnlen)sizeof(integer));
#line 656 "talldp.f"
	do_fio(&c__1, (char *)&k2, (ftnlen)sizeof(integer));
#line 656 "talldp.f"
	do_fio(&c__1, (char *)&k3, (ftnlen)sizeof(integer));
#line 656 "talldp.f"
	e_wsfe();
#line 657 "talldp.f"
	io___196.ciunit = *iout;
#line 657 "talldp.f"
	s_wsfe(&io___196);
#line 657 "talldp.f"
	do_fio(&c__1, (char *)&it, (ftnlen)sizeof(integer));
#line 657 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 657 "talldp.f"
	e_wsfe();
#line 658 "talldp.f"
	w = -999.;
#line 659 "talldp.f"
	if (r6 != zero) {
#line 659 "talldp.f"
	    w = log((abs(r6))) / albeta;
#line 659 "talldp.f"
	}
#line 660 "talldp.f"
	io___197.ciunit = *iout;
#line 660 "talldp.f"
	s_wsfe(&io___197);
#line 660 "talldp.f"
	do_fio(&c__1, (char *)&r6, (ftnlen)sizeof(doublereal));
#line 660 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 660 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 660 "talldp.f"
	do_fio(&c__1, (char *)&x1, (ftnlen)sizeof(doublereal));
#line 660 "talldp.f"
	e_wsfe();
/* Computing MAX */
#line 661 "talldp.f"
	d__1 = ait + w;
#line 661 "talldp.f"
	w = max(d__1,zero);
#line 662 "talldp.f"
	io___198.ciunit = *iout;
#line 662 "talldp.f"
	s_wsfe(&io___198);
#line 662 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 662 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 662 "talldp.f"
	e_wsfe();
#line 663 "talldp.f"
	w = -999.;
#line 664 "talldp.f"
	if (r7 != zero) {
#line 664 "talldp.f"
	    w = log((abs(r7))) / albeta;
#line 664 "talldp.f"
	}
#line 665 "talldp.f"
	io___199.ciunit = *iout;
#line 665 "talldp.f"
	s_wsfe(&io___199);
#line 665 "talldp.f"
	do_fio(&c__1, (char *)&r7, (ftnlen)sizeof(doublereal));
#line 665 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 665 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 665 "talldp.f"
	e_wsfe();
/* Computing MAX */
#line 666 "talldp.f"
	d__1 = ait + w;
#line 666 "talldp.f"
	w = max(d__1,zero);
#line 667 "talldp.f"
	io___200.ciunit = *iout;
#line 667 "talldp.f"
	s_wsfe(&io___200);
#line 667 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 667 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 667 "talldp.f"
	e_wsfe();
#line 668 "talldp.f"
	if (j == 2) {
#line 668 "talldp.f"
	    goto L270;
#line 668 "talldp.f"
	}
#line 669 "talldp.f"
	v = 2.8125;
#line 670 "talldp.f"
	a = -ten * b;
#line 671 "talldp.f"
	b = xmin * 4. * pow_di(&beta, &it);
#line 672 "talldp.f"
	b = log(b);
#line 673 "talldp.f"
	goto L300;
#line 674 "talldp.f"
L270:
#line 674 "talldp.f"
	a = -two * a;
#line 675 "talldp.f"
	b = ten * a;
#line 676 "talldp.f"
	if (b < d__) {
#line 676 "talldp.f"
	    b = d__;
#line 676 "talldp.f"
	}
#line 677 "talldp.f"
L300:
#line 677 "talldp.f"
	;
#line 677 "talldp.f"
    }
/* --------------------------------------------------------------------- */
/*     SPECIAL TESTS */
/* --------------------------------------------------------------------- */
#line 681 "talldp.f"
    io___201.ciunit = *iout;
#line 681 "talldp.f"
    s_wsfe(&io___201);
#line 681 "talldp.f"
    e_wsfe();
#line 682 "talldp.f"
    io___202.ciunit = *iout;
#line 682 "talldp.f"
    s_wsfe(&io___202);
#line 682 "talldp.f"
    e_wsfe();

#line 684 "talldp.f"
    for (i__ = 1; i__ <= 5; ++i__) {
#line 685 "talldp.f"
	x = dran_(&i1) * beta;
#line 686 "talldp.f"
	y = -x;
#line 687 "talldp.f"
	z__ = exp(x) * exp(y) - one;
#line 688 "talldp.f"
	io___203.ciunit = *iout;
#line 688 "talldp.f"
	s_wsfe(&io___203);
#line 688 "talldp.f"
	do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 688 "talldp.f"
	do_fio(&c__1, (char *)&z__, (ftnlen)sizeof(doublereal));
#line 688 "talldp.f"
	e_wsfe();
#line 689 "talldp.f"
/* L320: */
#line 689 "talldp.f"
    }

#line 691 "talldp.f"
    io___204.ciunit = *iout;
#line 691 "talldp.f"
    s_wsfe(&io___204);
#line 691 "talldp.f"
    e_wsfe();
#line 692 "talldp.f"
    x = zero;
#line 693 "talldp.f"
    y = exp(x) - one;
#line 694 "talldp.f"
    io___205.ciunit = *iout;
#line 694 "talldp.f"
    s_wsfe(&io___205);
#line 694 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 694 "talldp.f"
    e_wsfe();
#line 695 "talldp.f"
    r__1 = (real) log(xmin);
#line 695 "talldp.f"
    x = r_int(&r__1);
#line 696 "talldp.f"
    y = exp(x);
#line 697 "talldp.f"
    io___206.ciunit = *iout;
#line 697 "talldp.f"
    s_wsfe(&io___206);
#line 697 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 697 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 697 "talldp.f"
    e_wsfe();
#line 698 "talldp.f"
    r__1 = (real) log(xmax);
#line 698 "talldp.f"
    x = r_int(&r__1);
#line 699 "talldp.f"
    y = exp(x);
#line 700 "talldp.f"
    io___207.ciunit = *iout;
#line 700 "talldp.f"
    s_wsfe(&io___207);
#line 700 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 700 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 700 "talldp.f"
    e_wsfe();
#line 701 "talldp.f"
    x /= two;
#line 702 "talldp.f"
    v = x / two;
#line 703 "talldp.f"
    y = exp(x);
#line 704 "talldp.f"
    z__ = exp(v);
#line 705 "talldp.f"
    z__ *= z__;
#line 706 "talldp.f"
    io___208.ciunit = *iout;
#line 706 "talldp.f"
    s_wsfe(&io___208);
#line 706 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 706 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 706 "talldp.f"
    do_fio(&c__1, (char *)&v, (ftnlen)sizeof(doublereal));
#line 706 "talldp.f"
    do_fio(&c__1, (char *)&z__, (ftnlen)sizeof(doublereal));
#line 706 "talldp.f"
    e_wsfe();
/* --------------------------------------------------------------------- */
/*     TEST OF ERROR RETURNS */
/* --------------------------------------------------------------------- */
#line 710 "talldp.f"
    io___209.ciunit = *iout;
#line 710 "talldp.f"
    s_wsfe(&io___209);
#line 710 "talldp.f"
    e_wsfe();
#line 711 "talldp.f"
    x = -one / sqrt(xmin);
#line 712 "talldp.f"
    io___210.ciunit = *iout;
#line 712 "talldp.f"
    s_wsfe(&io___210);
#line 712 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 712 "talldp.f"
    e_wsfe();
#line 713 "talldp.f"
    y = exp(x);
#line 714 "talldp.f"
    io___211.ciunit = *iout;
#line 714 "talldp.f"
    s_wsfe(&io___211);
#line 714 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 714 "talldp.f"
    e_wsfe();
#line 715 "talldp.f"
    x = -x;
#line 716 "talldp.f"
    io___212.ciunit = *iout;
#line 716 "talldp.f"
    s_wsfe(&io___212);
#line 716 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 716 "talldp.f"
    e_wsfe();
#line 717 "talldp.f"
    y = exp(x);
#line 718 "talldp.f"
    io___213.ciunit = *iout;
#line 718 "talldp.f"
    s_wsfe(&io___213);
#line 718 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 718 "talldp.f"
    e_wsfe();
#line 719 "talldp.f"
    io___214.ciunit = *iout;
#line 719 "talldp.f"
    s_wsfe(&io___214);
#line 719 "talldp.f"
    e_wsfe();
#line 720 "talldp.f"
    return 0;
/*     ---------- LAST CARD OF DEXP TEST PROGRAM ---------- */
} /* tdexp_ */

/* Subroutine */ int tdlog_(integer *iout)
{
    /* Format strings */
    static char fmt_1000[] = "(\0021TEST OF DLOG(X) VS T.S. EXPANSION OF DLO"
	    "G(1+Y)  \002//)";
    static char fmt_1001[] = "(\0021TEST OF DLOG(X) VS DLOG(17X/16)-DLOG(17/"
	    "16)   \002//)";
    static char fmt_1005[] = "(\0021TEST OF DLOG10(X) VS DLOG10(11X/10)-DLOG"
	    "10(11/10) \002//)";
    static char fmt_1002[] = "(\0021TEST OF DLOG(X*X) VS 2 * LOG(X)  \002//)";
    static char fmt_1009[] = "(i7,\002 RANDOM ARGUMENTS WERE TESTED FROM THE"
	    " INTERVAL\002/6x,\002(1-EPS,1+EPS), WHERE EPS =\002,d15.4//)";
    static char fmt_1010[] = "(i7,\002 RANDOM ARGUMENTS WERE TESTED FROM THE"
	    " INTERVAL\002/6x,\002(\002,d15.4,\002,\002,d15.4,\002)\002//)";
    static char fmt_1011[] = "(\002 DLOG(X) WAS LARGER\002,i6,\002 TIMES,"
	    "\002/12x,\002 AGREED\002,i6,\002 TIMES, AND\002/8x,\002WAS SMALL"
	    "ER\002,i6,\002 TIMES.\002//)";
    static char fmt_1012[] = "(\002 DLOG10(X) WAS LARGER\002,i6,\002 TIMES"
	    ",\002/14x,\002 AGREED\002,i6,\002 TIMES, AND\002/10x,\002WAS SMA"
	    "LLER\002,i6,\002 TIMES.\002//)";
    static char fmt_1020[] = "(\002 THERE ARE\002,i4,\002 BASE\002,i4,\002 S"
	    "IGNIFICANT DIGITS IN A FLOATING-POINT NUMBER\002//)";
    static char fmt_1021[] = "(\002 THE MAXIMUM RELATIVE ERROR OF\002,d15.4"
	    ",\002 = \002,i4,\002 **\002,f7.2/4x,\002OCCURRED FOR X =\002,d17"
	    ".6)";
    static char fmt_1022[] = "(\002 THE ESTIMATED LOSS OF BASE\002,i4,\002 S"
	    "IGNIFICANT DIGITS IS\002,f7.2//)";
    static char fmt_1023[] = "(\002 THE ROOT MEAN SQUARE RELATIVE ERROR WA"
	    "S\002,d15.4,\002 = \002,i4,\002 **\002,f7.2)";
    static char fmt_1025[] = "(\0021SPECIAL TESTS\002//)";
    static char fmt_1030[] = "(\002 THE IDENTITY  DLOG(X) = -DLOG(1/X)  WILL"
	    " BE TESTED.\002//8x,\002X\002,9x,\002F(X) + F(1/X)\002/)";
    static char fmt_1060[] = "(d15.7,d25.17/)";
    static char fmt_1040[] = "(//\002 TEST OF SPECIAL ARGUMENTS\002//)";
    static char fmt_1041[] = "(\002 DLOG(1.0) = \002,d25.17//)";
    static char fmt_1042[] = "(\002 DLOG(XMIN) = DLOG(\002,d25.17,\002) ="
	    " \002,d25.17//)";
    static char fmt_1043[] = "(\002 DLOG(XMAX) = DLOG(\002,d25.17,\002) ="
	    " \002,d25.17//)";
    static char fmt_1050[] = "(\0021TEST OF ERROR RETURNS\002//)";
    static char fmt_1052[] = "(\002 DLOG WILL BE CALLED WITH THE ARGUMENT"
	    "\002,d15.4/\002 THIS SHOULD TRIGGER AN ERROR MESSAGE\002//)";
    static char fmt_1055[] = "(\002 DLOG RETURNED THE VALUE\002,d15.4///)";
    static char fmt_1100[] = "(\002 THIS CONCLUDES THE TESTS\002)";

    /* System generated locals */
    integer i__1;
    doublereal d__1;

    /* Builtin functions */
    double log(doublereal), d_lg10(doublereal *), d_sign(doublereal *, 
	    doublereal *), sqrt(doublereal);
    integer s_wsfe(cilist *), e_wsfe(void), do_fio(integer *, char *, ftnlen);

    /* Local variables */
    static doublereal a, b, c__;
    static integer i__, j, n;
    static doublereal w, x, y, z__;
    static integer i1, k1, k2, k3;
    static doublereal r6, r7, x1;
    static integer it;
    static doublereal xl, xn, zz, del, ait, one, eps, half, beta;
    extern doublereal dran_(integer *);
    static integer ngrd, irnd, iexp;
    static doublereal xmin, xmax, zero;
    static integer ibeta, negep;
    static doublereal eight, tenth, albeta;
    extern /* Subroutine */ int machar_(integer *, integer *, integer *, 
	    integer *, integer *, integer *, integer *, integer *, integer *, 
	    doublereal *, doublereal *, doublereal *, doublereal *);
    static integer machep;
    static doublereal epsneg;
    static integer minexp, maxexp;

    /* Fortran I/O blocks */
    static cilist io___257 = { 0, 0, 0, fmt_1000, 0 };
    static cilist io___258 = { 0, 0, 0, fmt_1001, 0 };
    static cilist io___259 = { 0, 0, 0, fmt_1005, 0 };
    static cilist io___260 = { 0, 0, 0, fmt_1002, 0 };
    static cilist io___261 = { 0, 0, 0, fmt_1009, 0 };
    static cilist io___262 = { 0, 0, 0, fmt_1010, 0 };
    static cilist io___263 = { 0, 0, 0, fmt_1011, 0 };
    static cilist io___264 = { 0, 0, 0, fmt_1012, 0 };
    static cilist io___265 = { 0, 0, 0, fmt_1020, 0 };
    static cilist io___266 = { 0, 0, 0, fmt_1021, 0 };
    static cilist io___267 = { 0, 0, 0, fmt_1022, 0 };
    static cilist io___268 = { 0, 0, 0, fmt_1023, 0 };
    static cilist io___269 = { 0, 0, 0, fmt_1022, 0 };
    static cilist io___270 = { 0, 0, 0, fmt_1025, 0 };
    static cilist io___271 = { 0, 0, 0, fmt_1030, 0 };
    static cilist io___272 = { 0, 0, 0, fmt_1060, 0 };
    static cilist io___273 = { 0, 0, 0, fmt_1040, 0 };
    static cilist io___274 = { 0, 0, 0, fmt_1041, 0 };
    static cilist io___275 = { 0, 0, 0, fmt_1042, 0 };
    static cilist io___276 = { 0, 0, 0, fmt_1043, 0 };
    static cilist io___277 = { 0, 0, 0, fmt_1050, 0 };
    static cilist io___278 = { 0, 0, 0, fmt_1052, 0 };
    static cilist io___279 = { 0, 0, 0, fmt_1055, 0 };
    static cilist io___280 = { 0, 0, 0, fmt_1052, 0 };
    static cilist io___281 = { 0, 0, 0, fmt_1055, 0 };
    static cilist io___282 = { 0, 0, 0, fmt_1100, 0 };


/*     PROGRAM TO TEST DLOG */

/*     DATA REQUIRED */

/*        NONE */

/*     SUBPROGRAMS REQUIRED FROM THIS PACKAGE */

/*        MACHAR - AN ENVIRONMENTAL INQUIRY PROGRAM PROVIDING */
/*                 INFORMATION ON THE FLOATING-POINT ARITHMETIC */
/*                 SYSTEM.  NOTE THAT THE CALL TO MACHAR CAN */
/*                 BE DELETED PROVIDED THE FOLLOWING FOUR */
/*                 PARAMETERS ARE ASSIGNED THE VALUES INDICATED */

/*                 IBETA - THE RADIX OF THE FLOATING-POINT SYSTEM */
/*                 IT    - THE NUMBER OF BASE-IBETA DIGITS IN THE */
/*                         SIGNIFICAND OF A FLOATING-POINT NUMBER */
/*                 XMIN  - THE SMALLEST NON-VANISHING FLOATING-POINT */
/*                         POWER OF THE RADIX */
/*                 XMAX  - THE LARGEST FINITE FLOATING-POINT NO. */

/*        DRAN(K) - A FUNCTION SUBPROGRAM RETURNING RANDOM DOUBLE */
/*                 PRECISION NUMBERS UNIFORMLY DISTRIBUTED OVER */
/*                 (0,1) */


/*     STANDARD FORTRAN SUBPROGRAMS REQUIRED */

/*         DABS, DLOG, DLOG10, DMAX1, DFLOAT, DSIGN, DSQRT */


/*     LATEST REVISION - DECEMBER 6, 1979 */

/*     AUTHOR - W. J. CODY */
/*              ARGONNE NATIONAL LABORATORY */



/*     IOUT = 6 */
#line 795 "talldp.f"
    machar_(&ibeta, &it, &irnd, &ngrd, &machep, &negep, &iexp, &minexp, &
	    maxexp, &eps, &epsneg, &xmin, &xmax);
#line 797 "talldp.f"
    beta = (doublereal) ((real) ibeta);
#line 798 "talldp.f"
    albeta = log(beta);
#line 799 "talldp.f"
    ait = (doublereal) ((real) it);
#line 800 "talldp.f"
    j = it / 3;
#line 801 "talldp.f"
    zero = 0.;
#line 802 "talldp.f"
    half = .5;
#line 803 "talldp.f"
    eight = 8.;
#line 804 "talldp.f"
    tenth = .1;
#line 805 "talldp.f"
    one = 1.;
#line 806 "talldp.f"
    c__ = one;

#line 808 "talldp.f"
    i__1 = j;
#line 808 "talldp.f"
    for (i__ = 1; i__ <= i__1; ++i__) {
#line 809 "talldp.f"
	c__ /= beta;
#line 810 "talldp.f"
/* L50: */
#line 810 "talldp.f"
    }

#line 812 "talldp.f"
    b = one + c__;
#line 813 "talldp.f"
    a = one - c__;
#line 814 "talldp.f"
    n = 2000;
#line 815 "talldp.f"
    xn = (doublereal) ((real) n);
#line 816 "talldp.f"
    i1 = 0;
/* ----------------------------------------------------------------- */
/*     RANDOM ARGUMENT ACCURACY TESTS */
/* ----------------------------------------------------------------- */
#line 820 "talldp.f"
    for (j = 1; j <= 4; ++j) {
#line 821 "talldp.f"
	k1 = 0;
#line 822 "talldp.f"
	k3 = 0;
#line 823 "talldp.f"
	x1 = zero;
#line 824 "talldp.f"
	r6 = zero;
#line 825 "talldp.f"
	r7 = zero;
#line 826 "talldp.f"
	del = (b - a) / xn;
#line 827 "talldp.f"
	xl = a;

#line 829 "talldp.f"
	i__1 = n;
#line 829 "talldp.f"
	for (i__ = 1; i__ <= i__1; ++i__) {
#line 830 "talldp.f"
	    x = del * dran_(&i1) + xl;
#line 831 "talldp.f"
	    if (j != 1) {
#line 831 "talldp.f"
		goto L100;
#line 831 "talldp.f"
	    }
#line 832 "talldp.f"
	    y = x - half - half;
#line 833 "talldp.f"
	    zz = log(x);
#line 834 "talldp.f"
	    z__ = one / 3.;
#line 835 "talldp.f"
	    z__ = y * (z__ - y / 4.);
#line 836 "talldp.f"
	    z__ = (z__ - half) * y * y + y;
#line 837 "talldp.f"
	    goto L150;
#line 838 "talldp.f"
L100:
#line 838 "talldp.f"
	    if (j != 2) {
#line 838 "talldp.f"
		goto L110;
#line 838 "talldp.f"
	    }
#line 839 "talldp.f"
	    x = x + eight - eight;
#line 840 "talldp.f"
	    y = x + x / 16.;
#line 841 "talldp.f"
	    z__ = log(x);
/* #          ZZ = DLOG(Y) - 7.7746816434842581D-5 */
/* #          ZZ = DLOG(Y) - (log(17/16) - 31/512) */
#line 844 "talldp.f"
	    zz = log(y) - 
		    7.77468164348425806061320404202632862024751447237708145e-5
		    ;
#line 846 "talldp.f"
	    zz += -.060546875;
#line 847 "talldp.f"
	    goto L150;
#line 848 "talldp.f"
L110:
#line 848 "talldp.f"
	    if (j != 3) {
#line 848 "talldp.f"
		goto L120;
#line 848 "talldp.f"
	    }
#line 849 "talldp.f"
	    x = x + eight - eight;
#line 850 "talldp.f"
	    y = x + x * tenth;
#line 851 "talldp.f"
	    z__ = d_lg10(&x);
/* #          ZZ = DLOG10(Y) - 3.7706015822504075D-4 */
/* #          ZZ = DLOG10(Y) - (log10(1.1) - 21/512) */
#line 854 "talldp.f"
	    zz = d_lg10(&y) - 
		    3.770601582250407501999712430242417067021904664530945966e-4
		    ;
#line 856 "talldp.f"
	    zz += -.041015625;
#line 857 "talldp.f"
	    goto L150;
#line 858 "talldp.f"
L120:
#line 858 "talldp.f"
	    z__ = log(x * x);
#line 859 "talldp.f"
	    zz = log(x);
#line 860 "talldp.f"
	    zz += zz;
#line 861 "talldp.f"
L150:
#line 861 "talldp.f"
	    w = one;
#line 862 "talldp.f"
	    if (z__ != zero) {
#line 862 "talldp.f"
		w = (z__ - zz) / z__;
#line 862 "talldp.f"
	    }
#line 863 "talldp.f"
	    z__ = d_sign(&w, &z__);
#line 864 "talldp.f"
	    if (z__ > zero) {
#line 864 "talldp.f"
		++k1;
#line 864 "talldp.f"
	    }
#line 865 "talldp.f"
	    if (z__ < zero) {
#line 865 "talldp.f"
		++k3;
#line 865 "talldp.f"
	    }
#line 866 "talldp.f"
	    w = abs(w);
#line 867 "talldp.f"
	    if (w <= r6) {
#line 867 "talldp.f"
		goto L160;
#line 867 "talldp.f"
	    }
#line 868 "talldp.f"
	    r6 = w;
#line 869 "talldp.f"
	    x1 = x;
#line 870 "talldp.f"
L160:
#line 870 "talldp.f"
	    r7 += w * w;
#line 871 "talldp.f"
	    xl += del;
#line 872 "talldp.f"
/* L200: */
#line 872 "talldp.f"
	}

#line 874 "talldp.f"
	k2 = n - k3 - k1;
#line 875 "talldp.f"
	r7 = sqrt(r7 / xn);
#line 876 "talldp.f"
	if (j == 1) {
#line 876 "talldp.f"
	    io___257.ciunit = *iout;
#line 876 "talldp.f"
	    s_wsfe(&io___257);
#line 876 "talldp.f"
	    e_wsfe();
#line 876 "talldp.f"
	}
#line 877 "talldp.f"
	if (j == 2) {
#line 877 "talldp.f"
	    io___258.ciunit = *iout;
#line 877 "talldp.f"
	    s_wsfe(&io___258);
#line 877 "talldp.f"
	    e_wsfe();
#line 877 "talldp.f"
	}
#line 878 "talldp.f"
	if (j == 3) {
#line 878 "talldp.f"
	    io___259.ciunit = *iout;
#line 878 "talldp.f"
	    s_wsfe(&io___259);
#line 878 "talldp.f"
	    e_wsfe();
#line 878 "talldp.f"
	}
#line 879 "talldp.f"
	if (j == 4) {
#line 879 "talldp.f"
	    io___260.ciunit = *iout;
#line 879 "talldp.f"
	    s_wsfe(&io___260);
#line 879 "talldp.f"
	    e_wsfe();
#line 879 "talldp.f"
	}
#line 880 "talldp.f"
	if (j == 1) {
#line 880 "talldp.f"
	    io___261.ciunit = *iout;
#line 880 "talldp.f"
	    s_wsfe(&io___261);
#line 880 "talldp.f"
	    do_fio(&c__1, (char *)&n, (ftnlen)sizeof(integer));
#line 880 "talldp.f"
	    do_fio(&c__1, (char *)&c__, (ftnlen)sizeof(doublereal));
#line 880 "talldp.f"
	    e_wsfe();
#line 880 "talldp.f"
	}
#line 881 "talldp.f"
	if (j != 1) {
#line 881 "talldp.f"
	    io___262.ciunit = *iout;
#line 881 "talldp.f"
	    s_wsfe(&io___262);
#line 881 "talldp.f"
	    do_fio(&c__1, (char *)&n, (ftnlen)sizeof(integer));
#line 881 "talldp.f"
	    do_fio(&c__1, (char *)&a, (ftnlen)sizeof(doublereal));
#line 881 "talldp.f"
	    do_fio(&c__1, (char *)&b, (ftnlen)sizeof(doublereal));
#line 881 "talldp.f"
	    e_wsfe();
#line 881 "talldp.f"
	}
#line 882 "talldp.f"
	if (j != 3) {
#line 882 "talldp.f"
	    io___263.ciunit = *iout;
#line 882 "talldp.f"
	    s_wsfe(&io___263);
#line 882 "talldp.f"
	    do_fio(&c__1, (char *)&k1, (ftnlen)sizeof(integer));
#line 882 "talldp.f"
	    do_fio(&c__1, (char *)&k2, (ftnlen)sizeof(integer));
#line 882 "talldp.f"
	    do_fio(&c__1, (char *)&k3, (ftnlen)sizeof(integer));
#line 882 "talldp.f"
	    e_wsfe();
#line 882 "talldp.f"
	}
#line 883 "talldp.f"
	if (j == 3) {
#line 883 "talldp.f"
	    io___264.ciunit = *iout;
#line 883 "talldp.f"
	    s_wsfe(&io___264);
#line 883 "talldp.f"
	    do_fio(&c__1, (char *)&k1, (ftnlen)sizeof(integer));
#line 883 "talldp.f"
	    do_fio(&c__1, (char *)&k2, (ftnlen)sizeof(integer));
#line 883 "talldp.f"
	    do_fio(&c__1, (char *)&k3, (ftnlen)sizeof(integer));
#line 883 "talldp.f"
	    e_wsfe();
#line 883 "talldp.f"
	}
#line 884 "talldp.f"
	io___265.ciunit = *iout;
#line 884 "talldp.f"
	s_wsfe(&io___265);
#line 884 "talldp.f"
	do_fio(&c__1, (char *)&it, (ftnlen)sizeof(integer));
#line 884 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 884 "talldp.f"
	e_wsfe();
#line 885 "talldp.f"
	w = -999.;
#line 886 "talldp.f"
	if (r6 != zero) {
#line 886 "talldp.f"
	    w = log((abs(r6))) / albeta;
#line 886 "talldp.f"
	}
#line 887 "talldp.f"
	io___266.ciunit = *iout;
#line 887 "talldp.f"
	s_wsfe(&io___266);
#line 887 "talldp.f"
	do_fio(&c__1, (char *)&r6, (ftnlen)sizeof(doublereal));
#line 887 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 887 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 887 "talldp.f"
	do_fio(&c__1, (char *)&x1, (ftnlen)sizeof(doublereal));
#line 887 "talldp.f"
	e_wsfe();
/* Computing MAX */
#line 888 "talldp.f"
	d__1 = ait + w;
#line 888 "talldp.f"
	w = max(d__1,zero);
#line 889 "talldp.f"
	io___267.ciunit = *iout;
#line 889 "talldp.f"
	s_wsfe(&io___267);
#line 889 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 889 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 889 "talldp.f"
	e_wsfe();
#line 890 "talldp.f"
	w = -999.;
#line 891 "talldp.f"
	if (r7 != zero) {
#line 891 "talldp.f"
	    w = log((abs(r7))) / albeta;
#line 891 "talldp.f"
	}
#line 892 "talldp.f"
	io___268.ciunit = *iout;
#line 892 "talldp.f"
	s_wsfe(&io___268);
#line 892 "talldp.f"
	do_fio(&c__1, (char *)&r7, (ftnlen)sizeof(doublereal));
#line 892 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 892 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 892 "talldp.f"
	e_wsfe();
/* Computing MAX */
#line 893 "talldp.f"
	d__1 = ait + w;
#line 893 "talldp.f"
	w = max(d__1,zero);
#line 894 "talldp.f"
	io___269.ciunit = *iout;
#line 894 "talldp.f"
	s_wsfe(&io___269);
#line 894 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 894 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 894 "talldp.f"
	e_wsfe();
#line 895 "talldp.f"
	if (j > 1) {
#line 895 "talldp.f"
	    goto L230;
#line 895 "talldp.f"
	}
#line 896 "talldp.f"
	a = sqrt(half);
#line 897 "talldp.f"
	b = .9375;
#line 898 "talldp.f"
	goto L300;
#line 899 "talldp.f"
L230:
#line 899 "talldp.f"
	if (j > 2) {
#line 899 "talldp.f"
	    goto L240;
#line 899 "talldp.f"
	}
#line 900 "talldp.f"
	a = sqrt(tenth);
#line 901 "talldp.f"
	b = .9;
#line 902 "talldp.f"
	goto L300;
#line 903 "talldp.f"
L240:
#line 903 "talldp.f"
	a = 16.;
#line 904 "talldp.f"
	b = 240.;
#line 905 "talldp.f"
L300:
#line 905 "talldp.f"
	;
#line 905 "talldp.f"
    }
/* ----------------------------------------------------------------- */
/*     SPECIAL TESTS */
/* ----------------------------------------------------------------- */
#line 909 "talldp.f"
    io___270.ciunit = *iout;
#line 909 "talldp.f"
    s_wsfe(&io___270);
#line 909 "talldp.f"
    e_wsfe();
#line 910 "talldp.f"
    io___271.ciunit = *iout;
#line 910 "talldp.f"
    s_wsfe(&io___271);
#line 910 "talldp.f"
    e_wsfe();

#line 912 "talldp.f"
    for (i__ = 1; i__ <= 5; ++i__) {
#line 913 "talldp.f"
	x = dran_(&i1);
#line 914 "talldp.f"
	x = x + x + 15.;
#line 915 "talldp.f"
	y = one / x;
#line 916 "talldp.f"
	z__ = log(x) + log(y);
#line 917 "talldp.f"
	io___272.ciunit = *iout;
#line 917 "talldp.f"
	s_wsfe(&io___272);
#line 917 "talldp.f"
	do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 917 "talldp.f"
	do_fio(&c__1, (char *)&z__, (ftnlen)sizeof(doublereal));
#line 917 "talldp.f"
	e_wsfe();
#line 918 "talldp.f"
/* L320: */
#line 918 "talldp.f"
    }

#line 920 "talldp.f"
    io___273.ciunit = *iout;
#line 920 "talldp.f"
    s_wsfe(&io___273);
#line 920 "talldp.f"
    e_wsfe();
#line 921 "talldp.f"
    x = one;
#line 922 "talldp.f"
    y = log(x);
#line 923 "talldp.f"
    io___274.ciunit = *iout;
#line 923 "talldp.f"
    s_wsfe(&io___274);
#line 923 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 923 "talldp.f"
    e_wsfe();
#line 924 "talldp.f"
    x = xmin;
#line 925 "talldp.f"
    y = log(x);
#line 926 "talldp.f"
    io___275.ciunit = *iout;
#line 926 "talldp.f"
    s_wsfe(&io___275);
#line 926 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 926 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 926 "talldp.f"
    e_wsfe();
#line 927 "talldp.f"
    x = xmax;
#line 928 "talldp.f"
    y = log(x);
#line 929 "talldp.f"
    io___276.ciunit = *iout;
#line 929 "talldp.f"
    s_wsfe(&io___276);
#line 929 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 929 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 929 "talldp.f"
    e_wsfe();
/* ----------------------------------------------------------------- */
/*     TEST OF ERROR RETURNS */
/* ----------------------------------------------------------------- */
#line 933 "talldp.f"
    io___277.ciunit = *iout;
#line 933 "talldp.f"
    s_wsfe(&io___277);
#line 933 "talldp.f"
    e_wsfe();
#line 934 "talldp.f"
    x = -2.;
#line 935 "talldp.f"
    io___278.ciunit = *iout;
#line 935 "talldp.f"
    s_wsfe(&io___278);
#line 935 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 935 "talldp.f"
    e_wsfe();
#line 936 "talldp.f"
    y = log(x);
#line 937 "talldp.f"
    io___279.ciunit = *iout;
#line 937 "talldp.f"
    s_wsfe(&io___279);
#line 937 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 937 "talldp.f"
    e_wsfe();
#line 938 "talldp.f"
    x = zero;
#line 939 "talldp.f"
    io___280.ciunit = *iout;
#line 939 "talldp.f"
    s_wsfe(&io___280);
#line 939 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 939 "talldp.f"
    e_wsfe();
#line 940 "talldp.f"
    y = log(x);
#line 941 "talldp.f"
    io___281.ciunit = *iout;
#line 941 "talldp.f"
    s_wsfe(&io___281);
#line 941 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 941 "talldp.f"
    e_wsfe();
#line 942 "talldp.f"
    io___282.ciunit = *iout;
#line 942 "talldp.f"
    s_wsfe(&io___282);
#line 942 "talldp.f"
    e_wsfe();
#line 943 "talldp.f"
    return 0;
/*     ---------- LAST CARD OF DLOG/DLOG10 TEST PROGRAM ---------- */
} /* tdlog_ */

/* Subroutine */ int tpower_(integer *iout)
{
    /* Format strings */
    static char fmt_1000[] = "(\0021TEST OF X**1.0 VS X\002//)";
    static char fmt_1010[] = "(i7,\002 RANDOM ARGUMENTS WERE TESTED FROM THE"
	    " INTERVAL\002/6x,\002(\002,d15.4,\002,\002,d15.4,\002)\002//)";
    static char fmt_1011[] = "(\002 X**1.0 WAS LARGER\002,i6,\002 TIMES,\002"
	    "/11x,\002 AGREED\002,i6,\002 TIMES, AND\002/7x,\002WAS SMALLE"
	    "R\002,i6,\002 TIMES.\002//)";
    static char fmt_1001[] = "(\0021TEST OF XSQ**1.5 VS XSQ*X\002//)";
    static char fmt_1012[] = "(\002 X**1.5 WAS LARGER\002,i6,\002 TIMES,\002"
	    "/11x,\002 AGREED\002,i6,\002 TIMES, AND\002/7x,\002WAS SMALLE"
	    "R\002,i6,\002 TIMES.\002//)";
    static char fmt_1002[] = "(\0021TEST OF X**Y VS XSQ**(Y/2)\002//)";
    static char fmt_1014[] = "(i7,\002 RANDOM ARGUMENTS WERE TESTED FROM THE"
	    " REGION\002/6x,\002X IN (\002,d15.4,\002,\002,d15.4,\002), Y IN ("
	    "\002,d15.4,\002,\002,d15.4,\002)\002//)";
    static char fmt_1013[] = "(\002  X**Y  WAS LARGER\002,i6,\002 TIMES,\002"
	    "/11x,\002 AGREED\002,i6,\002 TIMES, AND\002/7x,\002WAS SMALLE"
	    "R\002,i6,\002 TIMES.\002//)";
    static char fmt_1020[] = "(\002 THERE ARE\002,i4,\002 BASE\002,i4,\002 S"
	    "IGNIFICANT DIGITS IN A FLOATING-POINT NUMBER\002//)";
    static char fmt_1021[] = "(\002 THE MAXIMUM RELATIVE ERROR OF\002,d15.4"
	    ",\002 = \002,i4,\002 **\002,f7.2/4x,\002OCCURRED FOR X =\002,d17"
	    ".6)";
    static char fmt_1024[] = "(\002 THE MAXIMUM RELATIVE ERROR OF\002,d15.4"
	    ",\002 = \002,i4,\002 **\002,f7.2/4x,\002OCCURRED FOR X =\002,d17"
	    ".6,\002 Y =\002,d17.6)";
    static char fmt_1022[] = "(\002 THE ESTIMATED LOSS OF BASE\002,i4,\002 S"
	    "IGNIFICANT DIGITS IS\002,f7.2//)";
    static char fmt_1023[] = "(\002 THE ROOT MEAN SQUARE RELATIVE ERROR WA"
	    "S\002,d15.4,\002 = \002,i4,\002 **\002,f7.2)";
    static char fmt_1025[] = "(\0021SPECIAL TESTS\002//)";
    static char fmt_1030[] = "(\002 THE IDENTITY  X ** Y = (1/X) ** (-Y)  WI"
	    "LL BE TESTED.\002//8x,\002X\002,14x,\002Y\002,9x,\002(X**Y-(1/X)"
	    "**(-Y) / X**Y\002/)";
    static char fmt_1060[] = "(2d15.7,6x,d15.7/)";
    static char fmt_1050[] = "(\0021TEST OF ERROR RETURNS\002//)";
    static char fmt_1051[] = "(\002 (\002,d14.7,\002 ) ** (\002,d14.7,\002 )"
	    " WILL BE COMPUTED.\002/\002 THIS SHOULD NOT TRIGGER AN ERROR MES"
	    "SAGE\002//)";
    static char fmt_1055[] = "(\002 THE VALUE RETURNED IS\002,d15.4///)";
    static char fmt_1052[] = "(\002 (\002,d14.7,\002 ) ** (\002,d14.7,\002 )"
	    " WILL BE COMPUTED.\002/\002 THIS SHOULD TRIGGER AN ERROR MESSAG"
	    "E\002//)";
    static char fmt_1100[] = "(\002 THIS CONCLUDES THE TESTS\002)";

    /* System generated locals */
    integer i__1;
    doublereal d__1, d__2;

    /* Builtin functions */
    double log(doublereal), pow_dd(doublereal *, doublereal *), sqrt(
	    doublereal);
    integer s_wsfe(cilist *), e_wsfe(void), do_fio(integer *, char *, ftnlen);
    double exp(doublereal);

    /* Local variables */
    static doublereal a, b, c__;
    static integer i__, j, n;
    static doublereal w, x, y, z__;
    static integer i1, k1, k2, k3;
    static doublereal r6, r7, x1, y1, y2;
    static integer it;
    static doublereal xl, xn, zz, del, ait, one, eps, two, xsq, beta;
    extern doublereal dran_(integer *);
    static integer ngrd, irnd;
    static doublereal dely;
    static integer iexp;
    static doublereal xmin, xmax, zero, onep5;
    static integer ibeta;
    static doublereal scale;
    static integer negep;
    extern doublereal store_(doublereal *);
    static doublereal albeta;
    extern /* Subroutine */ int machar_(integer *, integer *, integer *, 
	    integer *, integer *, integer *, integer *, integer *, integer *, 
	    doublereal *, doublereal *, doublereal *, doublereal *);
    static integer machep;
    static doublereal epsneg, alxmax;
    static integer minexp, maxexp;

    /* Fortran I/O blocks */
    static cilist io___330 = { 0, 0, 0, fmt_1000, 0 };
    static cilist io___331 = { 0, 0, 0, fmt_1010, 0 };
    static cilist io___332 = { 0, 0, 0, fmt_1011, 0 };
    static cilist io___333 = { 0, 0, 0, fmt_1001, 0 };
    static cilist io___334 = { 0, 0, 0, fmt_1010, 0 };
    static cilist io___335 = { 0, 0, 0, fmt_1012, 0 };
    static cilist io___336 = { 0, 0, 0, fmt_1002, 0 };
    static cilist io___337 = { 0, 0, 0, fmt_1014, 0 };
    static cilist io___338 = { 0, 0, 0, fmt_1013, 0 };
    static cilist io___339 = { 0, 0, 0, fmt_1020, 0 };
    static cilist io___340 = { 0, 0, 0, fmt_1021, 0 };
    static cilist io___341 = { 0, 0, 0, fmt_1024, 0 };
    static cilist io___342 = { 0, 0, 0, fmt_1022, 0 };
    static cilist io___343 = { 0, 0, 0, fmt_1023, 0 };
    static cilist io___344 = { 0, 0, 0, fmt_1022, 0 };
    static cilist io___345 = { 0, 0, 0, fmt_1025, 0 };
    static cilist io___346 = { 0, 0, 0, fmt_1030, 0 };
    static cilist io___347 = { 0, 0, 0, fmt_1060, 0 };
    static cilist io___348 = { 0, 0, 0, fmt_1050, 0 };
    static cilist io___349 = { 0, 0, 0, fmt_1051, 0 };
    static cilist io___350 = { 0, 0, 0, fmt_1055, 0 };
    static cilist io___351 = { 0, 0, 0, fmt_1051, 0 };
    static cilist io___352 = { 0, 0, 0, fmt_1055, 0 };
    static cilist io___353 = { 0, 0, 0, fmt_1051, 0 };
    static cilist io___354 = { 0, 0, 0, fmt_1055, 0 };
    static cilist io___355 = { 0, 0, 0, fmt_1052, 0 };
    static cilist io___356 = { 0, 0, 0, fmt_1055, 0 };
    static cilist io___357 = { 0, 0, 0, fmt_1052, 0 };
    static cilist io___358 = { 0, 0, 0, fmt_1055, 0 };
    static cilist io___359 = { 0, 0, 0, fmt_1052, 0 };
    static cilist io___360 = { 0, 0, 0, fmt_1055, 0 };
    static cilist io___361 = { 0, 0, 0, fmt_1100, 0 };


/*     PROGRAM TO TEST POWER FUNCTION (**) */

/*     DATA REQUIRED */

/*        NONE */

/*     SUBPROGRAMS REQUIRED FROM THIS PACKAGE */

/*        MACHAR - AN ENVIRONMENTAL INQUIRY PROGRAM PROVIDING */
/*                 INFORMATION ON THE FLOATING-POINT ARITHMETIC */
/*                 SYSTEM.  NOTE THAT THE CALL TO MACHAR CAN */
/*                 BE DELETED PROVIDED THE FOLLOWING SIX */
/*                 PARAMETERS ARE ASSIGNED THE VALUES INDICATED */

/*                 IBETA  - THE RADIX OF THE FLOATING-POINT SYSTEM */
/*                 IT     - THE NUMBER OF BASE-IBETA DIGITS IN THE */
/*                          SIGNIFICAND OF A FLOATING-POINT NUMBER */
/*                 MINEXP - THE LARGEST IN MAGNITUDE NEGATIVE */
/*                          INTEGER SUCH THAT  DFLOAT(IBETA)**MINEXP */
/*                          IS A POSITIVE FLOATING-POINT NUMBER */
/*                 MAXEXP - THE LARGEST POSITIVE INTEGER EXPONENT */
/*                          FOR A FINITE FLOATING-POINT NUMBER */
/*                 XMIN   - THE SMALLEST NON-VANISHING FLOATING-POINT */
/*                          POWER OF THE RADIX */
/*                 XMAX   - THE LARGEST FINITE FLOATING-POINT */
/*                          NUMBER */

/*        DRAN(K) - A FUNCTION SUBPROGRAM RETURNING RANDOM DOUBLE */
/*                 PRECISION NUMBERS UNIFORMLY DISTRIBUTED OVER */
/*                 (0,1) */


/*     STANDARD FORTRAN SUBPROGRAMS REQUIRED */

/*         DABS, DLOG, DMAX1, DEXP, DFLOAT, DSQRT */


/*     LATEST REVISION - DECEMBER 6, 1979 */

/*     AUTHOR - W. J. CODY */
/*              ARGONNE NATIONAL LABORATORY */



/*     IOUT = 6 */
#line 1033 "talldp.f"
    machar_(&ibeta, &it, &irnd, &ngrd, &machep, &negep, &iexp, &minexp, &
	    maxexp, &eps, &epsneg, &xmin, &xmax);
#line 1035 "talldp.f"
    beta = (doublereal) ((real) ibeta);
#line 1036 "talldp.f"
    albeta = log(beta);
#line 1037 "talldp.f"
    ait = (doublereal) ((real) it);
#line 1038 "talldp.f"
    alxmax = log(xmax);
#line 1039 "talldp.f"
    zero = 0.;
#line 1040 "talldp.f"
    one = 1.;
#line 1041 "talldp.f"
    two = one + one;
#line 1042 "talldp.f"
    onep5 = (two + one) / two;
#line 1043 "talldp.f"
    scale = one;
#line 1044 "talldp.f"
    j = (it + 1) / 2;

#line 1046 "talldp.f"
    i__1 = j;
#line 1046 "talldp.f"
    for (i__ = 1; i__ <= i__1; ++i__) {
#line 1047 "talldp.f"
	scale *= beta;
#line 1048 "talldp.f"
/* L20: */
#line 1048 "talldp.f"
    }

#line 1050 "talldp.f"
    a = one / beta;
#line 1051 "talldp.f"
    b = one;
/* Computing MAX */
#line 1052 "talldp.f"
    d__1 = alxmax, d__2 = -log(xmin);
#line 1052 "talldp.f"
    c__ = -max(d__1,d__2) / log(100.);
#line 1053 "talldp.f"
    dely = -c__ - c__;
#line 1054 "talldp.f"
    n = 2000;
#line 1055 "talldp.f"
    xn = (doublereal) ((real) n);
#line 1056 "talldp.f"
    i1 = 0;
#line 1057 "talldp.f"
    y1 = zero;
/* ----------------------------------------------------------------- */
/*     RANDOM ARGUMENT ACCURACY TESTS */
/* ----------------------------------------------------------------- */
#line 1061 "talldp.f"
    for (j = 1; j <= 4; ++j) {
#line 1062 "talldp.f"
	k1 = 0;
#line 1063 "talldp.f"
	k3 = 0;
#line 1064 "talldp.f"
	x1 = zero;
#line 1065 "talldp.f"
	r6 = zero;
#line 1066 "talldp.f"
	r7 = zero;
#line 1067 "talldp.f"
	del = (b - a) / xn;
#line 1068 "talldp.f"
	xl = a;

#line 1070 "talldp.f"
	i__1 = n;
#line 1070 "talldp.f"
	for (i__ = 1; i__ <= i__1; ++i__) {
#line 1071 "talldp.f"
	    x = del * dran_(&i1) + xl;
#line 1072 "talldp.f"
	    if (j != 1) {
#line 1072 "talldp.f"
		goto L50;
#line 1072 "talldp.f"
	    }
#line 1073 "talldp.f"
	    zz = pow_dd(&x, &one);
#line 1074 "talldp.f"
	    z__ = x;
#line 1075 "talldp.f"
	    goto L110;
#line 1076 "talldp.f"
L50:
#line 1076 "talldp.f"
	    d__1 = scale * x;
#line 1076 "talldp.f"
	    w = store_(&d__1);
#line 1077 "talldp.f"
	    d__2 = x + w;
#line 1077 "talldp.f"
	    d__1 = store_(&d__2) - w;
#line 1077 "talldp.f"
	    x = store_(&d__1);
#line 1078 "talldp.f"
	    xsq = x * x;
#line 1079 "talldp.f"
	    if (j == 4) {
#line 1079 "talldp.f"
		goto L70;
#line 1079 "talldp.f"
	    }
#line 1080 "talldp.f"
	    zz = pow_dd(&xsq, &onep5);
#line 1081 "talldp.f"
	    z__ = x * xsq;
#line 1082 "talldp.f"
	    goto L110;
#line 1083 "talldp.f"
L70:
#line 1083 "talldp.f"
	    y = dely * dran_(&i1) + c__;
#line 1084 "talldp.f"
	    y2 = y / two + y - y;
#line 1085 "talldp.f"
	    y = y2 + y2;
#line 1086 "talldp.f"
	    z__ = pow_dd(&x, &y);
#line 1087 "talldp.f"
	    zz = pow_dd(&xsq, &y2);
#line 1088 "talldp.f"
L110:
#line 1088 "talldp.f"
	    w = one;
#line 1089 "talldp.f"
	    if (z__ != zero) {
#line 1089 "talldp.f"
		w = (z__ - zz) / z__;
#line 1089 "talldp.f"
	    }
#line 1090 "talldp.f"
	    if (w > zero) {
#line 1090 "talldp.f"
		++k1;
#line 1090 "talldp.f"
	    }
#line 1091 "talldp.f"
	    if (w < zero) {
#line 1091 "talldp.f"
		++k3;
#line 1091 "talldp.f"
	    }
#line 1092 "talldp.f"
	    w = abs(w);
#line 1093 "talldp.f"
	    if (w <= r6) {
#line 1093 "talldp.f"
		goto L120;
#line 1093 "talldp.f"
	    }
#line 1094 "talldp.f"
	    r6 = w;
#line 1095 "talldp.f"
	    x1 = x;
#line 1096 "talldp.f"
	    if (j == 4) {
#line 1096 "talldp.f"
		y1 = y;
#line 1096 "talldp.f"
	    }
#line 1097 "talldp.f"
L120:
#line 1097 "talldp.f"
	    r7 += w * w;
#line 1098 "talldp.f"
	    xl += del;
#line 1099 "talldp.f"
/* L200: */
#line 1099 "talldp.f"
	}

#line 1101 "talldp.f"
	k2 = n - k3 - k1;
#line 1102 "talldp.f"
	r7 = sqrt(r7 / xn);
#line 1103 "talldp.f"
	if (j > 1) {
#line 1103 "talldp.f"
	    goto L210;
#line 1103 "talldp.f"
	}
#line 1104 "talldp.f"
	io___330.ciunit = *iout;
#line 1104 "talldp.f"
	s_wsfe(&io___330);
#line 1104 "talldp.f"
	e_wsfe();
#line 1105 "talldp.f"
	io___331.ciunit = *iout;
#line 1105 "talldp.f"
	s_wsfe(&io___331);
#line 1105 "talldp.f"
	do_fio(&c__1, (char *)&n, (ftnlen)sizeof(integer));
#line 1105 "talldp.f"
	do_fio(&c__1, (char *)&a, (ftnlen)sizeof(doublereal));
#line 1105 "talldp.f"
	do_fio(&c__1, (char *)&b, (ftnlen)sizeof(doublereal));
#line 1105 "talldp.f"
	e_wsfe();
#line 1106 "talldp.f"
	io___332.ciunit = *iout;
#line 1106 "talldp.f"
	s_wsfe(&io___332);
#line 1106 "talldp.f"
	do_fio(&c__1, (char *)&k1, (ftnlen)sizeof(integer));
#line 1106 "talldp.f"
	do_fio(&c__1, (char *)&k2, (ftnlen)sizeof(integer));
#line 1106 "talldp.f"
	do_fio(&c__1, (char *)&k3, (ftnlen)sizeof(integer));
#line 1106 "talldp.f"
	e_wsfe();
#line 1107 "talldp.f"
	goto L220;
#line 1108 "talldp.f"
L210:
#line 1108 "talldp.f"
	if (j == 4) {
#line 1108 "talldp.f"
	    goto L215;
#line 1108 "talldp.f"
	}
#line 1109 "talldp.f"
	io___333.ciunit = *iout;
#line 1109 "talldp.f"
	s_wsfe(&io___333);
#line 1109 "talldp.f"
	e_wsfe();
#line 1110 "talldp.f"
	io___334.ciunit = *iout;
#line 1110 "talldp.f"
	s_wsfe(&io___334);
#line 1110 "talldp.f"
	do_fio(&c__1, (char *)&n, (ftnlen)sizeof(integer));
#line 1110 "talldp.f"
	do_fio(&c__1, (char *)&a, (ftnlen)sizeof(doublereal));
#line 1110 "talldp.f"
	do_fio(&c__1, (char *)&b, (ftnlen)sizeof(doublereal));
#line 1110 "talldp.f"
	e_wsfe();
#line 1111 "talldp.f"
	io___335.ciunit = *iout;
#line 1111 "talldp.f"
	s_wsfe(&io___335);
#line 1111 "talldp.f"
	do_fio(&c__1, (char *)&k1, (ftnlen)sizeof(integer));
#line 1111 "talldp.f"
	do_fio(&c__1, (char *)&k2, (ftnlen)sizeof(integer));
#line 1111 "talldp.f"
	do_fio(&c__1, (char *)&k3, (ftnlen)sizeof(integer));
#line 1111 "talldp.f"
	e_wsfe();
#line 1112 "talldp.f"
	goto L220;
#line 1113 "talldp.f"
L215:
#line 1113 "talldp.f"
	io___336.ciunit = *iout;
#line 1113 "talldp.f"
	s_wsfe(&io___336);
#line 1113 "talldp.f"
	e_wsfe();
#line 1114 "talldp.f"
	w = c__ + dely;
#line 1115 "talldp.f"
	io___337.ciunit = *iout;
#line 1115 "talldp.f"
	s_wsfe(&io___337);
#line 1115 "talldp.f"
	do_fio(&c__1, (char *)&n, (ftnlen)sizeof(integer));
#line 1115 "talldp.f"
	do_fio(&c__1, (char *)&a, (ftnlen)sizeof(doublereal));
#line 1115 "talldp.f"
	do_fio(&c__1, (char *)&b, (ftnlen)sizeof(doublereal));
#line 1115 "talldp.f"
	do_fio(&c__1, (char *)&c__, (ftnlen)sizeof(doublereal));
#line 1115 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 1115 "talldp.f"
	e_wsfe();
#line 1116 "talldp.f"
	io___338.ciunit = *iout;
#line 1116 "talldp.f"
	s_wsfe(&io___338);
#line 1116 "talldp.f"
	do_fio(&c__1, (char *)&k1, (ftnlen)sizeof(integer));
#line 1116 "talldp.f"
	do_fio(&c__1, (char *)&k2, (ftnlen)sizeof(integer));
#line 1116 "talldp.f"
	do_fio(&c__1, (char *)&k3, (ftnlen)sizeof(integer));
#line 1116 "talldp.f"
	e_wsfe();
#line 1117 "talldp.f"
L220:
#line 1117 "talldp.f"
	io___339.ciunit = *iout;
#line 1117 "talldp.f"
	s_wsfe(&io___339);
#line 1117 "talldp.f"
	do_fio(&c__1, (char *)&it, (ftnlen)sizeof(integer));
#line 1117 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 1117 "talldp.f"
	e_wsfe();
#line 1118 "talldp.f"
	w = -999.;
#line 1119 "talldp.f"
	if (r6 != zero) {
#line 1119 "talldp.f"
	    w = log((abs(r6))) / albeta;
#line 1119 "talldp.f"
	}
#line 1120 "talldp.f"
	if (j != 4) {
#line 1120 "talldp.f"
	    io___340.ciunit = *iout;
#line 1120 "talldp.f"
	    s_wsfe(&io___340);
#line 1120 "talldp.f"
	    do_fio(&c__1, (char *)&r6, (ftnlen)sizeof(doublereal));
#line 1120 "talldp.f"
	    do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 1120 "talldp.f"
	    do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 1120 "talldp.f"
	    do_fio(&c__1, (char *)&x1, (ftnlen)sizeof(doublereal));
#line 1120 "talldp.f"
	    e_wsfe();
#line 1120 "talldp.f"
	}
#line 1121 "talldp.f"
	if (j == 4) {
#line 1121 "talldp.f"
	    io___341.ciunit = *iout;
#line 1121 "talldp.f"
	    s_wsfe(&io___341);
#line 1121 "talldp.f"
	    do_fio(&c__1, (char *)&r6, (ftnlen)sizeof(doublereal));
#line 1121 "talldp.f"
	    do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 1121 "talldp.f"
	    do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 1121 "talldp.f"
	    do_fio(&c__1, (char *)&x1, (ftnlen)sizeof(doublereal));
#line 1121 "talldp.f"
	    do_fio(&c__1, (char *)&y1, (ftnlen)sizeof(doublereal));
#line 1121 "talldp.f"
	    e_wsfe();
#line 1121 "talldp.f"
	}
/* Computing MAX */
#line 1122 "talldp.f"
	d__1 = ait + w;
#line 1122 "talldp.f"
	w = max(d__1,zero);
#line 1123 "talldp.f"
	io___342.ciunit = *iout;
#line 1123 "talldp.f"
	s_wsfe(&io___342);
#line 1123 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 1123 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 1123 "talldp.f"
	e_wsfe();
#line 1124 "talldp.f"
	w = -999.;
#line 1125 "talldp.f"
	if (r7 != zero) {
#line 1125 "talldp.f"
	    w = log((abs(r7))) / albeta;
#line 1125 "talldp.f"
	}
#line 1126 "talldp.f"
	io___343.ciunit = *iout;
#line 1126 "talldp.f"
	s_wsfe(&io___343);
#line 1126 "talldp.f"
	do_fio(&c__1, (char *)&r7, (ftnlen)sizeof(doublereal));
#line 1126 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 1126 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 1126 "talldp.f"
	e_wsfe();
/* Computing MAX */
#line 1127 "talldp.f"
	d__1 = ait + w;
#line 1127 "talldp.f"
	w = max(d__1,zero);
#line 1128 "talldp.f"
	io___344.ciunit = *iout;
#line 1128 "talldp.f"
	s_wsfe(&io___344);
#line 1128 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 1128 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 1128 "talldp.f"
	e_wsfe();
#line 1129 "talldp.f"
	if (j == 1) {
#line 1129 "talldp.f"
	    goto L300;
#line 1129 "talldp.f"
	}
#line 1130 "talldp.f"
	b = 10.;
#line 1131 "talldp.f"
	a = .01;
#line 1132 "talldp.f"
	if (j == 3) {
#line 1132 "talldp.f"
	    goto L300;
#line 1132 "talldp.f"
	}
#line 1133 "talldp.f"
	a = one;
#line 1134 "talldp.f"
	b = exp(alxmax / 3.);
#line 1135 "talldp.f"
L300:
#line 1135 "talldp.f"
	;
#line 1135 "talldp.f"
    }
/* ----------------------------------------------------------------- */
/*     SPECIAL TESTS */
/* ----------------------------------------------------------------- */
#line 1139 "talldp.f"
    io___345.ciunit = *iout;
#line 1139 "talldp.f"
    s_wsfe(&io___345);
#line 1139 "talldp.f"
    e_wsfe();
#line 1140 "talldp.f"
    io___346.ciunit = *iout;
#line 1140 "talldp.f"
    s_wsfe(&io___346);
#line 1140 "talldp.f"
    e_wsfe();
#line 1141 "talldp.f"
    b = 10.;

#line 1143 "talldp.f"
    for (i__ = 1; i__ <= 5; ++i__) {
#line 1144 "talldp.f"
	x = dran_(&i1) * b + one;
#line 1145 "talldp.f"
	y = dran_(&i1) * b + one;
#line 1146 "talldp.f"
	z__ = pow_dd(&x, &y);
#line 1147 "talldp.f"
	d__1 = one / x;
#line 1147 "talldp.f"
	d__2 = -y;
#line 1147 "talldp.f"
	zz = pow_dd(&d__1, &d__2);
#line 1148 "talldp.f"
	w = (z__ - zz) / z__;
#line 1149 "talldp.f"
	io___347.ciunit = *iout;
#line 1149 "talldp.f"
	s_wsfe(&io___347);
#line 1149 "talldp.f"
	do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 1149 "talldp.f"
	do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 1149 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 1149 "talldp.f"
	e_wsfe();
#line 1150 "talldp.f"
/* L320: */
#line 1150 "talldp.f"
    }
/* ----------------------------------------------------------------- */
/*     TEST OF ERROR RETURNS */
/* ----------------------------------------------------------------- */
#line 1154 "talldp.f"
    io___348.ciunit = *iout;
#line 1154 "talldp.f"
    s_wsfe(&io___348);
#line 1154 "talldp.f"
    e_wsfe();
#line 1155 "talldp.f"
    x = beta;
#line 1156 "talldp.f"
    y = (doublereal) ((real) minexp);
#line 1157 "talldp.f"
    io___349.ciunit = *iout;
#line 1157 "talldp.f"
    s_wsfe(&io___349);
#line 1157 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 1157 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 1157 "talldp.f"
    e_wsfe();
#line 1158 "talldp.f"
    z__ = pow_dd(&x, &y);
#line 1159 "talldp.f"
    io___350.ciunit = *iout;
#line 1159 "talldp.f"
    s_wsfe(&io___350);
#line 1159 "talldp.f"
    do_fio(&c__1, (char *)&z__, (ftnlen)sizeof(doublereal));
#line 1159 "talldp.f"
    e_wsfe();
#line 1160 "talldp.f"
    y = (doublereal) ((real) (maxexp - 1));
#line 1161 "talldp.f"
    io___351.ciunit = *iout;
#line 1161 "talldp.f"
    s_wsfe(&io___351);
#line 1161 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 1161 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 1161 "talldp.f"
    e_wsfe();
#line 1162 "talldp.f"
    z__ = pow_dd(&x, &y);
#line 1163 "talldp.f"
    io___352.ciunit = *iout;
#line 1163 "talldp.f"
    s_wsfe(&io___352);
#line 1163 "talldp.f"
    do_fio(&c__1, (char *)&z__, (ftnlen)sizeof(doublereal));
#line 1163 "talldp.f"
    e_wsfe();
#line 1164 "talldp.f"
    x = zero;
#line 1165 "talldp.f"
    y = two;
#line 1166 "talldp.f"
    io___353.ciunit = *iout;
#line 1166 "talldp.f"
    s_wsfe(&io___353);
#line 1166 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 1166 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 1166 "talldp.f"
    e_wsfe();
#line 1167 "talldp.f"
    z__ = pow_dd(&x, &y);
#line 1168 "talldp.f"
    io___354.ciunit = *iout;
#line 1168 "talldp.f"
    s_wsfe(&io___354);
#line 1168 "talldp.f"
    do_fio(&c__1, (char *)&z__, (ftnlen)sizeof(doublereal));
#line 1168 "talldp.f"
    e_wsfe();
#line 1169 "talldp.f"
    x = -y;
#line 1170 "talldp.f"
    y = zero;
#line 1171 "talldp.f"
    io___355.ciunit = *iout;
#line 1171 "talldp.f"
    s_wsfe(&io___355);
#line 1171 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 1171 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 1171 "talldp.f"
    e_wsfe();
#line 1172 "talldp.f"
    z__ = pow_dd(&x, &y);
#line 1173 "talldp.f"
    io___356.ciunit = *iout;
#line 1173 "talldp.f"
    s_wsfe(&io___356);
#line 1173 "talldp.f"
    do_fio(&c__1, (char *)&z__, (ftnlen)sizeof(doublereal));
#line 1173 "talldp.f"
    e_wsfe();
#line 1174 "talldp.f"
    y = two;
#line 1175 "talldp.f"
    io___357.ciunit = *iout;
#line 1175 "talldp.f"
    s_wsfe(&io___357);
#line 1175 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 1175 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 1175 "talldp.f"
    e_wsfe();
#line 1176 "talldp.f"
    z__ = pow_dd(&x, &y);
#line 1177 "talldp.f"
    io___358.ciunit = *iout;
#line 1177 "talldp.f"
    s_wsfe(&io___358);
#line 1177 "talldp.f"
    do_fio(&c__1, (char *)&z__, (ftnlen)sizeof(doublereal));
#line 1177 "talldp.f"
    e_wsfe();
#line 1178 "talldp.f"
    x = zero;
#line 1179 "talldp.f"
    y = zero;
#line 1180 "talldp.f"
    io___359.ciunit = *iout;
#line 1180 "talldp.f"
    s_wsfe(&io___359);
#line 1180 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 1180 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 1180 "talldp.f"
    e_wsfe();
#line 1181 "talldp.f"
    z__ = pow_dd(&x, &y);
#line 1182 "talldp.f"
    io___360.ciunit = *iout;
#line 1182 "talldp.f"
    s_wsfe(&io___360);
#line 1182 "talldp.f"
    do_fio(&c__1, (char *)&z__, (ftnlen)sizeof(doublereal));
#line 1182 "talldp.f"
    e_wsfe();
#line 1183 "talldp.f"
    io___361.ciunit = *iout;
#line 1183 "talldp.f"
    s_wsfe(&io___361);
#line 1183 "talldp.f"
    e_wsfe();
#line 1184 "talldp.f"
    return 0;
/*     ---------- LAST CARD OF POWER TEST PROGRAM ---------- */
} /* tpower_ */

/* Subroutine */ int tdsin_(integer *iout)
{
    /* Format strings */
    static char fmt_1000[] = "(\0021TEST OF DSIN(X) VS 3*DSIN(X/3)-4*DSIN(X/"
	    "3)**3  \002//)";
    static char fmt_1010[] = "(i7,\002 RANDOM ARGUMENTS WERE TESTED FROM THE"
	    " INTERVAL\002/6x,\002(\002,d15.4,\002,\002,d15.4,\002)\002//)";
    static char fmt_1011[] = "(\002 DSIN(X) WAS LARGER\002,i6,\002 TIMES,"
	    "\002/11x,\002 AGREED\002,i6,\002 TIMES, AND\002/7x,\002WAS SMALL"
	    "ER\002,i6,\002 TIMES.\002//)";
    static char fmt_1005[] = "(\0021TEST OF DCOS(X) VS 4*DCOS(X/3)**3-3*DCOS"
	    "(X/3)  \002//)";
    static char fmt_1012[] = "(\002 DCOS(X) WAS LARGER\002,i6,\002 TIMES,"
	    "\002/11x,\002 AGREED\002,i6,\002 TIMES, AND\002/7x,\002WAS SMALL"
	    "ER\002,i6,\002 TIMES.\002//)";
    static char fmt_1020[] = "(\002 THERE ARE\002,i4,\002 BASE\002,i4,\002 S"
	    "IGNIFICANT DIGITS IN A FLOATING-POINT NUMBER\002//)";
    static char fmt_1021[] = "(\002 THE MAXIMUM RELATIVE ERROR OF\002,d15.4"
	    ",\002 = \002,i4,\002 **\002,f7.2/4x,\002OCCURRED FOR X =\002,d17"
	    ".6)";
    static char fmt_1022[] = "(\002 THE ESTIMATED LOSS OF BASE\002,i4,\002 S"
	    "IGNIFICANT DIGITS IS\002,f7.2//)";
    static char fmt_1023[] = "(\002 THE ROOT MEAN SQUARE RELATIVE ERROR WA"
	    "S\002,d15.4,\002 = \002,i4,\002 **\002,f7.2)";
    static char fmt_1025[] = "(\0021SPECIAL TESTS\002//)";
    static char fmt_1026[] = "(\002 IF \002,d13.6,\002 IS NOT ALMOST 1.0D+"
	    "00,\002,4x,\002DSIN HAS THE WRONG PERIOD.  \002//)";
    static char fmt_1030[] = "(\002 THE IDENTITY   DSIN(-X) = -DSIN(X)   WIL"
	    "L BE TESTED.\002//8x,\002X\002,9x,\002F(X) + F(-X)\002/)";
    static char fmt_1060[] = "(d15.7,d25.17/)";
    static char fmt_1031[] = "(\002 THE IDENTITY DSIN(X) = X , X SMALL, WILL"
	    " BE TESTED.\002//8x,\002X\002,9x,\002X - F(X)\002/)";
    static char fmt_1032[] = "(\002 THE IDENTITY   DCOS(-X) = DCOS(X)   WILL"
	    " BE TESTED.\002//8x,\002X\002,9x,\002F(X) - F(-X)\002/)";
    static char fmt_1035[] = "(\002 TEST OF UNDERFLOW FOR VERY SMALL ARGUMEN"
	    "T.\002)";
    static char fmt_1061[] = "(/6x,\002 DSIN(\002,d23.16,\002) =\002,d23.16)";
    static char fmt_1040[] = "(\002 THE FOLLOWING THREE LINES ILLUSTRATE THE"
	    " LOSS IN\002,\002 SIGNIFICANCE\002/\002 FOR LARGE ARGUMENTS.  TH"
	    "E ARGUMENTS\002,\002 ARE CONSECUTIVE.\002)";
    static char fmt_1050[] = "(\0021TEST OF ERROR RETURNS\002//)";
    static char fmt_1052[] = "(\002 DSIN WILL BE CALLED WITH THE ARGUMENT"
	    "\002,d15.4/\002 THIS SHOULD TRIGGER AN ERROR MESSAGE\002//)";
    static char fmt_1055[] = "(\002 DSIN RETURNED THE VALUE\002,d15.4///)";
    static char fmt_1100[] = "(\002 THIS CONCLUDES THE TESTS\002)";

    /* System generated locals */
    integer i__1;
    doublereal d__1;

    /* Builtin functions */
    double log(doublereal), sin(doublereal), cos(doublereal), sqrt(doublereal)
	    ;
    integer s_wsfe(cilist *), e_wsfe(void), do_fio(integer *, char *, ftnlen);
    double pow_di(doublereal *, integer *), pow_dd(doublereal *, doublereal *)
	    ;

    /* Local variables */
    static doublereal a, b, c__;
    static integer i__, j, n;
    static doublereal w, x, y, z__;
    static integer i1, k1, k2, k3;
    static doublereal r6, r7, x1;
    static integer it;
    static doublereal xl, xn, zz, del, ait, one, eps, beta;
    extern doublereal dran_(integer *);
    static integer ngrd, irnd, iexp;
    static doublereal xmin, xmax, zero;
    static integer ibeta;
    static doublereal betap;
    static integer negep;
    static doublereal three, expon, albeta;
    extern /* Subroutine */ int machar_(integer *, integer *, integer *, 
	    integer *, integer *, integer *, integer *, integer *, integer *, 
	    doublereal *, doublereal *, doublereal *, doublereal *);
    static integer machep;
    static doublereal epsneg;
    static integer minexp, maxexp;

    /* Fortran I/O blocks */
    static cilist io___402 = { 0, 0, 0, fmt_1000, 0 };
    static cilist io___403 = { 0, 0, 0, fmt_1010, 0 };
    static cilist io___404 = { 0, 0, 0, fmt_1011, 0 };
    static cilist io___405 = { 0, 0, 0, fmt_1005, 0 };
    static cilist io___406 = { 0, 0, 0, fmt_1010, 0 };
    static cilist io___407 = { 0, 0, 0, fmt_1012, 0 };
    static cilist io___408 = { 0, 0, 0, fmt_1020, 0 };
    static cilist io___409 = { 0, 0, 0, fmt_1021, 0 };
    static cilist io___410 = { 0, 0, 0, fmt_1022, 0 };
    static cilist io___411 = { 0, 0, 0, fmt_1023, 0 };
    static cilist io___412 = { 0, 0, 0, fmt_1022, 0 };
    static cilist io___413 = { 0, 0, 0, fmt_1025, 0 };
    static cilist io___414 = { 0, 0, 0, fmt_1026, 0 };
    static cilist io___415 = { 0, 0, 0, fmt_1030, 0 };
    static cilist io___416 = { 0, 0, 0, fmt_1060, 0 };
    static cilist io___417 = { 0, 0, 0, fmt_1031, 0 };
    static cilist io___419 = { 0, 0, 0, fmt_1060, 0 };
    static cilist io___420 = { 0, 0, 0, fmt_1032, 0 };
    static cilist io___421 = { 0, 0, 0, fmt_1060, 0 };
    static cilist io___422 = { 0, 0, 0, fmt_1035, 0 };
    static cilist io___424 = { 0, 0, 0, fmt_1061, 0 };
    static cilist io___425 = { 0, 0, 0, fmt_1040, 0 };
    static cilist io___426 = { 0, 0, 0, fmt_1061, 0 };
    static cilist io___427 = { 0, 0, 0, fmt_1061, 0 };
    static cilist io___428 = { 0, 0, 0, fmt_1061, 0 };
    static cilist io___429 = { 0, 0, 0, fmt_1050, 0 };
    static cilist io___430 = { 0, 0, 0, fmt_1052, 0 };
    static cilist io___431 = { 0, 0, 0, fmt_1055, 0 };
    static cilist io___432 = { 0, 0, 0, fmt_1100, 0 };


/*     PROGRAM TO TEST DSIN/DCOS */

/*     DATA REQUIRED */

/*        NONE */

/*     SUBPROGRAMS REQUIRED FROM THIS PACKAGE */

/*        MACHAR - AN ENVIRONMENTAL INQUIRY PROGRAM PROVIDING */
/*                 INFORMATION ON THE FLOATING-POINT ARITHMETIC */
/*                 SYSTEM.  NOTE THAT THE CALL TO MACHAR CAN */
/*                 BE DELETED PROVIDED THE FOLLOWING FIVE */
/*                 PARAMETERS ARE ASSIGNED THE VALUES INDICATED */

/*                 IBETA  - THE RADIX OF THE FLOATING-POINT SYSTEM */
/*                 IT     - THE NUMBER OF BASE-IBETA DIGITS IN THE */
/*                          SIGNIFICAND OF A FLOATING-POINT NUMBER */
/*                 MINEXP - THE LARGEST IN MAGNITUDE NEGATIVE */
/*                          INTEGER SUCH THAT  DFLOAT(IBETA)**MINEXP */
/*                          IS A POSITIVE FLOATING-POINT NUMBER */
/*                 EPS    - THE SMALLEST POSITIVE FLOATING-POINT */
/*                          NUMBER SUCH THAT 1.0+EPS .NE. 1.0 */
/*                 EPSNEG - THE SMALLEST POSITIVE FLOATING-POINT */
/*                          NUMBER SUCH THAT 1.0-EPSNEG .NE. 1.0 */

/*        DRAN(K) - A FUNCTION SUBPROGRAM RETURNING RANDOM DOUBLE */
/*                 PRECISION NUMBERS UNIFORMLY DISTRIBUTED OVER */
/*                 (0,1) */


/*     STANDARD FORTRAN SUBPROGRAMS REQUIRED */

/*         DABS, DLOG, DMAX1, DCOS, DFLOAT, DSIN, DSQRT */


/*     LATEST REVISION - DECEMBER 6, 1979 */

/*     AUTHOR - W. J. CODY */
/*              ARGONNE NATIONAL LABORATORY */



/*     IOUT = 6 */
#line 1272 "talldp.f"
    machar_(&ibeta, &it, &irnd, &ngrd, &machep, &negep, &iexp, &minexp, &
	    maxexp, &eps, &epsneg, &xmin, &xmax);
#line 1274 "talldp.f"
    beta = (doublereal) ((real) ibeta);
#line 1275 "talldp.f"
    albeta = log(beta);
#line 1276 "talldp.f"
    ait = (doublereal) ((real) it);
#line 1277 "talldp.f"
    one = 1.;
#line 1278 "talldp.f"
    zero = 0.;
#line 1279 "talldp.f"
    three = 3.;
#line 1280 "talldp.f"
    a = zero;
/* #    B = 1.570796327D+00 */
/* #    B = PI/2 */
#line 1283 "talldp.f"
    b = 1.57079632679489661923132169163975144209858469968755291;
#line 1284 "talldp.f"
    c__ = b;
#line 1285 "talldp.f"
    n = 2000;
#line 1286 "talldp.f"
    xn = (doublereal) ((real) n);
#line 1287 "talldp.f"
    i1 = 0;
/* ----------------------------------------------------------------- */
/*     RANDOM ARGUMENT ACCURACY TESTS */
/* ----------------------------------------------------------------- */
#line 1291 "talldp.f"
    for (j = 1; j <= 3; ++j) {
#line 1292 "talldp.f"
	k1 = 0;
#line 1293 "talldp.f"
	k3 = 0;
#line 1294 "talldp.f"
	x1 = zero;
#line 1295 "talldp.f"
	r6 = zero;
#line 1296 "talldp.f"
	r7 = zero;
#line 1297 "talldp.f"
	del = (b - a) / xn;
#line 1298 "talldp.f"
	xl = a;

#line 1300 "talldp.f"
	i__1 = n;
#line 1300 "talldp.f"
	for (i__ = 1; i__ <= i__1; ++i__) {
#line 1301 "talldp.f"
	    x = del * dran_(&i1) + xl;
#line 1302 "talldp.f"
	    y = x / three;
#line 1303 "talldp.f"
	    y = x + y - x;
#line 1304 "talldp.f"
	    x = three * y;
#line 1305 "talldp.f"
	    if (j == 3) {
#line 1305 "talldp.f"
		goto L100;
#line 1305 "talldp.f"
	    }
#line 1306 "talldp.f"
	    z__ = sin(x);
#line 1307 "talldp.f"
	    zz = sin(y);
#line 1308 "talldp.f"
	    w = one;
#line 1309 "talldp.f"
	    if (z__ != zero) {
#line 1309 "talldp.f"
		w = (z__ - zz * (three - zz * 4. * zz)) / z__;
#line 1309 "talldp.f"
	    }
#line 1310 "talldp.f"
	    goto L110;
#line 1311 "talldp.f"
L100:
#line 1311 "talldp.f"
	    z__ = cos(x);
#line 1312 "talldp.f"
	    zz = cos(y);
#line 1313 "talldp.f"
	    w = one;
#line 1314 "talldp.f"
	    if (z__ != zero) {
#line 1314 "talldp.f"
		w = (z__ + zz * (three - zz * 4. * zz)) / z__;
#line 1314 "talldp.f"
	    }
#line 1315 "talldp.f"
L110:
#line 1315 "talldp.f"
	    if (w > zero) {
#line 1315 "talldp.f"
		++k1;
#line 1315 "talldp.f"
	    }
#line 1316 "talldp.f"
	    if (w < zero) {
#line 1316 "talldp.f"
		++k3;
#line 1316 "talldp.f"
	    }
#line 1317 "talldp.f"
	    w = abs(w);
#line 1318 "talldp.f"
	    if (w <= r6) {
#line 1318 "talldp.f"
		goto L120;
#line 1318 "talldp.f"
	    }
#line 1319 "talldp.f"
	    r6 = w;
#line 1320 "talldp.f"
	    x1 = x;
#line 1321 "talldp.f"
L120:
#line 1321 "talldp.f"
	    r7 += w * w;
#line 1322 "talldp.f"
	    xl += del;
#line 1323 "talldp.f"
/* L200: */
#line 1323 "talldp.f"
	}

#line 1325 "talldp.f"
	k2 = n - k3 - k1;
#line 1326 "talldp.f"
	r7 = sqrt(r7 / xn);
#line 1327 "talldp.f"
	if (j == 3) {
#line 1327 "talldp.f"
	    goto L210;
#line 1327 "talldp.f"
	}
#line 1328 "talldp.f"
	io___402.ciunit = *iout;
#line 1328 "talldp.f"
	s_wsfe(&io___402);
#line 1328 "talldp.f"
	e_wsfe();
#line 1329 "talldp.f"
	io___403.ciunit = *iout;
#line 1329 "talldp.f"
	s_wsfe(&io___403);
#line 1329 "talldp.f"
	do_fio(&c__1, (char *)&n, (ftnlen)sizeof(integer));
#line 1329 "talldp.f"
	do_fio(&c__1, (char *)&a, (ftnlen)sizeof(doublereal));
#line 1329 "talldp.f"
	do_fio(&c__1, (char *)&b, (ftnlen)sizeof(doublereal));
#line 1329 "talldp.f"
	e_wsfe();
#line 1330 "talldp.f"
	io___404.ciunit = *iout;
#line 1330 "talldp.f"
	s_wsfe(&io___404);
#line 1330 "talldp.f"
	do_fio(&c__1, (char *)&k1, (ftnlen)sizeof(integer));
#line 1330 "talldp.f"
	do_fio(&c__1, (char *)&k2, (ftnlen)sizeof(integer));
#line 1330 "talldp.f"
	do_fio(&c__1, (char *)&k3, (ftnlen)sizeof(integer));
#line 1330 "talldp.f"
	e_wsfe();
#line 1331 "talldp.f"
	goto L220;
#line 1332 "talldp.f"
L210:
#line 1332 "talldp.f"
	io___405.ciunit = *iout;
#line 1332 "talldp.f"
	s_wsfe(&io___405);
#line 1332 "talldp.f"
	e_wsfe();
#line 1333 "talldp.f"
	io___406.ciunit = *iout;
#line 1333 "talldp.f"
	s_wsfe(&io___406);
#line 1333 "talldp.f"
	do_fio(&c__1, (char *)&n, (ftnlen)sizeof(integer));
#line 1333 "talldp.f"
	do_fio(&c__1, (char *)&a, (ftnlen)sizeof(doublereal));
#line 1333 "talldp.f"
	do_fio(&c__1, (char *)&b, (ftnlen)sizeof(doublereal));
#line 1333 "talldp.f"
	e_wsfe();
#line 1334 "talldp.f"
	io___407.ciunit = *iout;
#line 1334 "talldp.f"
	s_wsfe(&io___407);
#line 1334 "talldp.f"
	do_fio(&c__1, (char *)&k1, (ftnlen)sizeof(integer));
#line 1334 "talldp.f"
	do_fio(&c__1, (char *)&k2, (ftnlen)sizeof(integer));
#line 1334 "talldp.f"
	do_fio(&c__1, (char *)&k3, (ftnlen)sizeof(integer));
#line 1334 "talldp.f"
	e_wsfe();
#line 1335 "talldp.f"
L220:
#line 1335 "talldp.f"
	io___408.ciunit = *iout;
#line 1335 "talldp.f"
	s_wsfe(&io___408);
#line 1335 "talldp.f"
	do_fio(&c__1, (char *)&it, (ftnlen)sizeof(integer));
#line 1335 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 1335 "talldp.f"
	e_wsfe();
#line 1336 "talldp.f"
	w = -999.;
#line 1337 "talldp.f"
	if (r6 != zero) {
#line 1337 "talldp.f"
	    w = log((abs(r6))) / albeta;
#line 1337 "talldp.f"
	}
#line 1338 "talldp.f"
	io___409.ciunit = *iout;
#line 1338 "talldp.f"
	s_wsfe(&io___409);
#line 1338 "talldp.f"
	do_fio(&c__1, (char *)&r6, (ftnlen)sizeof(doublereal));
#line 1338 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 1338 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 1338 "talldp.f"
	do_fio(&c__1, (char *)&x1, (ftnlen)sizeof(doublereal));
#line 1338 "talldp.f"
	e_wsfe();
/* Computing MAX */
#line 1339 "talldp.f"
	d__1 = ait + w;
#line 1339 "talldp.f"
	w = max(d__1,zero);
#line 1340 "talldp.f"
	io___410.ciunit = *iout;
#line 1340 "talldp.f"
	s_wsfe(&io___410);
#line 1340 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 1340 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 1340 "talldp.f"
	e_wsfe();
#line 1341 "talldp.f"
	w = -999.;
#line 1342 "talldp.f"
	if (r7 != zero) {
#line 1342 "talldp.f"
	    w = log((abs(r7))) / albeta;
#line 1342 "talldp.f"
	}
#line 1343 "talldp.f"
	io___411.ciunit = *iout;
#line 1343 "talldp.f"
	s_wsfe(&io___411);
#line 1343 "talldp.f"
	do_fio(&c__1, (char *)&r7, (ftnlen)sizeof(doublereal));
#line 1343 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 1343 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 1343 "talldp.f"
	e_wsfe();
/* Computing MAX */
#line 1344 "talldp.f"
	d__1 = ait + w;
#line 1344 "talldp.f"
	w = max(d__1,zero);
#line 1345 "talldp.f"
	io___412.ciunit = *iout;
#line 1345 "talldp.f"
	s_wsfe(&io___412);
#line 1345 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 1345 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 1345 "talldp.f"
	e_wsfe();
/* #       A = 18.84955592D+00 */
/* #       A = 6*PI */
#line 1348 "talldp.f"
	a = 18.84955592153875943077586029967701730518301639625063493;
#line 1350 "talldp.f"
	if (j == 2) {
#line 1350 "talldp.f"
	    a = b + c__;
#line 1350 "talldp.f"
	}
#line 1351 "talldp.f"
	b = a + c__;
#line 1352 "talldp.f"
/* L300: */
#line 1352 "talldp.f"
    }
/* ----------------------------------------------------------------- */
/*     SPECIAL TESTS */
/* ----------------------------------------------------------------- */
#line 1356 "talldp.f"
    io___413.ciunit = *iout;
#line 1356 "talldp.f"
    s_wsfe(&io___413);
#line 1356 "talldp.f"
    e_wsfe();
#line 1357 "talldp.f"
    i__1 = it / 2;
#line 1357 "talldp.f"
    c__ = one / pow_di(&beta, &i__1);
#line 1358 "talldp.f"
    z__ = (sin(a + c__) - sin(a - c__)) / (c__ + c__);
#line 1359 "talldp.f"
    io___414.ciunit = *iout;
#line 1359 "talldp.f"
    s_wsfe(&io___414);
#line 1359 "talldp.f"
    do_fio(&c__1, (char *)&z__, (ftnlen)sizeof(doublereal));
#line 1359 "talldp.f"
    e_wsfe();

#line 1361 "talldp.f"
    io___415.ciunit = *iout;
#line 1361 "talldp.f"
    s_wsfe(&io___415);
#line 1361 "talldp.f"
    e_wsfe();

#line 1363 "talldp.f"
    for (i__ = 1; i__ <= 5; ++i__) {
#line 1364 "talldp.f"
	x = dran_(&i1) * a;
#line 1365 "talldp.f"
	z__ = sin(x) + sin(-x);
#line 1366 "talldp.f"
	io___416.ciunit = *iout;
#line 1366 "talldp.f"
	s_wsfe(&io___416);
#line 1366 "talldp.f"
	do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 1366 "talldp.f"
	do_fio(&c__1, (char *)&z__, (ftnlen)sizeof(doublereal));
#line 1366 "talldp.f"
	e_wsfe();
#line 1367 "talldp.f"
/* L320: */
#line 1367 "talldp.f"
    }

#line 1369 "talldp.f"
    io___417.ciunit = *iout;
#line 1369 "talldp.f"
    s_wsfe(&io___417);
#line 1369 "talldp.f"
    e_wsfe();
#line 1370 "talldp.f"
    betap = pow_di(&beta, &it);
#line 1371 "talldp.f"
    x = dran_(&i1) / betap;

#line 1373 "talldp.f"
    for (i__ = 1; i__ <= 5; ++i__) {
#line 1374 "talldp.f"
	z__ = x - sin(x);
#line 1375 "talldp.f"
	io___419.ciunit = *iout;
#line 1375 "talldp.f"
	s_wsfe(&io___419);
#line 1375 "talldp.f"
	do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 1375 "talldp.f"
	do_fio(&c__1, (char *)&z__, (ftnlen)sizeof(doublereal));
#line 1375 "talldp.f"
	e_wsfe();
#line 1376 "talldp.f"
	x /= beta;
#line 1377 "talldp.f"
/* L330: */
#line 1377 "talldp.f"
    }

#line 1379 "talldp.f"
    io___420.ciunit = *iout;
#line 1379 "talldp.f"
    s_wsfe(&io___420);
#line 1379 "talldp.f"
    e_wsfe();

#line 1381 "talldp.f"
    for (i__ = 1; i__ <= 5; ++i__) {
#line 1382 "talldp.f"
	x = dran_(&i1) * a;
#line 1383 "talldp.f"
	z__ = cos(x) - cos(-x);
#line 1384 "talldp.f"
	io___421.ciunit = *iout;
#line 1384 "talldp.f"
	s_wsfe(&io___421);
#line 1384 "talldp.f"
	do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 1384 "talldp.f"
	do_fio(&c__1, (char *)&z__, (ftnlen)sizeof(doublereal));
#line 1384 "talldp.f"
	e_wsfe();
#line 1385 "talldp.f"
/* L340: */
#line 1385 "talldp.f"
    }

#line 1387 "talldp.f"
    io___422.ciunit = *iout;
#line 1387 "talldp.f"
    s_wsfe(&io___422);
#line 1387 "talldp.f"
    e_wsfe();
#line 1388 "talldp.f"
    expon = (doublereal) ((real) minexp) * .75;
#line 1389 "talldp.f"
    x = pow_dd(&beta, &expon);
#line 1390 "talldp.f"
    y = sin(x);
#line 1391 "talldp.f"
    io___424.ciunit = *iout;
#line 1391 "talldp.f"
    s_wsfe(&io___424);
#line 1391 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 1391 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 1391 "talldp.f"
    e_wsfe();
#line 1392 "talldp.f"
    io___425.ciunit = *iout;
#line 1392 "talldp.f"
    s_wsfe(&io___425);
#line 1392 "talldp.f"
    e_wsfe();
#line 1393 "talldp.f"
    z__ = sqrt(betap);
#line 1394 "talldp.f"
    x = z__ * (one - epsneg);
#line 1395 "talldp.f"
    y = sin(x);
#line 1396 "talldp.f"
    io___426.ciunit = *iout;
#line 1396 "talldp.f"
    s_wsfe(&io___426);
#line 1396 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 1396 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 1396 "talldp.f"
    e_wsfe();
#line 1397 "talldp.f"
    y = sin(z__);
#line 1398 "talldp.f"
    io___427.ciunit = *iout;
#line 1398 "talldp.f"
    s_wsfe(&io___427);
#line 1398 "talldp.f"
    do_fio(&c__1, (char *)&z__, (ftnlen)sizeof(doublereal));
#line 1398 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 1398 "talldp.f"
    e_wsfe();
#line 1399 "talldp.f"
    x = z__ * (one + eps);
#line 1400 "talldp.f"
    y = sin(x);
#line 1401 "talldp.f"
    io___428.ciunit = *iout;
#line 1401 "talldp.f"
    s_wsfe(&io___428);
#line 1401 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 1401 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 1401 "talldp.f"
    e_wsfe();
/* ----------------------------------------------------------------- */
/*     TEST OF ERROR RETURNS */
/* ----------------------------------------------------------------- */
#line 1405 "talldp.f"
    io___429.ciunit = *iout;
#line 1405 "talldp.f"
    s_wsfe(&io___429);
#line 1405 "talldp.f"
    e_wsfe();
#line 1406 "talldp.f"
    x = betap;
#line 1407 "talldp.f"
    io___430.ciunit = *iout;
#line 1407 "talldp.f"
    s_wsfe(&io___430);
#line 1407 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 1407 "talldp.f"
    e_wsfe();
#line 1408 "talldp.f"
    y = sin(x);
#line 1409 "talldp.f"
    io___431.ciunit = *iout;
#line 1409 "talldp.f"
    s_wsfe(&io___431);
#line 1409 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 1409 "talldp.f"
    e_wsfe();
#line 1410 "talldp.f"
    io___432.ciunit = *iout;
#line 1410 "talldp.f"
    s_wsfe(&io___432);
#line 1410 "talldp.f"
    e_wsfe();
#line 1411 "talldp.f"
    return 0;
/*     ---------- LAST CARD OF DSIN/DCOS TEST PROGRAM ---------- */
} /* tdsin_ */

/* Subroutine */ int tdsinh_(integer *iout)
{
    /* Format strings */
    static char fmt_1000[] = "(\0021TEST OF DSINH(X) VS T.S. EXPANSION OF DS"
	    "INH(X) \002//)";
    static char fmt_1005[] = "(\0021TEST OF DCOSH(X) VS T.S. EXPANSION OF DC"
	    "OSH(X) \002//)";
    static char fmt_1001[] = "(\0021TEST OF DSINH(X) VS C*(DSINH(X+1)+DSINH("
	    "X-1))   \002//)";
    static char fmt_1006[] = "(\0021TEST OF DCOSH(X) VS C*(DCOSH(X+1)+DCOSH("
	    "X-1))   \002//)";
    static char fmt_1010[] = "(i7,\002 RANDOM ARGUMENTS WERE TESTED FROM THE"
	    " INTERVAL\002/6x,\002(\002,d15.4,\002,\002,d15.4,\002)\002//)";
    static char fmt_1011[] = "(\002 DSINH(X) WAS LARGER\002,i6,\002 TIMES"
	    ",\002/13x,\002 AGREED\002,i6,\002 TIMES, AND\002/9x,\002WAS SMAL"
	    "LER\002,i6,\002 TIMES.\002//)";
    static char fmt_1012[] = "(\002 DCOSH(X) WAS LARGER\002,i6,\002 TIMES"
	    ",\002/12x,\002 AGREED\002,i6,\002 TIMES, AND\002/8x,\002WAS SMAL"
	    "LER\002,i6,\002 TIMES.\002//)";
    static char fmt_1020[] = "(\002 THERE ARE\002,i4,\002 BASE\002,i4,\002 S"
	    "IGNIFICANT DIGITS IN A FLOATING-POINT NUMBER\002//)";
    static char fmt_1021[] = "(\002 THE MAXIMUM RELATIVE ERROR OF\002,d15.4"
	    ",\002 = \002,i4,\002 **\002,f7.2/4x,\002OCCURRED FOR X =\002,d17"
	    ".6)";
    static char fmt_1022[] = "(\002 THE ESTIMATED LOSS OF BASE\002,i4,\002 S"
	    "IGNIFICANT DIGITS IS\002,f7.2//)";
    static char fmt_1023[] = "(\002 THE ROOT MEAN SQUARE RELATIVE ERROR WA"
	    "S\002,d15.4,\002 = \002,i4,\002 **\002,f7.2)";
    static char fmt_1025[] = "(\0021SPECIAL TESTS\002//)";
    static char fmt_1030[] = "(\002 THE IDENTITY  DSINH(-X) = -DSINH(X)  WIL"
	    "L BE TESTED.\002//8x,\002X\002,9x,\002F(X) + F(-X)\002/)";
    static char fmt_1060[] = "(d15.7,d25.17/)";
    static char fmt_1031[] = "(\002 THE IDENTITY DSINH(X) = X , X SMALL, WIL"
	    "L BE TESTED.\002//8x,\002X\002,9x,\002X - F(X)\002/)";
    static char fmt_1032[] = "(\002 THE IDENTITY  DCOSH(-X) = DCOSH(X)  WILL"
	    " BE TESTED.\002//8x,\002X\002,9x,\002F(X) - F(-X)\002/)";
    static char fmt_1035[] = "(\002 TEST OF UNDERFLOW FOR VERY SMALL ARGUMEN"
	    "T.\002/)";
    static char fmt_1061[] = "(6x,\002 DSINH(\002,d13.6,\002) =\002,d13.6/)";
    static char fmt_1050[] = "(\0021TEST OF ERROR RETURNS\002//)";
    static char fmt_1051[] = "(\002 DSINH WILL BE CALLED WITH THE ARGUMEN"
	    "T\002,d15.4/\002 THIS SHOULD NOT TRIGGER AN ERROR MESSAGE\002//)";
    static char fmt_1055[] = "(\002 DSINH RETURNED THE VALUE\002,d15.4///)";
    static char fmt_1052[] = "(\0020DSINH WILL BE CALLED WITH THE ARGUMEN"
	    "T\002,d15.4/\002 THIS SHOULD TRIGGER AN ERROR MESSAGE\002//)";
    static char fmt_1100[] = "(\002 THIS CONCLUDES THE TESTS\002)";

    /* System generated locals */
    integer i__1, i__2;
    doublereal d__1;

    /* Builtin functions */
    double log(doublereal), sinh(doublereal), cosh(doublereal), sqrt(
	    doublereal);
    integer s_wsfe(cilist *), e_wsfe(void), do_fio(integer *, char *, ftnlen);
    double pow_di(doublereal *, integer *), pow_dd(doublereal *, doublereal *)
	    ;

    /* Local variables */
    static doublereal a, b, c__;
    static integer i__, j, n;
    static doublereal w, x, y, z__, c0;
    static integer i1, i2, k1, k2, k3;
    static doublereal r6, r7, x1;
    static integer ii, it;
    static doublereal xl, xn, zz, del, den, ait, one, eps;
    static integer nit;
    static doublereal xsq, aind, beta;
    extern doublereal dran_(integer *);
    static doublereal five;
    static integer ngrd, irnd, iexp;
    static doublereal xmin, xmax, zero;
    static integer ibeta;
    static doublereal betap;
    static integer negep;
    static doublereal three, albeta;
    extern /* Subroutine */ int machar_(integer *, integer *, integer *, 
	    integer *, integer *, integer *, integer *, integer *, integer *, 
	    doublereal *, doublereal *, doublereal *, doublereal *);
    static integer machep;
    static doublereal epsneg, alxmax;
    static integer minexp, maxexp;

    /* Fortran I/O blocks */
    static cilist io___482 = { 0, 0, 0, fmt_1000, 0 };
    static cilist io___483 = { 0, 0, 0, fmt_1005, 0 };
    static cilist io___484 = { 0, 0, 0, fmt_1001, 0 };
    static cilist io___485 = { 0, 0, 0, fmt_1006, 0 };
    static cilist io___486 = { 0, 0, 0, fmt_1010, 0 };
    static cilist io___487 = { 0, 0, 0, fmt_1011, 0 };
    static cilist io___488 = { 0, 0, 0, fmt_1012, 0 };
    static cilist io___489 = { 0, 0, 0, fmt_1020, 0 };
    static cilist io___490 = { 0, 0, 0, fmt_1021, 0 };
    static cilist io___491 = { 0, 0, 0, fmt_1022, 0 };
    static cilist io___492 = { 0, 0, 0, fmt_1023, 0 };
    static cilist io___493 = { 0, 0, 0, fmt_1022, 0 };
    static cilist io___494 = { 0, 0, 0, fmt_1025, 0 };
    static cilist io___495 = { 0, 0, 0, fmt_1030, 0 };
    static cilist io___496 = { 0, 0, 0, fmt_1060, 0 };
    static cilist io___497 = { 0, 0, 0, fmt_1031, 0 };
    static cilist io___499 = { 0, 0, 0, fmt_1060, 0 };
    static cilist io___500 = { 0, 0, 0, fmt_1032, 0 };
    static cilist io___501 = { 0, 0, 0, fmt_1060, 0 };
    static cilist io___502 = { 0, 0, 0, fmt_1035, 0 };
    static cilist io___503 = { 0, 0, 0, fmt_1061, 0 };
    static cilist io___504 = { 0, 0, 0, fmt_1050, 0 };
    static cilist io___505 = { 0, 0, 0, fmt_1051, 0 };
    static cilist io___506 = { 0, 0, 0, fmt_1055, 0 };
    static cilist io___507 = { 0, 0, 0, fmt_1052, 0 };
    static cilist io___508 = { 0, 0, 0, fmt_1055, 0 };
    static cilist io___509 = { 0, 0, 0, fmt_1100, 0 };


/*     PROGRAM TO TEST DSINH/DCOSH */

/*     DATA REQUIRED */

/*        NONE */

/*     SUBPROGRAMS REQUIRED FROM THIS PACKAGE */

/*        MACHAR - AN ENVIRONMENTAL INQUIRY PROGRAM PROVIDING */
/*                 INFORMATION ON THE FLOATING-POINT ARITHMETIC */
/*                 SYSTEM.  NOTE THAT THE CALL TO MACHAR CAN */
/*                 BE DELETED PROVIDED THE FOLLOWING SIX */
/*                 PARAMETERS ARE ASSIGNED THE VALUES INDICATED */

/*                 IBETA  - THE RADIX OF THE FLOATING-POINT SYSTEM */
/*                 IT     - THE NUMBER OF BASE-IBETA DIGITS IN THE */
/*                          SIGNIFICAND OF A FLOATING-POINT NUMBER */
/*                 IRND   - 0 IF FLOATING-POINT ADDITION CHOPS, */
/*                          1 IF FLOATING-POINT ADDITION ROUNDS */
/*                 MINEXP - THE LARGEST IN MAGNITUDE NEGATIVE */
/*                          INTEGER SUCH THAT DFLOAT(IBETA)**MINEXP */
/*                          IS A POSITIVE FLOATING-POINT NUMBER */
/*                 EPS    - THE SMALLEST POSITIVE FLOATING-POINT */
/*                          NUMBER SUCH THAT 1.0+EPS .NE. 1.0 */
/*                 XMAX   - THE LARGEST FINITE FLOATING-POINT NO. */

/*        DRAN(K) - A FUNCTION SUBPROGRAM RETURNING RANDOM DOUBLE */
/*                 PRECISION NUMBERS UNIFORMLY DISTRIBUTED OVER */
/*                 (0,1) */


/*     STANDARD FORTRAN SUBPROGRAMS REQUIRED */

/*         DABS, DLOG, DMAX1, DCOSH, DFLOAT, IDINT, DSINH, DSQRT */


/*     LATEST REVISION - DECEMBER 6, 1979 */

/*     AUTHOR - W. J. CODY */
/*              ARGONNE NATIONAL LABORATORY */



/*     IOUT = 6 */
#line 1502 "talldp.f"
    machar_(&ibeta, &it, &irnd, &ngrd, &machep, &negep, &iexp, &minexp, &
	    maxexp, &eps, &epsneg, &xmin, &xmax);
#line 1504 "talldp.f"
    beta = (doublereal) ((real) ibeta);
#line 1505 "talldp.f"
    albeta = log(beta);
#line 1506 "talldp.f"
    alxmax = log(xmax);
#line 1507 "talldp.f"
    ait = (doublereal) ((real) it);
#line 1508 "talldp.f"
    zero = 0.;
#line 1509 "talldp.f"
    one = 1.;
#line 1510 "talldp.f"
    three = 3.;
#line 1511 "talldp.f"
    five = 5.;
/* #    C0 = FIVE/16.0D+00 + 1.152713683194269979D-2 */
/* #    C0 = FIVE/16.0D+00 + ((1/(2*cosh(1))) - 5/16) */
#line 1514 "talldp.f"
    c0 = five / 16. + 
	    .01152713683194269978748867661307516155424465603597101152;
#line 1516 "talldp.f"
    a = zero;
#line 1517 "talldp.f"
    b = .5;
#line 1518 "talldp.f"
    c__ = (ait + one) * .35;
#line 1519 "talldp.f"
    if (ibeta == 10) {
#line 1519 "talldp.f"
	c__ *= three;
#line 1519 "talldp.f"
    }
#line 1520 "talldp.f"
    n = 2000;
#line 1521 "talldp.f"
    xn = (doublereal) ((real) n);
#line 1522 "talldp.f"
    i1 = 0;
#line 1523 "talldp.f"
    i2 = 2;
#line 1524 "talldp.f"
    nit = 2 - (integer) (log(eps) * three) / 20;
#line 1525 "talldp.f"
    aind = (doublereal) ((real) (nit + nit + 1));
/* ----------------------------------------------------------------- */
/*     RANDOM ARGUMENT ACCURACY TESTS */
/* ----------------------------------------------------------------- */
#line 1529 "talldp.f"
    for (j = 1; j <= 4; ++j) {
#line 1530 "talldp.f"
	if (j != 2) {
#line 1530 "talldp.f"
	    goto L30;
#line 1530 "talldp.f"
	}
#line 1531 "talldp.f"
	aind -= one;
#line 1532 "talldp.f"
	i2 = 1;
#line 1533 "talldp.f"
L30:
#line 1533 "talldp.f"
	k1 = 0;
#line 1534 "talldp.f"
	k3 = 0;
#line 1535 "talldp.f"
	x1 = zero;
#line 1536 "talldp.f"
	r6 = zero;
#line 1537 "talldp.f"
	r7 = zero;
#line 1538 "talldp.f"
	del = (b - a) / xn;
#line 1539 "talldp.f"
	xl = a;

#line 1541 "talldp.f"
	i__1 = n;
#line 1541 "talldp.f"
	for (i__ = 1; i__ <= i__1; ++i__) {
#line 1542 "talldp.f"
	    x = del * dran_(&i1) + xl;
#line 1543 "talldp.f"
	    if (j > 2) {
#line 1543 "talldp.f"
		goto L80;
#line 1543 "talldp.f"
	    }
#line 1544 "talldp.f"
	    xsq = x * x;
#line 1545 "talldp.f"
	    zz = one;
#line 1546 "talldp.f"
	    den = aind;

#line 1548 "talldp.f"
	    i__2 = nit;
#line 1548 "talldp.f"
	    for (ii = i2; ii <= i__2; ++ii) {
#line 1549 "talldp.f"
		w = zz * xsq / (den * (den - one));
#line 1550 "talldp.f"
		zz = w + one;
#line 1551 "talldp.f"
		den += -2.;
#line 1552 "talldp.f"
/* L40: */
#line 1552 "talldp.f"
	    }

#line 1554 "talldp.f"
	    if (j == 2) {
#line 1554 "talldp.f"
		goto L50;
#line 1554 "talldp.f"
	    }
#line 1555 "talldp.f"
	    w = x * xsq * zz / 6.;
#line 1556 "talldp.f"
	    zz = x + w;
#line 1557 "talldp.f"
	    z__ = sinh(x);
#line 1558 "talldp.f"
	    if (irnd != 0) {
#line 1558 "talldp.f"
		goto L110;
#line 1558 "talldp.f"
	    }
#line 1559 "talldp.f"
	    w = x - zz + w;
#line 1560 "talldp.f"
	    zz += w + w;
#line 1561 "talldp.f"
	    goto L110;
#line 1562 "talldp.f"
L50:
#line 1562 "talldp.f"
	    z__ = cosh(x);
#line 1563 "talldp.f"
	    if (irnd != 0) {
#line 1563 "talldp.f"
		goto L110;
#line 1563 "talldp.f"
	    }
#line 1564 "talldp.f"
	    w = one - zz + w;
#line 1565 "talldp.f"
	    zz += w + w;
#line 1566 "talldp.f"
	    goto L110;
#line 1567 "talldp.f"
L80:
#line 1567 "talldp.f"
	    y = x;
#line 1568 "talldp.f"
	    x = y - one;
#line 1569 "talldp.f"
	    w = x - one;
#line 1570 "talldp.f"
	    if (j == 4) {
#line 1570 "talldp.f"
		goto L100;
#line 1570 "talldp.f"
	    }
#line 1571 "talldp.f"
	    z__ = sinh(x);
#line 1572 "talldp.f"
	    zz = (sinh(y) + sinh(w)) * c0;
#line 1573 "talldp.f"
	    goto L110;
#line 1574 "talldp.f"
L100:
#line 1574 "talldp.f"
	    z__ = cosh(x);
#line 1575 "talldp.f"
	    zz = (cosh(y) + cosh(w)) * c0;
#line 1576 "talldp.f"
L110:
#line 1576 "talldp.f"
	    w = one;
#line 1577 "talldp.f"
	    if (z__ != zero) {
#line 1577 "talldp.f"
		w = (z__ - zz) / z__;
#line 1577 "talldp.f"
	    }
#line 1578 "talldp.f"
	    if (w > zero) {
#line 1578 "talldp.f"
		++k1;
#line 1578 "talldp.f"
	    }
#line 1579 "talldp.f"
	    if (w < zero) {
#line 1579 "talldp.f"
		++k3;
#line 1579 "talldp.f"
	    }
#line 1580 "talldp.f"
	    w = abs(w);
#line 1581 "talldp.f"
	    if (w <= r6) {
#line 1581 "talldp.f"
		goto L120;
#line 1581 "talldp.f"
	    }
#line 1582 "talldp.f"
	    r6 = w;
#line 1583 "talldp.f"
	    x1 = x;
#line 1584 "talldp.f"
L120:
#line 1584 "talldp.f"
	    r7 += w * w;
#line 1585 "talldp.f"
	    xl += del;
#line 1586 "talldp.f"
/* L200: */
#line 1586 "talldp.f"
	}

#line 1588 "talldp.f"
	k2 = n - k3 - k1;
#line 1589 "talldp.f"
	r7 = sqrt(r7 / xn);
#line 1590 "talldp.f"
	i__ = j / 2 << 1;
#line 1591 "talldp.f"
	if (j == 1) {
#line 1591 "talldp.f"
	    io___482.ciunit = *iout;
#line 1591 "talldp.f"
	    s_wsfe(&io___482);
#line 1591 "talldp.f"
	    e_wsfe();
#line 1591 "talldp.f"
	}
#line 1592 "talldp.f"
	if (j == 2) {
#line 1592 "talldp.f"
	    io___483.ciunit = *iout;
#line 1592 "talldp.f"
	    s_wsfe(&io___483);
#line 1592 "talldp.f"
	    e_wsfe();
#line 1592 "talldp.f"
	}
#line 1593 "talldp.f"
	if (j == 3) {
#line 1593 "talldp.f"
	    io___484.ciunit = *iout;
#line 1593 "talldp.f"
	    s_wsfe(&io___484);
#line 1593 "talldp.f"
	    e_wsfe();
#line 1593 "talldp.f"
	}
#line 1594 "talldp.f"
	if (j == 4) {
#line 1594 "talldp.f"
	    io___485.ciunit = *iout;
#line 1594 "talldp.f"
	    s_wsfe(&io___485);
#line 1594 "talldp.f"
	    e_wsfe();
#line 1594 "talldp.f"
	}
#line 1595 "talldp.f"
	io___486.ciunit = *iout;
#line 1595 "talldp.f"
	s_wsfe(&io___486);
#line 1595 "talldp.f"
	do_fio(&c__1, (char *)&n, (ftnlen)sizeof(integer));
#line 1595 "talldp.f"
	do_fio(&c__1, (char *)&a, (ftnlen)sizeof(doublereal));
#line 1595 "talldp.f"
	do_fio(&c__1, (char *)&b, (ftnlen)sizeof(doublereal));
#line 1595 "talldp.f"
	e_wsfe();
#line 1596 "talldp.f"
	if (i__ != j) {
#line 1596 "talldp.f"
	    io___487.ciunit = *iout;
#line 1596 "talldp.f"
	    s_wsfe(&io___487);
#line 1596 "talldp.f"
	    do_fio(&c__1, (char *)&k1, (ftnlen)sizeof(integer));
#line 1596 "talldp.f"
	    do_fio(&c__1, (char *)&k2, (ftnlen)sizeof(integer));
#line 1596 "talldp.f"
	    do_fio(&c__1, (char *)&k3, (ftnlen)sizeof(integer));
#line 1596 "talldp.f"
	    e_wsfe();
#line 1596 "talldp.f"
	}
#line 1597 "talldp.f"
	if (i__ == j) {
#line 1597 "talldp.f"
	    io___488.ciunit = *iout;
#line 1597 "talldp.f"
	    s_wsfe(&io___488);
#line 1597 "talldp.f"
	    do_fio(&c__1, (char *)&k1, (ftnlen)sizeof(integer));
#line 1597 "talldp.f"
	    do_fio(&c__1, (char *)&k2, (ftnlen)sizeof(integer));
#line 1597 "talldp.f"
	    do_fio(&c__1, (char *)&k3, (ftnlen)sizeof(integer));
#line 1597 "talldp.f"
	    e_wsfe();
#line 1597 "talldp.f"
	}
#line 1598 "talldp.f"
	io___489.ciunit = *iout;
#line 1598 "talldp.f"
	s_wsfe(&io___489);
#line 1598 "talldp.f"
	do_fio(&c__1, (char *)&it, (ftnlen)sizeof(integer));
#line 1598 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 1598 "talldp.f"
	e_wsfe();
#line 1599 "talldp.f"
	w = -999.;
#line 1600 "talldp.f"
	if (r6 != zero) {
#line 1600 "talldp.f"
	    w = log((abs(r6))) / albeta;
#line 1600 "talldp.f"
	}
#line 1601 "talldp.f"
	io___490.ciunit = *iout;
#line 1601 "talldp.f"
	s_wsfe(&io___490);
#line 1601 "talldp.f"
	do_fio(&c__1, (char *)&r6, (ftnlen)sizeof(doublereal));
#line 1601 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 1601 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 1601 "talldp.f"
	do_fio(&c__1, (char *)&x1, (ftnlen)sizeof(doublereal));
#line 1601 "talldp.f"
	e_wsfe();
/* Computing MAX */
#line 1602 "talldp.f"
	d__1 = ait + w;
#line 1602 "talldp.f"
	w = max(d__1,zero);
#line 1603 "talldp.f"
	io___491.ciunit = *iout;
#line 1603 "talldp.f"
	s_wsfe(&io___491);
#line 1603 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 1603 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 1603 "talldp.f"
	e_wsfe();
#line 1604 "talldp.f"
	w = -999.;
#line 1605 "talldp.f"
	if (r7 != zero) {
#line 1605 "talldp.f"
	    w = log((abs(r7))) / albeta;
#line 1605 "talldp.f"
	}
#line 1606 "talldp.f"
	io___492.ciunit = *iout;
#line 1606 "talldp.f"
	s_wsfe(&io___492);
#line 1606 "talldp.f"
	do_fio(&c__1, (char *)&r7, (ftnlen)sizeof(doublereal));
#line 1606 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 1606 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 1606 "talldp.f"
	e_wsfe();
/* Computing MAX */
#line 1607 "talldp.f"
	d__1 = ait + w;
#line 1607 "talldp.f"
	w = max(d__1,zero);
#line 1608 "talldp.f"
	io___493.ciunit = *iout;
#line 1608 "talldp.f"
	s_wsfe(&io___493);
#line 1608 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 1608 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 1608 "talldp.f"
	e_wsfe();
#line 1609 "talldp.f"
	if (j != 2) {
#line 1609 "talldp.f"
	    goto L300;
#line 1609 "talldp.f"
	}
#line 1610 "talldp.f"
	b = alxmax;
#line 1611 "talldp.f"
	a = three;
#line 1612 "talldp.f"
L300:
#line 1612 "talldp.f"
	;
#line 1612 "talldp.f"
    }
/* ----------------------------------------------------------------- */
/*     SPECIAL TESTS */
/* ----------------------------------------------------------------- */
#line 1616 "talldp.f"
    io___494.ciunit = *iout;
#line 1616 "talldp.f"
    s_wsfe(&io___494);
#line 1616 "talldp.f"
    e_wsfe();
#line 1617 "talldp.f"
    io___495.ciunit = *iout;
#line 1617 "talldp.f"
    s_wsfe(&io___495);
#line 1617 "talldp.f"
    e_wsfe();

#line 1619 "talldp.f"
    for (i__ = 1; i__ <= 5; ++i__) {
#line 1620 "talldp.f"
	x = dran_(&i1) * a;
#line 1621 "talldp.f"
	z__ = sinh(x) + sinh(-x);
#line 1622 "talldp.f"
	io___496.ciunit = *iout;
#line 1622 "talldp.f"
	s_wsfe(&io___496);
#line 1622 "talldp.f"
	do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 1622 "talldp.f"
	do_fio(&c__1, (char *)&z__, (ftnlen)sizeof(doublereal));
#line 1622 "talldp.f"
	e_wsfe();
#line 1623 "talldp.f"
/* L320: */
#line 1623 "talldp.f"
    }

#line 1625 "talldp.f"
    io___497.ciunit = *iout;
#line 1625 "talldp.f"
    s_wsfe(&io___497);
#line 1625 "talldp.f"
    e_wsfe();
#line 1626 "talldp.f"
    betap = pow_di(&beta, &it);
#line 1627 "talldp.f"
    x = dran_(&i1) / betap;

#line 1629 "talldp.f"
    for (i__ = 1; i__ <= 5; ++i__) {
#line 1630 "talldp.f"
	z__ = x - sinh(x);
#line 1631 "talldp.f"
	io___499.ciunit = *iout;
#line 1631 "talldp.f"
	s_wsfe(&io___499);
#line 1631 "talldp.f"
	do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 1631 "talldp.f"
	do_fio(&c__1, (char *)&z__, (ftnlen)sizeof(doublereal));
#line 1631 "talldp.f"
	e_wsfe();
#line 1632 "talldp.f"
	x /= beta;
#line 1633 "talldp.f"
/* L330: */
#line 1633 "talldp.f"
    }

#line 1635 "talldp.f"
    io___500.ciunit = *iout;
#line 1635 "talldp.f"
    s_wsfe(&io___500);
#line 1635 "talldp.f"
    e_wsfe();

#line 1637 "talldp.f"
    for (i__ = 1; i__ <= 5; ++i__) {
#line 1638 "talldp.f"
	x = dran_(&i1) * a;
#line 1639 "talldp.f"
	z__ = cosh(x) - cosh(-x);
#line 1640 "talldp.f"
	io___501.ciunit = *iout;
#line 1640 "talldp.f"
	s_wsfe(&io___501);
#line 1640 "talldp.f"
	do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 1640 "talldp.f"
	do_fio(&c__1, (char *)&z__, (ftnlen)sizeof(doublereal));
#line 1640 "talldp.f"
	e_wsfe();
#line 1641 "talldp.f"
/* L340: */
#line 1641 "talldp.f"
    }

#line 1643 "talldp.f"
    io___502.ciunit = *iout;
#line 1643 "talldp.f"
    s_wsfe(&io___502);
#line 1643 "talldp.f"
    e_wsfe();
#line 1644 "talldp.f"
    d__1 = (doublereal) ((real) minexp) * .75;
#line 1644 "talldp.f"
    x = pow_dd(&beta, &d__1);
#line 1645 "talldp.f"
    y = sinh(x);
#line 1646 "talldp.f"
    io___503.ciunit = *iout;
#line 1646 "talldp.f"
    s_wsfe(&io___503);
#line 1646 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 1646 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 1646 "talldp.f"
    e_wsfe();
/* ----------------------------------------------------------------- */
/*     TEST OF ERROR RETURNS */
/* ----------------------------------------------------------------- */
#line 1650 "talldp.f"
    io___504.ciunit = *iout;
#line 1650 "talldp.f"
    s_wsfe(&io___504);
#line 1650 "talldp.f"
    e_wsfe();
#line 1651 "talldp.f"
    x = alxmax + .125;
#line 1652 "talldp.f"
    io___505.ciunit = *iout;
#line 1652 "talldp.f"
    s_wsfe(&io___505);
#line 1652 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 1652 "talldp.f"
    e_wsfe();
#line 1653 "talldp.f"
    y = sinh(x);
#line 1654 "talldp.f"
    io___506.ciunit = *iout;
#line 1654 "talldp.f"
    s_wsfe(&io___506);
#line 1654 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 1654 "talldp.f"
    e_wsfe();
#line 1655 "talldp.f"
    x = betap;
#line 1656 "talldp.f"
    io___507.ciunit = *iout;
#line 1656 "talldp.f"
    s_wsfe(&io___507);
#line 1656 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 1656 "talldp.f"
    e_wsfe();
#line 1657 "talldp.f"
    y = sinh(x);
#line 1658 "talldp.f"
    io___508.ciunit = *iout;
#line 1658 "talldp.f"
    s_wsfe(&io___508);
#line 1658 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 1658 "talldp.f"
    e_wsfe();
#line 1659 "talldp.f"
    io___509.ciunit = *iout;
#line 1659 "talldp.f"
    s_wsfe(&io___509);
#line 1659 "talldp.f"
    e_wsfe();
#line 1660 "talldp.f"
    return 0;
/*     ---------- LAST CARD OF DSINH/DCOSH TEST PROGRAM ---------- */
} /* tdsinh_ */

/* Subroutine */ int tdsqrt_(integer *iout)
{
    /* Format strings */
    static char fmt_1000[] = "(\0021TEST OF DSQRT(X*X) - X \002//)";
    static char fmt_1010[] = "(i7,\002 RANDOM ARGUMENTS WERE TESTED FROM THE"
	    " INTERVAL\002/6x,\002(\002,d15.4,\002,\002,d15.4,\002)\002//)";
    static char fmt_1011[] = "(\002 DSQRT(X) WAS LARGER\002,i6,\002 TIMES"
	    ",\002/13x,\002 AGREED\002,i6,\002 TIMES, AND\002/9x,\002WAS SMAL"
	    "LER\002,i6,\002 TIMES.\002//)";
    static char fmt_1020[] = "(\002 THERE ARE\002,i4,\002 BASE\002,i4,\002 S"
	    "IGNIFICANT DIGITS IN A FLOATING-POINT NUMBER\002//)";
    static char fmt_1021[] = "(\002 THE MAXIMUM RELATIVE ERROR OF\002,d15.4"
	    ",\002 = \002,i4,\002 **\002,f7.2/4x,\002OCCURRED FOR X =\002,d17"
	    ".6)";
    static char fmt_1022[] = "(\002 THE ESTIMATED LOSS OF BASE\002,i4,\002 S"
	    "IGNIFICANT DIGITS IS\002,f7.2//)";
    static char fmt_1023[] = "(\002 THE ROOT MEAN SQUARE RELATIVE ERROR WA"
	    "S\002,d15.4,\002 = \002,i4,\002 **\002,f7.2)";
    static char fmt_1040[] = "(\0021TEST OF SPECIAL ARGUMENTS\002//)";
    static char fmt_1041[] = "(\002 DSQRT(XMIN) = DSQRT(\002,d25.17,\002) ="
	    " \002,d25.17//)";
    static char fmt_1042[] = "(\002 DSQRT(1-EPSNEG) = DSQRT(1-\002,d15.7,"
	    "\002) = \002,d25.17//)";
    static char fmt_1043[] = "(\002 DSQRT(1.0) = DSQRT(\002,d25.17,\002) ="
	    " \002,d25.17//)";
    static char fmt_1044[] = "(\002 DSQRT(1+EPS) = DSQRT(1+\002,d15.7,\002) "
	    "= \002,d25.17//)";
    static char fmt_1045[] = "(\002 DSQRT(XMAX) = DSQRT(\002,d25.17,\002) ="
	    " \002,d25.17//)";
    static char fmt_1050[] = "(\0021TEST OF ERROR RETURNS\002//)";
    static char fmt_1051[] = "(\002 DSQRT WILL BE CALLED WITH THE ARGUMEN"
	    "T\002,d15.4/\002 THIS SHOULD NOT TRIGGER AN ERROR MESSAGE\002//)";
    static char fmt_1055[] = "(\002 DSQRT RETURNED THE VALUE\002,d15.4///)";
    static char fmt_1052[] = "(\0020DSQRT WILL BE CALLED WITH THE ARGUMEN"
	    "T\002,d15.4/\002 THIS SHOULD TRIGGER AN ERROR MESSAGE\002//)";
    static char fmt_1100[] = "(\002 THIS CONCLUDES THE TESTS\002)";

    /* System generated locals */
    integer i__1;
    doublereal d__1;

    /* Builtin functions */
    double sqrt(doublereal), log(doublereal);
    integer s_wsfe(cilist *), e_wsfe(void), do_fio(integer *, char *, ftnlen);

    /* Local variables */
    static doublereal a, b, c__;
    static integer i__, j, n;
    static doublereal w, x, y, z__;
    static integer k1, k2, k3;
    static doublereal r6, r7, x1;
    static integer it;
    static doublereal xn, ait, one, eps, beta;
    static integer ngrd, irnd, iexp;
    static doublereal xmin, xmax, zero;
    static integer ibeta, negep;
    static doublereal albeta;
    extern /* Subroutine */ int machar_(integer *, integer *, integer *, 
	    integer *, integer *, integer *, integer *, integer *, integer *, 
	    doublereal *, doublereal *, doublereal *, doublereal *);
    static integer machep;
    extern doublereal drandl_(doublereal *);
    static doublereal sqbeta, epsneg;
    static integer minexp, maxexp;

    /* Fortran I/O blocks */
    static cilist io___546 = { 0, 0, 0, fmt_1000, 0 };
    static cilist io___547 = { 0, 0, 0, fmt_1010, 0 };
    static cilist io___548 = { 0, 0, 0, fmt_1011, 0 };
    static cilist io___549 = { 0, 6, 0, fmt_1020, 0 };
    static cilist io___550 = { 0, 0, 0, fmt_1021, 0 };
    static cilist io___551 = { 0, 0, 0, fmt_1022, 0 };
    static cilist io___552 = { 0, 0, 0, fmt_1023, 0 };
    static cilist io___553 = { 0, 0, 0, fmt_1022, 0 };
    static cilist io___554 = { 0, 0, 0, fmt_1040, 0 };
    static cilist io___555 = { 0, 0, 0, fmt_1041, 0 };
    static cilist io___556 = { 0, 0, 0, fmt_1042, 0 };
    static cilist io___557 = { 0, 0, 0, fmt_1043, 0 };
    static cilist io___558 = { 0, 0, 0, fmt_1044, 0 };
    static cilist io___559 = { 0, 0, 0, fmt_1045, 0 };
    static cilist io___560 = { 0, 0, 0, fmt_1050, 0 };
    static cilist io___561 = { 0, 0, 0, fmt_1051, 0 };
    static cilist io___562 = { 0, 0, 0, fmt_1055, 0 };
    static cilist io___563 = { 0, 0, 0, fmt_1052, 0 };
    static cilist io___564 = { 0, 0, 0, fmt_1055, 0 };
    static cilist io___565 = { 0, 0, 0, fmt_1100, 0 };


/*     PROGRAM TO TEST DSQRT */

/*     DATA REQUIRED */

/*        NONE */

/*     SUBPROGRAMS REQUIRED FROM THIS PACKAGE */

/*        MACHAR - AN ENVIRONMENTAL INQUIRY PROGRAM PROVIDING */
/*                 INFORMATION ON THE FLOATING-POINT ARITHMETIC */
/*                 SYSTEM.  NOTE THAT THE CALL TO MACHAR CAN */
/*                 BE DELETED PROVIDED THE FOLLOWING SIX */
/*                 PARAMETERS ARE ASSIGNED THE VALUES INDICATED */

/*                 IBETA  - THE RADIX OF THE FLOATING-POINT SYSTEM */
/*                 IT     - THE NUMBER OF BASE-IBETA DIGITS IN THE */
/*                          SIGNIFICAND OF A FLOATING-POINT NUMBER */
/*                 EPS    - THE SMALLEST POSITIVE FLOATING-POINT */
/*                          NUMBER SUCH THAT 1.0+EPS .NE. 1.0 */
/*                 EPSNEG - THE SMALLEST POSITIVE FLOATING-POINT */
/*                          NUMBER SUCH THAT 1.0-EPSNEG .NE. 1.0 */
/*                 XMIN   - THE SMALLEST NON-VANISHING FLOATING-POINT */
/*                          POWER OF THE RADIX */
/*                 XMAX   - THE LARGEST FINITE FLOATING-POINT NO. */

/*      DRANDL(X) - A FUNCTION SUBPROGRAM RETURNING LOGARITHMICALLY */
/*                 DISTRIBUTED RANDOM DOUBLE PRECISION NUMBERS. */
/*                 IN PARTICULAR, */
/*                        A * DRANDL(DLOG(B/A)) */
/*                 IS LOGARITHMICALLY DISTRIBUTED OVER (A,B) */

/*        DRAN(K) - A FUNCTION SUBPROGRAM RETURNING RANDOM DOUBLE */
/*                 PRECISION NUMBERS UNIFORMLY DISTRIBUTED OVER */
/*                 (0,1) */


/*     STANDARD FORTRAN SUBPROGRAMS REQUIRED */

/*         DABS, DLOG, DMAX1, DFLOAT, DSQRT */


/*     LATEST REVISION - AUGUST 2, 1979 */

/*     AUTHOR - W. J. CODY */
/*              ARGONNE NATIONAL LABORATORY */



/*     IOUT = 6 */
#line 1754 "talldp.f"
    machar_(&ibeta, &it, &irnd, &ngrd, &machep, &negep, &iexp, &minexp, &
	    maxexp, &eps, &epsneg, &xmin, &xmax);
#line 1756 "talldp.f"
    beta = (doublereal) ((real) ibeta);
#line 1757 "talldp.f"
    sqbeta = sqrt(beta);
#line 1758 "talldp.f"
    albeta = log(beta);
#line 1759 "talldp.f"
    ait = (doublereal) ((real) it);
#line 1760 "talldp.f"
    one = 1.;
#line 1761 "talldp.f"
    zero = 0.;
#line 1762 "talldp.f"
    a = one / sqbeta;
#line 1763 "talldp.f"
    b = one;
#line 1764 "talldp.f"
    n = 2000;
#line 1765 "talldp.f"
    xn = (doublereal) ((real) n);
/* ----------------------------------------------------------------- */
/*     RANDOM ARGUMENT ACCURACY TESTS */
/* ----------------------------------------------------------------- */
#line 1769 "talldp.f"
    for (j = 1; j <= 2; ++j) {
#line 1770 "talldp.f"
	c__ = log(b / a);
#line 1771 "talldp.f"
	k1 = 0;
#line 1772 "talldp.f"
	k3 = 0;
#line 1773 "talldp.f"
	x1 = zero;
#line 1774 "talldp.f"
	r6 = zero;
#line 1775 "talldp.f"
	r7 = zero;

#line 1777 "talldp.f"
	i__1 = n;
#line 1777 "talldp.f"
	for (i__ = 1; i__ <= i__1; ++i__) {
#line 1778 "talldp.f"
	    x = a * drandl_(&c__);
#line 1779 "talldp.f"
	    y = x * x;
#line 1780 "talldp.f"
	    z__ = sqrt(y);
#line 1781 "talldp.f"
	    w = (z__ - x) / x;
#line 1782 "talldp.f"
	    if (w > zero) {
#line 1782 "talldp.f"
		++k1;
#line 1782 "talldp.f"
	    }
#line 1783 "talldp.f"
	    if (w < zero) {
#line 1783 "talldp.f"
		++k3;
#line 1783 "talldp.f"
	    }
#line 1784 "talldp.f"
	    w = abs(w);
#line 1785 "talldp.f"
	    if (w <= r6) {
#line 1785 "talldp.f"
		goto L120;
#line 1785 "talldp.f"
	    }
#line 1786 "talldp.f"
	    r6 = w;
#line 1787 "talldp.f"
	    x1 = x;
#line 1788 "talldp.f"
L120:
#line 1788 "talldp.f"
	    r7 += w * w;
#line 1789 "talldp.f"
/* L200: */
#line 1789 "talldp.f"
	}

#line 1791 "talldp.f"
	k2 = n - k1 - k3;
#line 1792 "talldp.f"
	r7 = sqrt(r7 / xn);
#line 1793 "talldp.f"
	io___546.ciunit = *iout;
#line 1793 "talldp.f"
	s_wsfe(&io___546);
#line 1793 "talldp.f"
	e_wsfe();
#line 1794 "talldp.f"
	io___547.ciunit = *iout;
#line 1794 "talldp.f"
	s_wsfe(&io___547);
#line 1794 "talldp.f"
	do_fio(&c__1, (char *)&n, (ftnlen)sizeof(integer));
#line 1794 "talldp.f"
	do_fio(&c__1, (char *)&a, (ftnlen)sizeof(doublereal));
#line 1794 "talldp.f"
	do_fio(&c__1, (char *)&b, (ftnlen)sizeof(doublereal));
#line 1794 "talldp.f"
	e_wsfe();
#line 1795 "talldp.f"
	io___548.ciunit = *iout;
#line 1795 "talldp.f"
	s_wsfe(&io___548);
#line 1795 "talldp.f"
	do_fio(&c__1, (char *)&k1, (ftnlen)sizeof(integer));
#line 1795 "talldp.f"
	do_fio(&c__1, (char *)&k2, (ftnlen)sizeof(integer));
#line 1795 "talldp.f"
	do_fio(&c__1, (char *)&k3, (ftnlen)sizeof(integer));
#line 1795 "talldp.f"
	e_wsfe();
#line 1796 "talldp.f"
	s_wsfe(&io___549);
#line 1796 "talldp.f"
	do_fio(&c__1, (char *)&it, (ftnlen)sizeof(integer));
#line 1796 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 1796 "talldp.f"
	e_wsfe();
#line 1797 "talldp.f"
	w = -999.;
#line 1798 "talldp.f"
	if (r6 != zero) {
#line 1798 "talldp.f"
	    w = log((abs(r6))) / albeta;
#line 1798 "talldp.f"
	}
#line 1799 "talldp.f"
	io___550.ciunit = *iout;
#line 1799 "talldp.f"
	s_wsfe(&io___550);
#line 1799 "talldp.f"
	do_fio(&c__1, (char *)&r6, (ftnlen)sizeof(doublereal));
#line 1799 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 1799 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 1799 "talldp.f"
	do_fio(&c__1, (char *)&x1, (ftnlen)sizeof(doublereal));
#line 1799 "talldp.f"
	e_wsfe();
/* Computing MAX */
#line 1800 "talldp.f"
	d__1 = ait + w;
#line 1800 "talldp.f"
	w = max(d__1,zero);
#line 1801 "talldp.f"
	io___551.ciunit = *iout;
#line 1801 "talldp.f"
	s_wsfe(&io___551);
#line 1801 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 1801 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 1801 "talldp.f"
	e_wsfe();
#line 1802 "talldp.f"
	w = -999.;
#line 1803 "talldp.f"
	if (r7 != zero) {
#line 1803 "talldp.f"
	    w = log((abs(r7))) / albeta;
#line 1803 "talldp.f"
	}
#line 1804 "talldp.f"
	io___552.ciunit = *iout;
#line 1804 "talldp.f"
	s_wsfe(&io___552);
#line 1804 "talldp.f"
	do_fio(&c__1, (char *)&r7, (ftnlen)sizeof(doublereal));
#line 1804 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 1804 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 1804 "talldp.f"
	e_wsfe();
/* Computing MAX */
#line 1805 "talldp.f"
	d__1 = ait + w;
#line 1805 "talldp.f"
	w = max(d__1,zero);
#line 1806 "talldp.f"
	io___553.ciunit = *iout;
#line 1806 "talldp.f"
	s_wsfe(&io___553);
#line 1806 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 1806 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 1806 "talldp.f"
	e_wsfe();
#line 1807 "talldp.f"
	a = one;
#line 1808 "talldp.f"
	b = sqbeta;
#line 1809 "talldp.f"
/* L300: */
#line 1809 "talldp.f"
    }
/* ----------------------------------------------------------------- */
/*     SPECIAL TESTS */
/* ----------------------------------------------------------------- */
#line 1813 "talldp.f"
    io___554.ciunit = *iout;
#line 1813 "talldp.f"
    s_wsfe(&io___554);
#line 1813 "talldp.f"
    e_wsfe();
#line 1814 "talldp.f"
    x = xmin;
#line 1815 "talldp.f"
    y = sqrt(x);
#line 1816 "talldp.f"
    io___555.ciunit = *iout;
#line 1816 "talldp.f"
    s_wsfe(&io___555);
#line 1816 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 1816 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 1816 "talldp.f"
    e_wsfe();
#line 1817 "talldp.f"
    x = one - epsneg;
#line 1818 "talldp.f"
    y = sqrt(x);
#line 1819 "talldp.f"
    io___556.ciunit = *iout;
#line 1819 "talldp.f"
    s_wsfe(&io___556);
#line 1819 "talldp.f"
    do_fio(&c__1, (char *)&epsneg, (ftnlen)sizeof(doublereal));
#line 1819 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 1819 "talldp.f"
    e_wsfe();
#line 1820 "talldp.f"
    x = one;
#line 1821 "talldp.f"
    y = sqrt(x);
#line 1822 "talldp.f"
    io___557.ciunit = *iout;
#line 1822 "talldp.f"
    s_wsfe(&io___557);
#line 1822 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 1822 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 1822 "talldp.f"
    e_wsfe();
#line 1823 "talldp.f"
    x = one + eps;
#line 1824 "talldp.f"
    y = sqrt(x);
#line 1825 "talldp.f"
    io___558.ciunit = *iout;
#line 1825 "talldp.f"
    s_wsfe(&io___558);
#line 1825 "talldp.f"
    do_fio(&c__1, (char *)&eps, (ftnlen)sizeof(doublereal));
#line 1825 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 1825 "talldp.f"
    e_wsfe();
#line 1826 "talldp.f"
    x = xmax;
#line 1827 "talldp.f"
    y = sqrt(x);
#line 1828 "talldp.f"
    io___559.ciunit = *iout;
#line 1828 "talldp.f"
    s_wsfe(&io___559);
#line 1828 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 1828 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 1828 "talldp.f"
    e_wsfe();
/* ----------------------------------------------------------------- */
/*     TEST OF ERROR RETURNS */
/* ----------------------------------------------------------------- */
#line 1832 "talldp.f"
    io___560.ciunit = *iout;
#line 1832 "talldp.f"
    s_wsfe(&io___560);
#line 1832 "talldp.f"
    e_wsfe();
#line 1833 "talldp.f"
    x = zero;
#line 1834 "talldp.f"
    io___561.ciunit = *iout;
#line 1834 "talldp.f"
    s_wsfe(&io___561);
#line 1834 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 1834 "talldp.f"
    e_wsfe();
#line 1835 "talldp.f"
    y = sqrt(x);
#line 1836 "talldp.f"
    io___562.ciunit = *iout;
#line 1836 "talldp.f"
    s_wsfe(&io___562);
#line 1836 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 1836 "talldp.f"
    e_wsfe();
#line 1837 "talldp.f"
    x = -one;
#line 1838 "talldp.f"
    io___563.ciunit = *iout;
#line 1838 "talldp.f"
    s_wsfe(&io___563);
#line 1838 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 1838 "talldp.f"
    e_wsfe();
#line 1839 "talldp.f"
    y = sqrt(x);
#line 1840 "talldp.f"
    io___564.ciunit = *iout;
#line 1840 "talldp.f"
    s_wsfe(&io___564);
#line 1840 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 1840 "talldp.f"
    e_wsfe();
#line 1841 "talldp.f"
    io___565.ciunit = *iout;
#line 1841 "talldp.f"
    s_wsfe(&io___565);
#line 1841 "talldp.f"
    e_wsfe();
#line 1842 "talldp.f"
    return 0;
/*     ---------- LAST CARD OF DSQRT TEST PROGRAM ---------- */
} /* tdsqrt_ */

/* Subroutine */ int tdtan_(integer *iout)
{
    /* Format strings */
    static char fmt_1000[] = "(\0021TEST OF DTAN(X) VS 2*DTAN(X/2)/(1-DTAN(X"
	    "/2)**2) \002//)";
    static char fmt_1005[] = "(\0021TEST OF DCOT(X) VS (DCOT(X/2)**2-1)/(2*D"
	    "COT(X/2)) \002//)";
    static char fmt_1010[] = "(i7,\002 RANDOM ARGUMENTS WERE TESTED FROM THE"
	    " INTERVAL\002/6x,\002(\002,d15.4,\002,\002,d15.4,\002)\002//)";
    static char fmt_1011[] = "(\002 DTAN(X) WAS LARGER\002,i6,\002 TIMES,"
	    "\002/12x,\002 AGREED\002,i6,\002 TIMES, AND\002/8x,\002WAS SMALL"
	    "ER\002,i6,\002 TIMES.\002//)";
    static char fmt_1012[] = "(\002 DCOT(X) WAS LARGER\002,i6,\002 TIMES,"
	    "\002/12x,\002 AGREED\002,i6,\002 TIMES, AND\002/8x,\002WAS SMALL"
	    "ER\002,i6,\002 TIMES.\002//)";
    static char fmt_1020[] = "(\002 THERE ARE\002,i4,\002 BASE\002,i4,\002 S"
	    "IGNIFICANT DIGITS IN A FLOATING-POINT NUMBER\002//)";
    static char fmt_1021[] = "(\002 THE MAXIMUM RELATIVE ERROR OF\002,d15.4"
	    ",\002 = \002,i4,\002 **\002,f7.2/4x,\002OCCURRED FOR X =\002,d17"
	    ".6)";
    static char fmt_1022[] = "(\002 THE ESTIMATED LOSS OF BASE\002,i4,\002 S"
	    "IGNIFICANT DIGITS IS\002,f7.2//)";
    static char fmt_1023[] = "(\002 THE ROOT MEAN SQUARE RELATIVE ERROR WA"
	    "S\002,d15.4,\002 = \002,i4,\002 **\002,f7.2)";
    static char fmt_1025[] = "(\0021SPECIAL TESTS\002//)";
    static char fmt_1030[] = "(\002 THE IDENTITY  DTAN(-X) = -DTAN(X)  WILL "
	    "BE TESTED.\002//8x,\002X\002,9x,\002F(X) + F(-X)\002/)";
    static char fmt_1060[] = "(d15.7,d25.17/)";
    static char fmt_1031[] = "(\002 THE IDENTITY DTAN(X) = X , X SMALL, WILL"
	    " BE TESTED.\002//8x,\002X\002,9x,\002X - F(X)\002/)";
    static char fmt_1035[] = "(\002 TEST OF UNDERFLOW FOR VERY SMALL ARGUMEN"
	    "T.\002/)";
    static char fmt_1061[] = "(6x,\002 DTAN(\002,d23.16,\002) =\002,d23.16/)";
    static char fmt_1040[] = "(\002 THE RELATIVE ERROR IN DTAN(11) IS \002,d"
	    "15.7,\002 = \002,i4,\002 **\002,f7.2,\002 WHERE\002/)";
    static char fmt_1050[] = "(\0021TEST OF ERROR RETURNS\002//)";
    static char fmt_1051[] = "(\002 DTAN WILL BE CALLED WITH THE ARGUMENT"
	    "\002,d15.4/\002 THIS SHOULD NOT TRIGGER AN ERROR MESSAGE\002//)";
    static char fmt_1055[] = "(\002 DTAN RETURNED THE VALUE\002,d15.4///)";
    static char fmt_1052[] = "(\0020DTAN WILL BE CALLED WITH THE ARGUMENT"
	    "\002,d15.4/\002 THIS SHOULD TRIGGER AN ERROR MESSAGE\002//)";
    static char fmt_1100[] = "(\002 THIS CONCLUDES THE TESTS\002)";

    /* System generated locals */
    integer i__1;
    doublereal d__1;

    /* Builtin functions */
    double log(doublereal), tan(doublereal), sqrt(doublereal);
    integer s_wsfe(cilist *), e_wsfe(void), do_fio(integer *, char *, ftnlen);
    double pow_di(doublereal *, integer *), pow_dd(doublereal *, doublereal *)
	    ;

    /* Local variables */
    static doublereal a, b;
    static integer i__, j, n;
    static doublereal w, x, y, z__, c1, c2;
    static integer i1, k1, k2, k3;
    static doublereal r6, r7, x1, pi;
    static integer it;
    static doublereal xl, xn, zz, del, ait, eps, half, beta;
    extern doublereal dran_(integer *);
    static integer ngrd, irnd, iexp;
    static doublereal xmin, xmax, zero;
    static integer ibeta;
    static doublereal betap;
    static integer negep;
    static doublereal albeta;
    extern /* Subroutine */ int machar_(integer *, integer *, integer *, 
	    integer *, integer *, integer *, integer *, integer *, integer *, 
	    doublereal *, doublereal *, doublereal *, doublereal *);
    static integer machep;
    extern doublereal dcotan_(doublereal *);
    static doublereal epsneg;
    static integer minexp, maxexp;

    /* Fortran I/O blocks */
    static cilist io___605 = { 0, 0, 0, fmt_1000, 0 };
    static cilist io___606 = { 0, 0, 0, fmt_1005, 0 };
    static cilist io___607 = { 0, 0, 0, fmt_1010, 0 };
    static cilist io___608 = { 0, 0, 0, fmt_1011, 0 };
    static cilist io___609 = { 0, 0, 0, fmt_1012, 0 };
    static cilist io___610 = { 0, 0, 0, fmt_1020, 0 };
    static cilist io___611 = { 0, 0, 0, fmt_1021, 0 };
    static cilist io___612 = { 0, 0, 0, fmt_1022, 0 };
    static cilist io___613 = { 0, 0, 0, fmt_1023, 0 };
    static cilist io___614 = { 0, 0, 0, fmt_1022, 0 };
    static cilist io___615 = { 0, 0, 0, fmt_1025, 0 };
    static cilist io___616 = { 0, 0, 0, fmt_1030, 0 };
    static cilist io___617 = { 0, 0, 0, fmt_1060, 0 };
    static cilist io___618 = { 0, 0, 0, fmt_1031, 0 };
    static cilist io___620 = { 0, 0, 0, fmt_1060, 0 };
    static cilist io___621 = { 0, 0, 0, fmt_1035, 0 };
    static cilist io___622 = { 0, 0, 0, fmt_1061, 0 };
    static cilist io___625 = { 0, 0, 0, fmt_1040, 0 };
    static cilist io___626 = { 0, 0, 0, fmt_1061, 0 };
    static cilist io___627 = { 0, 0, 0, fmt_1022, 0 };
    static cilist io___628 = { 0, 0, 0, fmt_1050, 0 };
    static cilist io___629 = { 0, 0, 0, fmt_1051, 0 };
    static cilist io___630 = { 0, 0, 0, fmt_1055, 0 };
    static cilist io___631 = { 0, 0, 0, fmt_1052, 0 };
    static cilist io___632 = { 0, 0, 0, fmt_1055, 0 };
    static cilist io___633 = { 0, 0, 0, fmt_1100, 0 };


/*     PROGRAM TO TEST DTAN/DCOTAN */

/*     DATA REQUIRED */

/*        NONE */

/*     SUBPROGRAMS REQUIRED FROM THIS PACKAGE */

/*        MACHAR - AN ENVIRONMENTAL INQUIRY PROGRAM PROVIDING */
/*                 INFORMATION ON THE FLOATING-POINT ARITHMETIC */
/*                 SYSTEM.  NOTE THAT THE CALL TO MACHAR CAN */
/*                 BE DELETED PROVIDED THE FOLLOWING THREE */
/*                 PARAMETERS ARE ASSIGNED THE VALUES INDICATED */

/*                 IBETA  - THE RADIX OF THE FLOATING-POINT SYSTEM */
/*                 IT     - THE NUMBER OF BASE-IBETA DIGITS IN THE */
/*                          SIGNIFICAND OF A FLOATING-POINT NUMBER */
/*                 MINEXP - THE LARGEST IN MAGNITUDE NEGATIVE */
/*                          INTEGER SUCH THAT DFLOAT(IBETA)**MINEXP */
/*                          IS A POSITIVE FLOATING-POINT NUMBER */

/*        DRAN(K) - A FUNCTION SUBPROGRAM RETURNING RANDOM DOUBLE */
/*                 PRECISION NUMBERS UNIFORMLY DISTRIBUTED OVER */
/*                 (0,1) */


/*     STANDARD FORTRAN SUBPROGRAMS REQUIRED */

/*         DABS, DLOG, DMAX1, DCOTAN, DFLOAT, DTAN, DSQRT */


/*     LATEST REVISION - DECEMBER 6, 1979 */

/*     AUTHOR - W. J. CODY */
/*              ARGONNE NATIONAL LABORATORY */



/*     IOUT = 6 */
#line 1917 "talldp.f"
    machar_(&ibeta, &it, &irnd, &ngrd, &machep, &negep, &iexp, &minexp, &
	    maxexp, &eps, &epsneg, &xmin, &xmax);
#line 1919 "talldp.f"
    beta = (doublereal) ((real) ibeta);
#line 1920 "talldp.f"
    albeta = log(beta);
#line 1921 "talldp.f"
    zero = 0.;
#line 1922 "talldp.f"
    half = .5;
#line 1923 "talldp.f"
    ait = (doublereal) ((real) it);
/* #    PI = 3.14159265D+00 */
#line 1925 "talldp.f"
    pi = 3.141592653589793238462643383279502884197169399375105821;
#line 1926 "talldp.f"
    a = zero;
#line 1927 "talldp.f"
    b = pi * .25;
#line 1928 "talldp.f"
    n = 2000;
#line 1929 "talldp.f"
    xn = (doublereal) ((real) n);
#line 1930 "talldp.f"
    i1 = 0;
/* ----------------------------------------------------------------- */
/*     RANDOM ARGUMENT ACCURACY TESTS */
/* ----------------------------------------------------------------- */
#line 1934 "talldp.f"
    for (j = 1; j <= 4; ++j) {
#line 1935 "talldp.f"
	k1 = 0;
#line 1936 "talldp.f"
	k3 = 0;
#line 1937 "talldp.f"
	x1 = zero;
#line 1938 "talldp.f"
	r6 = zero;
#line 1939 "talldp.f"
	r7 = zero;
#line 1940 "talldp.f"
	del = (b - a) / xn;
#line 1941 "talldp.f"
	xl = a;

#line 1943 "talldp.f"
	i__1 = n;
#line 1943 "talldp.f"
	for (i__ = 1; i__ <= i__1; ++i__) {
#line 1944 "talldp.f"
	    x = del * dran_(&i1) + xl;
#line 1945 "talldp.f"
	    y = x * half;
#line 1946 "talldp.f"
	    x = y + y;
#line 1947 "talldp.f"
	    if (j == 4) {
#line 1947 "talldp.f"
		goto L80;
#line 1947 "talldp.f"
	    }
#line 1948 "talldp.f"
	    z__ = tan(x);
#line 1949 "talldp.f"
	    zz = tan(y);
#line 1950 "talldp.f"
	    w = 1.;
#line 1951 "talldp.f"
	    if (z__ == zero) {
#line 1951 "talldp.f"
		goto L110;
#line 1951 "talldp.f"
	    }
#line 1952 "talldp.f"
	    w = (half - zz + half) * (half + zz + half);
#line 1953 "talldp.f"
	    w = (z__ - (zz + zz) / w) / z__;
#line 1954 "talldp.f"
	    goto L110;
#line 1955 "talldp.f"
L80:
#line 1955 "talldp.f"
	    z__ = dcotan_(&x);
#line 1956 "talldp.f"
	    zz = dcotan_(&y);
#line 1957 "talldp.f"
	    w = 1.;
#line 1958 "talldp.f"
	    if (z__ == zero) {
#line 1958 "talldp.f"
		goto L110;
#line 1958 "talldp.f"
	    }
#line 1959 "talldp.f"
	    w = (half - zz + half) * (half + zz + half);
#line 1960 "talldp.f"
	    w = (z__ + w / (zz + zz)) / z__;
#line 1961 "talldp.f"
L110:
#line 1961 "talldp.f"
	    if (w > zero) {
#line 1961 "talldp.f"
		++k1;
#line 1961 "talldp.f"
	    }
#line 1962 "talldp.f"
	    if (w < zero) {
#line 1962 "talldp.f"
		++k3;
#line 1962 "talldp.f"
	    }
#line 1963 "talldp.f"
	    w = abs(w);
#line 1964 "talldp.f"
	    if (w <= r6) {
#line 1964 "talldp.f"
		goto L120;
#line 1964 "talldp.f"
	    }
#line 1965 "talldp.f"
	    r6 = w;
#line 1966 "talldp.f"
	    x1 = x;
#line 1967 "talldp.f"
L120:
#line 1967 "talldp.f"
	    r7 += w * w;
#line 1968 "talldp.f"
	    xl += del;
#line 1969 "talldp.f"
/* L200: */
#line 1969 "talldp.f"
	}

#line 1971 "talldp.f"
	k2 = n - k3 - k1;
#line 1972 "talldp.f"
	r7 = sqrt(r7 / xn);
#line 1973 "talldp.f"
	if (j != 4) {
#line 1973 "talldp.f"
	    io___605.ciunit = *iout;
#line 1973 "talldp.f"
	    s_wsfe(&io___605);
#line 1973 "talldp.f"
	    e_wsfe();
#line 1973 "talldp.f"
	}
#line 1974 "talldp.f"
	if (j == 4) {
#line 1974 "talldp.f"
	    io___606.ciunit = *iout;
#line 1974 "talldp.f"
	    s_wsfe(&io___606);
#line 1974 "talldp.f"
	    e_wsfe();
#line 1974 "talldp.f"
	}
#line 1975 "talldp.f"
	io___607.ciunit = *iout;
#line 1975 "talldp.f"
	s_wsfe(&io___607);
#line 1975 "talldp.f"
	do_fio(&c__1, (char *)&n, (ftnlen)sizeof(integer));
#line 1975 "talldp.f"
	do_fio(&c__1, (char *)&a, (ftnlen)sizeof(doublereal));
#line 1975 "talldp.f"
	do_fio(&c__1, (char *)&b, (ftnlen)sizeof(doublereal));
#line 1975 "talldp.f"
	e_wsfe();
#line 1976 "talldp.f"
	if (j != 4) {
#line 1976 "talldp.f"
	    io___608.ciunit = *iout;
#line 1976 "talldp.f"
	    s_wsfe(&io___608);
#line 1976 "talldp.f"
	    do_fio(&c__1, (char *)&k1, (ftnlen)sizeof(integer));
#line 1976 "talldp.f"
	    do_fio(&c__1, (char *)&k2, (ftnlen)sizeof(integer));
#line 1976 "talldp.f"
	    do_fio(&c__1, (char *)&k3, (ftnlen)sizeof(integer));
#line 1976 "talldp.f"
	    e_wsfe();
#line 1976 "talldp.f"
	}
#line 1977 "talldp.f"
	if (j == 4) {
#line 1977 "talldp.f"
	    io___609.ciunit = *iout;
#line 1977 "talldp.f"
	    s_wsfe(&io___609);
#line 1977 "talldp.f"
	    do_fio(&c__1, (char *)&k1, (ftnlen)sizeof(integer));
#line 1977 "talldp.f"
	    do_fio(&c__1, (char *)&k2, (ftnlen)sizeof(integer));
#line 1977 "talldp.f"
	    do_fio(&c__1, (char *)&k3, (ftnlen)sizeof(integer));
#line 1977 "talldp.f"
	    e_wsfe();
#line 1977 "talldp.f"
	}
#line 1978 "talldp.f"
	io___610.ciunit = *iout;
#line 1978 "talldp.f"
	s_wsfe(&io___610);
#line 1978 "talldp.f"
	do_fio(&c__1, (char *)&it, (ftnlen)sizeof(integer));
#line 1978 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 1978 "talldp.f"
	e_wsfe();
#line 1979 "talldp.f"
	w = -999.;
#line 1980 "talldp.f"
	if (r6 != zero) {
#line 1980 "talldp.f"
	    w = log((abs(r6))) / albeta;
#line 1980 "talldp.f"
	}
#line 1981 "talldp.f"
	io___611.ciunit = *iout;
#line 1981 "talldp.f"
	s_wsfe(&io___611);
#line 1981 "talldp.f"
	do_fio(&c__1, (char *)&r6, (ftnlen)sizeof(doublereal));
#line 1981 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 1981 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 1981 "talldp.f"
	do_fio(&c__1, (char *)&x1, (ftnlen)sizeof(doublereal));
#line 1981 "talldp.f"
	e_wsfe();
/* Computing MAX */
#line 1982 "talldp.f"
	d__1 = ait + w;
#line 1982 "talldp.f"
	w = max(d__1,zero);
#line 1983 "talldp.f"
	io___612.ciunit = *iout;
#line 1983 "talldp.f"
	s_wsfe(&io___612);
#line 1983 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 1983 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 1983 "talldp.f"
	e_wsfe();
#line 1984 "talldp.f"
	w = -999.;
#line 1985 "talldp.f"
	if (r7 != zero) {
#line 1985 "talldp.f"
	    w = log((abs(r7))) / albeta;
#line 1985 "talldp.f"
	}
#line 1986 "talldp.f"
	io___613.ciunit = *iout;
#line 1986 "talldp.f"
	s_wsfe(&io___613);
#line 1986 "talldp.f"
	do_fio(&c__1, (char *)&r7, (ftnlen)sizeof(doublereal));
#line 1986 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 1986 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 1986 "talldp.f"
	e_wsfe();
/* Computing MAX */
#line 1987 "talldp.f"
	d__1 = ait + w;
#line 1987 "talldp.f"
	w = max(d__1,zero);
#line 1988 "talldp.f"
	io___614.ciunit = *iout;
#line 1988 "talldp.f"
	s_wsfe(&io___614);
#line 1988 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 1988 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 1988 "talldp.f"
	e_wsfe();
#line 1989 "talldp.f"
	if (j != 1) {
#line 1989 "talldp.f"
	    goto L250;
#line 1989 "talldp.f"
	}
#line 1990 "talldp.f"
	a = pi * .875;
#line 1991 "talldp.f"
	b = pi * 1.125;
#line 1992 "talldp.f"
	goto L300;
#line 1993 "talldp.f"
L250:
#line 1993 "talldp.f"
	a = pi * 6.;
#line 1994 "talldp.f"
	b = a + pi * .25;
#line 1995 "talldp.f"
L300:
#line 1995 "talldp.f"
	;
#line 1995 "talldp.f"
    }
/* ----------------------------------------------------------------- */
/*     SPECIAL TESTS */
/* ----------------------------------------------------------------- */
#line 1999 "talldp.f"
    io___615.ciunit = *iout;
#line 1999 "talldp.f"
    s_wsfe(&io___615);
#line 1999 "talldp.f"
    e_wsfe();
#line 2000 "talldp.f"
    io___616.ciunit = *iout;
#line 2000 "talldp.f"
    s_wsfe(&io___616);
#line 2000 "talldp.f"
    e_wsfe();

#line 2002 "talldp.f"
    for (i__ = 1; i__ <= 5; ++i__) {
#line 2003 "talldp.f"
	x = dran_(&i1) * a;
#line 2004 "talldp.f"
	z__ = tan(x) + tan(-x);
#line 2005 "talldp.f"
	io___617.ciunit = *iout;
#line 2005 "talldp.f"
	s_wsfe(&io___617);
#line 2005 "talldp.f"
	do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 2005 "talldp.f"
	do_fio(&c__1, (char *)&z__, (ftnlen)sizeof(doublereal));
#line 2005 "talldp.f"
	e_wsfe();
#line 2006 "talldp.f"
/* L320: */
#line 2006 "talldp.f"
    }

#line 2008 "talldp.f"
    io___618.ciunit = *iout;
#line 2008 "talldp.f"
    s_wsfe(&io___618);
#line 2008 "talldp.f"
    e_wsfe();
#line 2009 "talldp.f"
    betap = pow_di(&beta, &it);
#line 2010 "talldp.f"
    x = dran_(&i1) / betap;

#line 2012 "talldp.f"
    for (i__ = 1; i__ <= 5; ++i__) {
#line 2013 "talldp.f"
	z__ = x - tan(x);
#line 2014 "talldp.f"
	io___620.ciunit = *iout;
#line 2014 "talldp.f"
	s_wsfe(&io___620);
#line 2014 "talldp.f"
	do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 2014 "talldp.f"
	do_fio(&c__1, (char *)&z__, (ftnlen)sizeof(doublereal));
#line 2014 "talldp.f"
	e_wsfe();
#line 2015 "talldp.f"
	x /= beta;
#line 2016 "talldp.f"
/* L330: */
#line 2016 "talldp.f"
    }

#line 2018 "talldp.f"
    io___621.ciunit = *iout;
#line 2018 "talldp.f"
    s_wsfe(&io___621);
#line 2018 "talldp.f"
    e_wsfe();
#line 2019 "talldp.f"
    d__1 = (doublereal) ((real) minexp) * .75;
#line 2019 "talldp.f"
    x = pow_dd(&beta, &d__1);
#line 2020 "talldp.f"
    y = tan(x);
#line 2021 "talldp.f"
    io___622.ciunit = *iout;
#line 2021 "talldp.f"
    s_wsfe(&io___622);
#line 2021 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 2021 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 2021 "talldp.f"
    e_wsfe();
#line 2022 "talldp.f"
    c1 = -225.;
#line 2023 "talldp.f"
    c2 = -.950846454195142026;
#line 2024 "talldp.f"
    x = 11.;
#line 2025 "talldp.f"
    y = tan(x);
#line 2026 "talldp.f"
    w = (c1 - y + c2) / (c1 + c2);
#line 2027 "talldp.f"
    z__ = log((abs(w))) / albeta;
#line 2028 "talldp.f"
    io___625.ciunit = *iout;
#line 2028 "talldp.f"
    s_wsfe(&io___625);
#line 2028 "talldp.f"
    do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 2028 "talldp.f"
    do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 2028 "talldp.f"
    do_fio(&c__1, (char *)&z__, (ftnlen)sizeof(doublereal));
#line 2028 "talldp.f"
    e_wsfe();
#line 2029 "talldp.f"
    io___626.ciunit = *iout;
#line 2029 "talldp.f"
    s_wsfe(&io___626);
#line 2029 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 2029 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 2029 "talldp.f"
    e_wsfe();
/* Computing MAX */
#line 2030 "talldp.f"
    d__1 = ait + z__;
#line 2030 "talldp.f"
    w = max(d__1,zero);
#line 2031 "talldp.f"
    io___627.ciunit = *iout;
#line 2031 "talldp.f"
    s_wsfe(&io___627);
#line 2031 "talldp.f"
    do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 2031 "talldp.f"
    do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 2031 "talldp.f"
    e_wsfe();
/* ----------------------------------------------------------------- */
/*     TEST OF ERROR RETURNS */
/* ----------------------------------------------------------------- */
#line 2035 "talldp.f"
    io___628.ciunit = *iout;
#line 2035 "talldp.f"
    s_wsfe(&io___628);
#line 2035 "talldp.f"
    e_wsfe();
#line 2036 "talldp.f"
    i__1 = it / 2;
#line 2036 "talldp.f"
    x = pow_di(&beta, &i__1);
#line 2037 "talldp.f"
    io___629.ciunit = *iout;
#line 2037 "talldp.f"
    s_wsfe(&io___629);
#line 2037 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 2037 "talldp.f"
    e_wsfe();
#line 2038 "talldp.f"
    y = tan(x);
#line 2039 "talldp.f"
    io___630.ciunit = *iout;
#line 2039 "talldp.f"
    s_wsfe(&io___630);
#line 2039 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 2039 "talldp.f"
    e_wsfe();
#line 2040 "talldp.f"
    x = betap;
#line 2041 "talldp.f"
    io___631.ciunit = *iout;
#line 2041 "talldp.f"
    s_wsfe(&io___631);
#line 2041 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 2041 "talldp.f"
    e_wsfe();
#line 2042 "talldp.f"
    y = tan(x);
#line 2043 "talldp.f"
    io___632.ciunit = *iout;
#line 2043 "talldp.f"
    s_wsfe(&io___632);
#line 2043 "talldp.f"
    do_fio(&c__1, (char *)&y, (ftnlen)sizeof(doublereal));
#line 2043 "talldp.f"
    e_wsfe();
#line 2044 "talldp.f"
    io___633.ciunit = *iout;
#line 2044 "talldp.f"
    s_wsfe(&io___633);
#line 2044 "talldp.f"
    e_wsfe();
#line 2045 "talldp.f"
    return 0;
/*     ---------- LAST CARD OF DTAN/DCOTAN TEST PROGRAM ---------- */
} /* tdtan_ */

/* Subroutine */ int tdtanh_(integer *iout)
{
    /* Format strings */
    static char fmt_1000[] = "(\0021TEST OF DTANH(X) VS \002,\002(DTANH(X-1/"
	    "8)+DTANH(1/8))/(1+DTANH(X-1/8)DTANH(1/8))  \002//)";
    static char fmt_1010[] = "(i7,\002 RANDOM ARGUMENTS WERE TESTED FROM THE"
	    " INTERVAL\002/6x,\002(\002,d15.4,\002,\002,d15.4,\002)\002//)";
    static char fmt_1011[] = "(\002 DTANH(X) WAS LARGER\002,i6,\002 TIMES"
	    ",\002/13x,\002 AGREED\002,i6,\002 TIMES, AND\002/9x,\002WAS SMAL"
	    "LER\002,i6,\002 TIMES.\002//)";
    static char fmt_1020[] = "(\002 THERE ARE\002,i4,\002 BASE\002,i4,\002 S"
	    "IGNIFICANT DIGITS IN A FLOATING-POINT NUMBER\002//)";
    static char fmt_1021[] = "(\002 THE MAXIMUM RELATIVE ERROR OF\002,d15.4"
	    ",\002 = \002,i4,\002 **\002,f7.2/4x,\002OCCURRED FOR X =\002,d17"
	    ".6)";
    static char fmt_1022[] = "(\002 THE ESTIMATED LOSS OF BASE\002,i4,\002 S"
	    "IGNIFICANT DIGITS IS\002,f7.2//)";
    static char fmt_1023[] = "(\002 THE ROOT MEAN SQUARE RELATIVE ERROR WA"
	    "S\002,d15.4,\002 = \002,i4,\002 **\002,f7.2)";
    static char fmt_1025[] = "(\0021SPECIAL TESTS\002//)";
    static char fmt_1030[] = "(\002 THE IDENTITY   DTANH(-X) = -DTANH(X)   W"
	    "ILL BE TESTED.\002//8x,\002X\002,9x,\002F(X) + F(-X)\002/)";
    static char fmt_1060[] = "(d15.7,d25.17/)";
    static char fmt_1031[] = "(\002 THE IDENTITY DTANH(X) = X , X SMALL, WIL"
	    "L BE TESTED.\002//8x,\002X\002,9x,\002X - F(X)\002/)";
    static char fmt_1032[] = "(\002 THE IDENTITY DTANH(X) = 1 , X LARGE, WIL"
	    "L BE TESTED.\002//8x,\002X\002,9x,\0021 - F(X)\002/)";
    static char fmt_1035[] = "(\002 TEST OF UNDERFLOW FOR VERY SMALL ARGUMEN"
	    "T.\002/)";
    static char fmt_1061[] = "(6x,\002 DTANH(\002,d13.6,\002) =\002,d13.6/)";
    static char fmt_1040[] = "(\002 THE FUNCTION DTANH WILL BE CALLED WITH T"
	    "HE ARGUMENT\002,d15.7)";
    static char fmt_1100[] = "(\002 THIS CONCLUDES THE TESTS\002)";

    /* System generated locals */
    integer i__1;
    doublereal d__1;

    /* Builtin functions */
    double log(doublereal), tanh(doublereal), sqrt(doublereal);
    integer s_wsfe(cilist *), e_wsfe(void), do_fio(integer *, char *, ftnlen);
    double pow_di(doublereal *, integer *), pow_dd(doublereal *, doublereal *)
	    ;

    /* Local variables */
    static doublereal a, b, c__, d__;
    static integer i__, j, n;
    static doublereal w, x, y, z__;
    static integer i1, k1, k2, k3;
    static doublereal r6, r7, x1;
    static integer it;
    static doublereal xl, xn, zz, del, ait, one, eps, half, beta;
    extern doublereal dran_(integer *);
    static integer ngrd, irnd, iexp;
    static doublereal xmin, xmax, zero;
    static integer ibeta;
    static doublereal betap;
    static integer negep;
    static doublereal expon, albeta;
    extern /* Subroutine */ int machar_(integer *, integer *, integer *, 
	    integer *, integer *, integer *, integer *, integer *, integer *, 
	    doublereal *, doublereal *, doublereal *, doublereal *);
    static integer machep;
    static doublereal epsneg;
    static integer minexp, maxexp;

    /* Fortran I/O blocks */
    static cilist io___675 = { 0, 0, 0, fmt_1000, 0 };
    static cilist io___676 = { 0, 0, 0, fmt_1010, 0 };
    static cilist io___677 = { 0, 0, 0, fmt_1011, 0 };
    static cilist io___678 = { 0, 0, 0, fmt_1020, 0 };
    static cilist io___679 = { 0, 0, 0, fmt_1021, 0 };
    static cilist io___680 = { 0, 0, 0, fmt_1022, 0 };
    static cilist io___681 = { 0, 0, 0, fmt_1023, 0 };
    static cilist io___682 = { 0, 0, 0, fmt_1022, 0 };
    static cilist io___683 = { 0, 0, 0, fmt_1025, 0 };
    static cilist io___684 = { 0, 0, 0, fmt_1030, 0 };
    static cilist io___685 = { 0, 0, 0, fmt_1060, 0 };
    static cilist io___686 = { 0, 0, 0, fmt_1031, 0 };
    static cilist io___688 = { 0, 0, 0, fmt_1060, 0 };
    static cilist io___689 = { 0, 0, 0, fmt_1032, 0 };
    static cilist io___690 = { 0, 0, 0, fmt_1060, 0 };
    static cilist io___691 = { 0, 0, 0, fmt_1035, 0 };
    static cilist io___693 = { 0, 0, 0, fmt_1061, 0 };
    static cilist io___694 = { 0, 0, 0, fmt_1040, 0 };
    static cilist io___695 = { 0, 0, 0, fmt_1061, 0 };
    static cilist io___696 = { 0, 0, 0, fmt_1040, 0 };
    static cilist io___697 = { 0, 0, 0, fmt_1061, 0 };
    static cilist io___698 = { 0, 0, 0, fmt_1040, 0 };
    static cilist io___699 = { 0, 0, 0, fmt_1061, 0 };
    static cilist io___700 = { 0, 0, 0, fmt_1100, 0 };


/*     PROGRAM TO TEST DTANH */

/*     DATA REQUIRED */

/*        NONE */

/*     SUBPROGRAMS REQUIRED FROM THIS PACKAGE */

/*        MACHAR - AN ENVIRONMENTAL INQUIRY PROGRAM PROVIDING */
/*                 INFORMATION ON THE FLOATING-POINT ARITHMETIC */
/*                 SYSTEM.  NOTE THAT THE CALL TO MACHAR CAN */
/*                 BE DELETED PROVIDED THE FOLLOWING FIVE */
/*                 PARAMETERS ARE ASSIGNED THE VALUES INDICATED */

/*                 IBETA  - THE RADIX OF THE FLOATING-POINT SYSTEM */
/*                 IT     - THE NUMBER OF BASE-IBETA DIGITS IN THE */
/*                          SIGNIFICAND OF A FLOATING-POINT NUMBER */
/*                 MINEXP - THE LARGEST IN MAGNITUDE NEGATIVE */
/*                          INTEGER SUCH THAT DFLOAT(IBETA)**MINEXP */
/*                          IS A POSITIVE FLOATING-POINT NUMBER */
/*                 XMIN   - THE SMALLEST NON-VANISHING FLOATING-POINT */
/*                          POWER OF THE RADIX */
/*                 XMAX   - THE LARGEST FINITE FLOATING-POINT NO. */

/*        DRAN(K) - A FUNCTION SUBPROGRAM RETURNING RANDOM DOUBLE */
/*                 PRECISION NUMBERS UNIFORMLY DISTRIBUTED OVER */
/*                 (0,1) */


/*     STANDARD FORTRAN SUBPROGRAMS REQUIRED */

/*         DABS, DLOG, DMAX1, DFLOAT, DSQRT, DTANH */


/*     LATEST REVISION - DECEMBER 6, 1979 */

/*     AUTHOR - W. J. CODY */
/*              ARGONNE NATIONAL LABORATORY */



/*     IOUT = 6 */
#line 2130 "talldp.f"
    machar_(&ibeta, &it, &irnd, &ngrd, &machep, &negep, &iexp, &minexp, &
	    maxexp, &eps, &epsneg, &xmin, &xmax);
#line 2132 "talldp.f"
    beta = (doublereal) ((real) ibeta);
#line 2133 "talldp.f"
    albeta = log(beta);
#line 2134 "talldp.f"
    ait = (doublereal) ((real) it);
#line 2135 "talldp.f"
    zero = 0.;
#line 2136 "talldp.f"
    one = 1.;
#line 2137 "talldp.f"
    half = .5;
#line 2138 "talldp.f"
    a = .125;
#line 2139 "talldp.f"
    b = log(3.) * half;
/* #    C = 1.2435300177159620805D-1 */
/* #    C = TANH(1/8) */
#line 2142 "talldp.f"
    c__ = .1243530017715962080546472758058927076759187925153387504;
#line 2143 "talldp.f"
    d__ = log(2.) + (ait + one) * log(beta) * half;
#line 2144 "talldp.f"
    n = 2000;
#line 2145 "talldp.f"
    xn = (doublereal) ((real) n);
#line 2146 "talldp.f"
    i1 = 0;
/* ----------------------------------------------------------------- */
/*     RANDOM ARGUMENT ACCURACY TESTS */
/* ----------------------------------------------------------------- */
#line 2150 "talldp.f"
    for (j = 1; j <= 2; ++j) {
#line 2151 "talldp.f"
	k1 = 0;
#line 2152 "talldp.f"
	k3 = 0;
#line 2153 "talldp.f"
	x1 = zero;
#line 2154 "talldp.f"
	r6 = zero;
#line 2155 "talldp.f"
	r7 = zero;
#line 2156 "talldp.f"
	del = (b - a) / xn;
#line 2157 "talldp.f"
	xl = a;

#line 2159 "talldp.f"
	i__1 = n;
#line 2159 "talldp.f"
	for (i__ = 1; i__ <= i__1; ++i__) {
#line 2160 "talldp.f"
	    x = del * dran_(&i1) + xl;
#line 2161 "talldp.f"
	    z__ = tanh(x);
#line 2162 "talldp.f"
	    y = x - .125;
#line 2163 "talldp.f"
	    zz = tanh(y);
#line 2164 "talldp.f"
	    zz = (zz + c__) / (one + c__ * zz);
#line 2165 "talldp.f"
	    w = one;
#line 2166 "talldp.f"
	    if (z__ != zero) {
#line 2166 "talldp.f"
		w = (z__ - zz) / z__;
#line 2166 "talldp.f"
	    }
#line 2167 "talldp.f"
	    if (w > zero) {
#line 2167 "talldp.f"
		++k1;
#line 2167 "talldp.f"
	    }
#line 2168 "talldp.f"
	    if (w < zero) {
#line 2168 "talldp.f"
		++k3;
#line 2168 "talldp.f"
	    }
#line 2169 "talldp.f"
	    w = abs(w);
#line 2170 "talldp.f"
	    if (w <= r6) {
#line 2170 "talldp.f"
		goto L120;
#line 2170 "talldp.f"
	    }
#line 2171 "talldp.f"
	    r6 = w;
#line 2172 "talldp.f"
	    x1 = x;
#line 2173 "talldp.f"
L120:
#line 2173 "talldp.f"
	    r7 += w * w;
#line 2174 "talldp.f"
	    xl += del;
#line 2175 "talldp.f"
/* L200: */
#line 2175 "talldp.f"
	}

#line 2177 "talldp.f"
	k2 = n - k3 - k1;
#line 2178 "talldp.f"
	r7 = sqrt(r7 / xn);
#line 2179 "talldp.f"
	io___675.ciunit = *iout;
#line 2179 "talldp.f"
	s_wsfe(&io___675);
#line 2179 "talldp.f"
	e_wsfe();
#line 2180 "talldp.f"
	io___676.ciunit = *iout;
#line 2180 "talldp.f"
	s_wsfe(&io___676);
#line 2180 "talldp.f"
	do_fio(&c__1, (char *)&n, (ftnlen)sizeof(integer));
#line 2180 "talldp.f"
	do_fio(&c__1, (char *)&a, (ftnlen)sizeof(doublereal));
#line 2180 "talldp.f"
	do_fio(&c__1, (char *)&b, (ftnlen)sizeof(doublereal));
#line 2180 "talldp.f"
	e_wsfe();
#line 2181 "talldp.f"
	io___677.ciunit = *iout;
#line 2181 "talldp.f"
	s_wsfe(&io___677);
#line 2181 "talldp.f"
	do_fio(&c__1, (char *)&k1, (ftnlen)sizeof(integer));
#line 2181 "talldp.f"
	do_fio(&c__1, (char *)&k2, (ftnlen)sizeof(integer));
#line 2181 "talldp.f"
	do_fio(&c__1, (char *)&k3, (ftnlen)sizeof(integer));
#line 2181 "talldp.f"
	e_wsfe();
#line 2182 "talldp.f"
	io___678.ciunit = *iout;
#line 2182 "talldp.f"
	s_wsfe(&io___678);
#line 2182 "talldp.f"
	do_fio(&c__1, (char *)&it, (ftnlen)sizeof(integer));
#line 2182 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 2182 "talldp.f"
	e_wsfe();
#line 2183 "talldp.f"
	w = -999.;
#line 2184 "talldp.f"
	if (r6 != zero) {
#line 2184 "talldp.f"
	    w = log((abs(r6))) / albeta;
#line 2184 "talldp.f"
	}
#line 2185 "talldp.f"
	io___679.ciunit = *iout;
#line 2185 "talldp.f"
	s_wsfe(&io___679);
#line 2185 "talldp.f"
	do_fio(&c__1, (char *)&r6, (ftnlen)sizeof(doublereal));
#line 2185 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 2185 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 2185 "talldp.f"
	do_fio(&c__1, (char *)&x1, (ftnlen)sizeof(doublereal));
#line 2185 "talldp.f"
	e_wsfe();
/* Computing MAX */
#line 2186 "talldp.f"
	d__1 = ait + w;
#line 2186 "talldp.f"
	w = max(d__1,zero);
#line 2187 "talldp.f"
	io___680.ciunit = *iout;
#line 2187 "talldp.f"
	s_wsfe(&io___680);
#line 2187 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 2187 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 2187 "talldp.f"
	e_wsfe();
#line 2188 "talldp.f"
	w = -999.;
#line 2189 "talldp.f"
	if (r7 != zero) {
#line 2189 "talldp.f"
	    w = log((abs(r7))) / albeta;
#line 2189 "talldp.f"
	}
#line 2190 "talldp.f"
	io___681.ciunit = *iout;
#line 2190 "talldp.f"
	s_wsfe(&io___681);
#line 2190 "talldp.f"
	do_fio(&c__1, (char *)&r7, (ftnlen)sizeof(doublereal));
#line 2190 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 2190 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 2190 "talldp.f"
	e_wsfe();
/* Computing MAX */
#line 2191 "talldp.f"
	d__1 = ait + w;
#line 2191 "talldp.f"
	w = max(d__1,zero);
#line 2192 "talldp.f"
	io___682.ciunit = *iout;
#line 2192 "talldp.f"
	s_wsfe(&io___682);
#line 2192 "talldp.f"
	do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 2192 "talldp.f"
	do_fio(&c__1, (char *)&w, (ftnlen)sizeof(doublereal));
#line 2192 "talldp.f"
	e_wsfe();
#line 2193 "talldp.f"
	a = b + a;
#line 2194 "talldp.f"
	b = d__;
#line 2195 "talldp.f"
/* L300: */
#line 2195 "talldp.f"
    }
/* ----------------------------------------------------------------- */
/*     SPECIAL TESTS */
/* ----------------------------------------------------------------- */
#line 2199 "talldp.f"
    io___683.ciunit = *iout;
#line 2199 "talldp.f"
    s_wsfe(&io___683);
#line 2199 "talldp.f"
    e_wsfe();
#line 2200 "talldp.f"
    io___684.ciunit = *iout;
#line 2200 "talldp.f"
    s_wsfe(&io___684);
#line 2200 "talldp.f"
    e_wsfe();

#line 2202 "talldp.f"
    for (i__ = 1; i__ <= 5; ++i__) {
#line 2203 "talldp.f"
	x = dran_(&i1);
#line 2204 "talldp.f"
	z__ = tanh(x) + tanh(-x);
#line 2205 "talldp.f"
	io___685.ciunit = *iout;
#line 2205 "talldp.f"
	s_wsfe(&io___685);
#line 2205 "talldp.f"
	do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 2205 "talldp.f"
	do_fio(&c__1, (char *)&z__, (ftnlen)sizeof(doublereal));
#line 2205 "talldp.f"
	e_wsfe();
#line 2206 "talldp.f"
/* L320: */
#line 2206 "talldp.f"
    }

#line 2208 "talldp.f"
    io___686.ciunit = *iout;
#line 2208 "talldp.f"
    s_wsfe(&io___686);
#line 2208 "talldp.f"
    e_wsfe();
#line 2209 "talldp.f"
    betap = pow_di(&beta, &it);
#line 2210 "talldp.f"
    x = dran_(&i1) / betap;

#line 2212 "talldp.f"
    for (i__ = 1; i__ <= 5; ++i__) {
#line 2213 "talldp.f"
	z__ = x - tanh(x);
#line 2214 "talldp.f"
	io___688.ciunit = *iout;
#line 2214 "talldp.f"
	s_wsfe(&io___688);
#line 2214 "talldp.f"
	do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 2214 "talldp.f"
	do_fio(&c__1, (char *)&z__, (ftnlen)sizeof(doublereal));
#line 2214 "talldp.f"
	e_wsfe();
#line 2215 "talldp.f"
	x /= beta;
#line 2216 "talldp.f"
/* L330: */
#line 2216 "talldp.f"
    }

#line 2218 "talldp.f"
    io___689.ciunit = *iout;
#line 2218 "talldp.f"
    s_wsfe(&io___689);
#line 2218 "talldp.f"
    e_wsfe();
#line 2219 "talldp.f"
    x = d__;
#line 2220 "talldp.f"
    b = 4.;

#line 2222 "talldp.f"
    for (i__ = 1; i__ <= 5; ++i__) {
#line 2223 "talldp.f"
	z__ = tanh(x) - half - half;
#line 2224 "talldp.f"
	io___690.ciunit = *iout;
#line 2224 "talldp.f"
	s_wsfe(&io___690);
#line 2224 "talldp.f"
	do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 2224 "talldp.f"
	do_fio(&c__1, (char *)&z__, (ftnlen)sizeof(doublereal));
#line 2224 "talldp.f"
	e_wsfe();
#line 2225 "talldp.f"
	x += b;
#line 2226 "talldp.f"
/* L340: */
#line 2226 "talldp.f"
    }

#line 2228 "talldp.f"
    io___691.ciunit = *iout;
#line 2228 "talldp.f"
    s_wsfe(&io___691);
#line 2228 "talldp.f"
    e_wsfe();
#line 2229 "talldp.f"
    expon = (doublereal) ((real) minexp) * .75;
#line 2230 "talldp.f"
    x = pow_dd(&beta, &expon);
#line 2231 "talldp.f"
    z__ = tanh(x);
#line 2232 "talldp.f"
    io___693.ciunit = *iout;
#line 2232 "talldp.f"
    s_wsfe(&io___693);
#line 2232 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 2232 "talldp.f"
    do_fio(&c__1, (char *)&z__, (ftnlen)sizeof(doublereal));
#line 2232 "talldp.f"
    e_wsfe();
#line 2233 "talldp.f"
    io___694.ciunit = *iout;
#line 2233 "talldp.f"
    s_wsfe(&io___694);
#line 2233 "talldp.f"
    do_fio(&c__1, (char *)&xmax, (ftnlen)sizeof(doublereal));
#line 2233 "talldp.f"
    e_wsfe();
#line 2234 "talldp.f"
    z__ = tanh(xmax);
#line 2235 "talldp.f"
    io___695.ciunit = *iout;
#line 2235 "talldp.f"
    s_wsfe(&io___695);
#line 2235 "talldp.f"
    do_fio(&c__1, (char *)&xmax, (ftnlen)sizeof(doublereal));
#line 2235 "talldp.f"
    do_fio(&c__1, (char *)&z__, (ftnlen)sizeof(doublereal));
#line 2235 "talldp.f"
    e_wsfe();
#line 2236 "talldp.f"
    io___696.ciunit = *iout;
#line 2236 "talldp.f"
    s_wsfe(&io___696);
#line 2236 "talldp.f"
    do_fio(&c__1, (char *)&xmin, (ftnlen)sizeof(doublereal));
#line 2236 "talldp.f"
    e_wsfe();
#line 2237 "talldp.f"
    z__ = tanh(xmin);
#line 2238 "talldp.f"
    io___697.ciunit = *iout;
#line 2238 "talldp.f"
    s_wsfe(&io___697);
#line 2238 "talldp.f"
    do_fio(&c__1, (char *)&xmin, (ftnlen)sizeof(doublereal));
#line 2238 "talldp.f"
    do_fio(&c__1, (char *)&z__, (ftnlen)sizeof(doublereal));
#line 2238 "talldp.f"
    e_wsfe();
#line 2239 "talldp.f"
    x = zero;
#line 2240 "talldp.f"
    io___698.ciunit = *iout;
#line 2240 "talldp.f"
    s_wsfe(&io___698);
#line 2240 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 2240 "talldp.f"
    e_wsfe();
#line 2241 "talldp.f"
    z__ = tanh(x);
#line 2242 "talldp.f"
    io___699.ciunit = *iout;
#line 2242 "talldp.f"
    s_wsfe(&io___699);
#line 2242 "talldp.f"
    do_fio(&c__1, (char *)&x, (ftnlen)sizeof(doublereal));
#line 2242 "talldp.f"
    do_fio(&c__1, (char *)&z__, (ftnlen)sizeof(doublereal));
#line 2242 "talldp.f"
    e_wsfe();
#line 2243 "talldp.f"
    io___700.ciunit = *iout;
#line 2243 "talldp.f"
    s_wsfe(&io___700);
#line 2243 "talldp.f"
    e_wsfe();
#line 2244 "talldp.f"
    return 0;
/*     ---------- LAST CARD OF DTANH TEST PROGRAM ---------- */
} /* tdtanh_ */

doublereal dran_(integer *k)
{
    /* Initialized data */

    static integer iy = 100001;

    /* System generated locals */
    doublereal ret_val;

    /* Local variables */
    static integer j;


/*     RANDOM NUMBER GENERATOR - BASED ON ALGORITHM 266 BY PIKE AND */
/*      HILL (MODIFIED BY HANSSON), COMMUNICATIONS OF THE ACM, */
/*      VOL. 8, NO. 10, OCTOBER 1965. */

/*     THE SINGLE PRECISION VERSION OF THIS SUBPROGRAM IS INTENDED */
/*     FOR USE ON COMPUTERS WITH FIXED POINT WORDLENGTH OF AT */
/*     LEAST 29 BITS.  IT IS BEST IF THE FLOATING POINT */
/*     SIGNIFICAND HAS AT MOST 29 BITS. */

/*     FOLLOWING CODY AND WAITE'S RECOMMENDATION (P. 14), WE */
/*     PRODUCE A PAIR OF RANDOM NUMBERS AND USE RAN1 + */
/*     2**(-29)*RAN2 IN AN ATTEMPT TO GENERATE ABOUT 58 RANDOM BITS. */


#line 2293 "talldp.f"
    j = *k;
#line 2294 "talldp.f"
    iy *= 125;
#line 2295 "talldp.f"
    iy -= iy / 2796203 * 2796203;
#line 2296 "talldp.f"
    ret_val = (doublereal) ((real) iy) / 2796203.;

#line 2298 "talldp.f"
    iy *= 125;
#line 2299 "talldp.f"
    iy -= iy / 2796203 * 2796203;
#line 2300 "talldp.f"
    ret_val += (doublereal) ((real) iy) / 2796203. / 536870912.;
#line 2301 "talldp.f"
    return ret_val;
/*     ---------- LAST CARD OF DRAN ---------- */
} /* dran_ */

doublereal drandl_(doublereal *x)
{
    /* Initialized data */

    static integer k = 1;

    /* System generated locals */
    doublereal ret_val;

    /* Builtin functions */
    double exp(doublereal);

    /* Local variables */
    extern doublereal dran_(integer *);


/*     RETURNS PSEUDO RANDOM NUMBERS LOGARITHMICALLY DISTRIBUTED */
/*     OVER (1,DEXP(X)).  THUS A*DRANDL(LN(B/A)) IS LOGARITHMICALLY */
/*     DISTRIBUTED IN (A,B). */

/*     OTHER SUBROUTINES REQUIRED */

/*        DEXP(X) - THE EXPONENTIAL ROUTINE */

/*        DRAN(K) - A FUNCTION PROGRAM RETURNING RANDOM DOUBLE */
/*                 PRECISION NUMBERS UNIFORMLY DISTRIBUTED OVER */
/*                 (0,1).  THE ARGUMENT K IS A DUMMY. */



#line 2323 "talldp.f"
    ret_val = exp(*x * dran_(&k));
#line 2324 "talldp.f"
    return ret_val;
/*     ---------- LAST CARD OF DRANDL ---------- */
} /* drandl_ */

/* Subroutine */ int tsmach_(integer *iout)
{
    /* Format strings */
    static char fmt_1000[] = "(\0021IBETA (floating-point base)          "
	    " \002,i25/\002 IT (number of significand digits)     \002,i25"
	    "/\002 IRND (0: chops, >=1: rounds)          \002,i25/\002 NGRD ("
	    "number of guard digits)         \002,i25/\002 MACHEP (see MACHAR"
	    ")                   \002,i25/\002 NEGEPS (see MACHAR)           "
	    "        \002,i25/\002 IEXP (number of exponent bits)        \002"
	    ",i25/\002 MINEXP (exponent of min fp number)    \002,i25/\002 MA"
	    "XEXP (exponent of max fp number)    \002,i25/\002 EPS (machine e"
	    "psilon: 1 + e .ne. 1)   \002,1pd25.16/\002 EPSNEG (machine epsil"
	    "on: 1 - e .ne. 1)\002,1pd25.16/\002 XMIN (smallest fp number)   "
	    "          \002,1pd25.16/\002 XMAX (largest fp number)           "
	    "   \002,1pd25.16)";

    /* Builtin functions */
    integer s_wsfe(cilist *), do_fio(integer *, char *, ftnlen), e_wsfe(void);

    /* Local variables */
    static integer it;
    static doublereal eps;
    static integer ngrd, irnd, iexp;
    static doublereal xmin, xmax;
    static integer ibeta, negep;
    extern /* Subroutine */ int machar_(integer *, integer *, integer *, 
	    integer *, integer *, integer *, integer *, integer *, integer *, 
	    doublereal *, doublereal *, doublereal *, doublereal *);
    static integer machep;
    static doublereal epsneg;
    static integer minexp, maxexp;

    /* Fortran I/O blocks */
    static cilist io___717 = { 0, 0, 0, fmt_1000, 0 };


/*     (Test MACHAR) */
/*     Print the values returned by MACHAR() as a check on the */
/*     evironmental values. */
/*     (20-Mar-1993) */
#line 2336 "talldp.f"
    machar_(&ibeta, &it, &irnd, &ngrd, &machep, &negep, &iexp, &minexp, &
	    maxexp, &eps, &epsneg, &xmin, &xmax);
#line 2338 "talldp.f"
    io___717.ciunit = *iout;
#line 2338 "talldp.f"
    s_wsfe(&io___717);
#line 2338 "talldp.f"
    do_fio(&c__1, (char *)&ibeta, (ftnlen)sizeof(integer));
#line 2338 "talldp.f"
    do_fio(&c__1, (char *)&it, (ftnlen)sizeof(integer));
#line 2338 "talldp.f"
    do_fio(&c__1, (char *)&irnd, (ftnlen)sizeof(integer));
#line 2338 "talldp.f"
    do_fio(&c__1, (char *)&ngrd, (ftnlen)sizeof(integer));
#line 2338 "talldp.f"
    do_fio(&c__1, (char *)&machep, (ftnlen)sizeof(integer));
#line 2338 "talldp.f"
    do_fio(&c__1, (char *)&negep, (ftnlen)sizeof(integer));
#line 2338 "talldp.f"
    do_fio(&c__1, (char *)&iexp, (ftnlen)sizeof(integer));
#line 2338 "talldp.f"
    do_fio(&c__1, (char *)&minexp, (ftnlen)sizeof(integer));
#line 2338 "talldp.f"
    do_fio(&c__1, (char *)&maxexp, (ftnlen)sizeof(integer));
#line 2338 "talldp.f"
    do_fio(&c__1, (char *)&eps, (ftnlen)sizeof(doublereal));
#line 2338 "talldp.f"
    do_fio(&c__1, (char *)&epsneg, (ftnlen)sizeof(doublereal));
#line 2338 "talldp.f"
    do_fio(&c__1, (char *)&xmin, (ftnlen)sizeof(doublereal));
#line 2338 "talldp.f"
    do_fio(&c__1, (char *)&xmax, (ftnlen)sizeof(doublereal));
#line 2338 "talldp.f"
    e_wsfe();
#line 2340 "talldp.f"
    return 0;
} /* tsmach_ */

doublereal store_(doublereal *x)
{
    /* System generated locals */
    doublereal ret_val;

#line 2357 "talldp.f"
    ret_val = *x;
#line 2358 "talldp.f"
    return ret_val;
} /* store_ */

/* Subroutine */ int machar_(integer *ibeta, integer *it, integer *irnd, 
	integer *ngrd, integer *machep, integer *negep, integer *iexp, 
	integer *minexp, integer *maxexp, doublereal *eps, doublereal *epsneg,
	 doublereal *xmin, doublereal *xmax)
{
    /* System generated locals */
    integer i__1;
    doublereal d__1, d__2;

    /* Local variables */
    static doublereal a, b;
    static integer i__, j, k;
    static doublereal t, y, z__;
    static integer iz, mx;
    static doublereal one, two, beta, temp, zero, temp1, betah, tempa;
    static integer itemp;
    extern doublereal store_(doublereal *);
    static integer nxres;
    static doublereal betain;

/*      ALGORITHM 665, COLLECTED ALGORITHMS FROM ACM. */
/*      THIS WORK PUBLISHED IN TRANSACTIONS ON MATHEMATICAL SOFTWARE, */
/*      VOL. 14, NO. 4, PP. 303-311. */
/* ----------------------------------------------------------------------- */
/*  This Fortran 77 subroutine is intended to determine the parameters */
/*   of the floating-point arithmetic system specified below.  The */
/*   determination of the first three uses an extension of an algorithm */
/*   due to M. Malcolm, CACM 15 (1972), pp. 949-951, incorporating some, */
/*   but not all, of the improvements suggested by M. Gentleman and S. */
/*   Marovich, CACM 17 (1974), pp. 276-277.  An earlier version of this */
/*   program was published in the book Software Manual for the */
/*   Elementary Functions by W. J. Cody and W. Waite, Prentice-Hall, */
/*   Englewood Cliffs, NJ, 1980. */

/*  The program as given here must be modified before compiling.  If */
/*   a single (double) precision version is desired, change all */
/*   occurrences of CS (CD) in columns 1 and 2 to blanks. */

/*  Parameter values reported are as follows: */

/*       IBETA   - the radix for the floating-point representation */
/*       IT      - the number of base IBETA digits in the floating-point */
/*                 significand */
/*       IRND    - 0 if floating-point addition chops */
/*                 1 if floating-point addition rounds, but not in the */
/*                   IEEE style */
/*                 2 if floating-point addition rounds in the IEEE style */
/*                 3 if floating-point addition chops, and there is */
/*                   partial underflow */
/*                 4 if floating-point addition rounds, but not in the */
/*                   IEEE style, and there is partial underflow */
/*                 5 if floating-point addition rounds in the IEEE style, */
/*                   and there is partial underflow */
/*       NGRD    - the number of guard digits for multiplication with */
/*                 truncating arithmetic.  It is */
/*                 0 if floating-point arithmetic rounds, or if it */
/*                   truncates and only  IT  base  IBETA digits */
/*                   participate in the post-normalization shift of the */
/*                   floating-point significand in multiplication; */
/*                 1 if floating-point arithmetic truncates and more */
/*                   than  IT  base  IBETA  digits participate in the */
/*                   post-normalization shift of the floating-point */
/*                   significand in multiplication. */
/*       MACHEP  - the largest negative integer such that */
/*                 1.0+FLOAT(IBETA)**MACHEP .NE. 1.0, except that */
/*                 MACHEP is bounded below by  -(IT+3) */
/*       NEGEPS  - the largest negative integer such that */
/*                 1.0-FLOAT(IBETA)**NEGEPS .NE. 1.0, except that */
/*                 NEGEPS is bounded below by  -(IT+3) */
/*       IEXP    - the number of bits (decimal places if IBETA = 10) */
/*                 reserved for the representation of the exponent */
/*                 (including the bias or sign) of a floating-point */
/*                 number */
/*       MINEXP  - the largest in magnitude negative integer such that */
/*                 FLOAT(IBETA)**MINEXP is positive and normalized */
/*       MAXEXP  - the smallest positive power of  BETA  that overflows */
/*       EPS     - the smallest positive floating-point number such */
/*                 that  1.0+EPS .NE. 1.0. In particular, if either */
/*                 IBETA = 2  or  IRND = 0, EPS = FLOAT(IBETA)**MACHEP. */
/*                 Otherwise,  EPS = (FLOAT(IBETA)**MACHEP)/2 */
/*       EPSNEG  - A small positive floating-point number such that */
/*                 1.0-EPSNEG .NE. 1.0. In particular, if IBETA = 2 */
/*                 or  IRND = 0, EPSNEG = FLOAT(IBETA)**NEGEPS. */
/*                 Otherwise,  EPSNEG = (IBETA**NEGEPS)/2.  Because */
/*                 NEGEPS is bounded below by -(IT+3), EPSNEG may not */
/*                 be the smallest number that can alter 1.0 by */
/*                 subtraction. */
/*       XMIN    - the smallest non-vanishing normalized floating-point */
/*                 power of the radix, i.e.,  XMIN = FLOAT(IBETA)**MINEXP */
/*       XMAX    - the largest finite floating-point number.  In */
/*                 particular  XMAX = (1.0-EPSNEG)*FLOAT(IBETA)**MAXEXP */
/*                 Note - on some machines  XMAX  will be only the */
/*                 second, or perhaps third, largest number, being */
/*                 too small by 1 or 2 units in the last digit of */
/*                 the significand. */

/*     Latest revision - April 20, 1987 */

/*     Author - W. J. Cody */
/*              Argonne National Laboratory */

/* ----------------------------------------------------------------------- */
/* S    REAL A,B,BETA,BETAIN,BETAH,CONV,EPS,EPSNEG,ONE,T,TEMP,TEMPA, */
/* S   1     TEMP1,TWO,XMAX,XMIN,Y,Z,ZERO */
/* S    REAL STORE */
/* ----------------------------------------------------------------------- */
/* S    CONV(I) = REAL(I) */
#line 2454 "talldp.f"
    one = 1.;
#line 2455 "talldp.f"
    two = one + one;
#line 2456 "talldp.f"
    zero = one - one;
/* ----------------------------------------------------------------------- */
/*  Determine IBETA, BETA ala Malcolm. */
/* ----------------------------------------------------------------------- */
#line 2460 "talldp.f"
    a = one;
#line 2461 "talldp.f"
L10:
#line 2461 "talldp.f"
    a += a;
#line 2462 "talldp.f"
    d__1 = a + one;
#line 2462 "talldp.f"
    temp = store_(&d__1);
#line 2463 "talldp.f"
    d__1 = temp - a;
#line 2463 "talldp.f"
    temp1 = store_(&d__1);
#line 2464 "talldp.f"
    d__1 = temp1 - one;
#line 2464 "talldp.f"
    if (store_(&d__1) == zero) {
#line 2464 "talldp.f"
	goto L10;
#line 2464 "talldp.f"
    }
#line 2465 "talldp.f"
    b = one;
#line 2466 "talldp.f"
L20:
#line 2466 "talldp.f"
    b += b;
#line 2467 "talldp.f"
    d__1 = a + b;
#line 2467 "talldp.f"
    temp = store_(&d__1);
#line 2468 "talldp.f"
    d__1 = temp - a;
#line 2468 "talldp.f"
    itemp = (integer) store_(&d__1);
#line 2469 "talldp.f"
    if (itemp == 0) {
#line 2469 "talldp.f"
	goto L20;
#line 2469 "talldp.f"
    }
#line 2470 "talldp.f"
    *ibeta = itemp;
#line 2471 "talldp.f"
    beta = (doublereal) (*ibeta);
/* ----------------------------------------------------------------------- */
/*  Determine IT, IRND. */
/* ----------------------------------------------------------------------- */
#line 2475 "talldp.f"
    *it = 0;
#line 2476 "talldp.f"
    b = one;
#line 2477 "talldp.f"
L100:
#line 2477 "talldp.f"
    ++(*it);
#line 2478 "talldp.f"
    b *= beta;
#line 2479 "talldp.f"
    d__1 = b + one;
#line 2479 "talldp.f"
    temp = store_(&d__1);
#line 2480 "talldp.f"
    d__1 = temp - b;
#line 2480 "talldp.f"
    temp1 = store_(&d__1);
#line 2481 "talldp.f"
    d__1 = temp1 - one;
#line 2481 "talldp.f"
    if (store_(&d__1) == zero) {
#line 2481 "talldp.f"
	goto L100;
#line 2481 "talldp.f"
    }
#line 2482 "talldp.f"
    *irnd = 0;
#line 2483 "talldp.f"
    betah = beta / two;
#line 2484 "talldp.f"
    d__1 = a + betah;
#line 2484 "talldp.f"
    temp = store_(&d__1);
#line 2485 "talldp.f"
    d__1 = temp - a;
#line 2485 "talldp.f"
    if (store_(&d__1) != zero) {
#line 2485 "talldp.f"
	*irnd = 1;
#line 2485 "talldp.f"
    }
#line 2486 "talldp.f"
    d__1 = a + beta;
#line 2486 "talldp.f"
    tempa = store_(&d__1);
#line 2487 "talldp.f"
    d__1 = tempa + betah;
#line 2487 "talldp.f"
    temp = store_(&d__1);
#line 2488 "talldp.f"
    d__1 = temp - tempa;
#line 2488 "talldp.f"
    if (*irnd == 0 && store_(&d__1) != zero) {
#line 2488 "talldp.f"
	*irnd = 2;
#line 2488 "talldp.f"
    }
/* ----------------------------------------------------------------------- */
/*  Determine NEGEP, EPSNEG. */
/* ----------------------------------------------------------------------- */
#line 2492 "talldp.f"
    *negep = *it + 3;
#line 2493 "talldp.f"
    betain = one / beta;
#line 2494 "talldp.f"
    a = one;
#line 2495 "talldp.f"
    i__1 = *negep;
#line 2495 "talldp.f"
    for (i__ = 1; i__ <= i__1; ++i__) {
#line 2496 "talldp.f"
	a *= betain;
#line 2497 "talldp.f"
/* L200: */
#line 2497 "talldp.f"
    }
#line 2498 "talldp.f"
    b = a;
#line 2499 "talldp.f"
L210:
#line 2499 "talldp.f"
    d__1 = one - a;
#line 2499 "talldp.f"
    temp = store_(&d__1);
#line 2500 "talldp.f"
    d__1 = temp - one;
#line 2500 "talldp.f"
    if (store_(&d__1) != zero) {
#line 2500 "talldp.f"
	goto L220;
#line 2500 "talldp.f"
    }
#line 2501 "talldp.f"
    a *= beta;
#line 2502 "talldp.f"
    --(*negep);
#line 2503 "talldp.f"
    goto L210;
#line 2504 "talldp.f"
L220:
#line 2504 "talldp.f"
    *negep = -(*negep);
#line 2505 "talldp.f"
    *epsneg = a;
#line 2506 "talldp.f"
    if (*ibeta == 2 || *irnd == 0) {
#line 2506 "talldp.f"
	goto L300;
#line 2506 "talldp.f"
    }
#line 2507 "talldp.f"
    d__1 = one + a;
#line 2507 "talldp.f"
    a = a * store_(&d__1) / two;
#line 2508 "talldp.f"
    d__1 = one - a;
#line 2508 "talldp.f"
    temp = store_(&d__1);
#line 2509 "talldp.f"
    d__1 = temp - one;
#line 2509 "talldp.f"
    if (store_(&d__1) != zero) {
#line 2509 "talldp.f"
	*epsneg = a;
#line 2509 "talldp.f"
    }
/* ----------------------------------------------------------------------- */
/*  Determine MACHEP, EPS. */
/* ----------------------------------------------------------------------- */
#line 2513 "talldp.f"
L300:
#line 2513 "talldp.f"
    *machep = -(*it) - 3;
#line 2514 "talldp.f"
    a = b;
#line 2515 "talldp.f"
L310:
#line 2515 "talldp.f"
    d__1 = one + a;
#line 2515 "talldp.f"
    temp = store_(&d__1);
#line 2516 "talldp.f"
    d__1 = temp - one;
#line 2516 "talldp.f"
    if (store_(&d__1) != zero) {
#line 2516 "talldp.f"
	goto L320;
#line 2516 "talldp.f"
    }
#line 2517 "talldp.f"
    a *= beta;
#line 2518 "talldp.f"
    ++(*machep);
#line 2519 "talldp.f"
    goto L310;
#line 2520 "talldp.f"
L320:
#line 2520 "talldp.f"
    *eps = a;
#line 2521 "talldp.f"
    d__1 = tempa + beta * (one + *eps);
#line 2521 "talldp.f"
    temp = store_(&d__1);
#line 2522 "talldp.f"
    if (*ibeta == 2 || *irnd == 0) {
#line 2522 "talldp.f"
	goto L350;
#line 2522 "talldp.f"
    }
#line 2523 "talldp.f"
    d__2 = one + a;
#line 2523 "talldp.f"
    d__1 = a * store_(&d__2) / two;
#line 2523 "talldp.f"
    a = store_(&d__1);
#line 2524 "talldp.f"
    d__1 = one + a;
#line 2524 "talldp.f"
    temp = store_(&d__1);
#line 2525 "talldp.f"
    d__1 = temp - one;
#line 2525 "talldp.f"
    if (store_(&d__1) != zero) {
#line 2525 "talldp.f"
	*eps = a;
#line 2525 "talldp.f"
    }
/* ----------------------------------------------------------------------- */
/*  Determine NGRD. */
/* ----------------------------------------------------------------------- */
#line 2529 "talldp.f"
L350:
#line 2529 "talldp.f"
    *ngrd = 0;
#line 2530 "talldp.f"
    d__1 = one + *eps;
#line 2530 "talldp.f"
    temp = store_(&d__1);
#line 2531 "talldp.f"
    d__1 = temp * one - one;
#line 2531 "talldp.f"
    if (*irnd == 0 && store_(&d__1) != zero) {
#line 2531 "talldp.f"
	*ngrd = 1;
#line 2531 "talldp.f"
    }
/* ----------------------------------------------------------------------- */
/*  Determine IEXP, MINEXP, XMIN. */

/*  Loop to determine largest I and K = 2**I such that */
/*         (1/BETA) ** (2**(I)) */
/*  does not underflow. */
/*  Exit from loop is signaled by an underflow. */
/* ----------------------------------------------------------------------- */
#line 2540 "talldp.f"
    i__ = 0;
#line 2541 "talldp.f"
    k = 1;
#line 2542 "talldp.f"
    z__ = betain;
#line 2543 "talldp.f"
    t = one + *eps;
#line 2544 "talldp.f"
    nxres = 0;
#line 2545 "talldp.f"
L400:
#line 2545 "talldp.f"
    y = z__;
#line 2546 "talldp.f"
    z__ = y * y;
/* ----------------------------------------------------------------------- */
/*  Check for underflow here. */
/* ----------------------------------------------------------------------- */
#line 2550 "talldp.f"
    a = z__ * one;
#line 2551 "talldp.f"
    temp = z__ * t;
#line 2552 "talldp.f"
    d__1 = a + a;
#line 2552 "talldp.f"
    if (store_(&d__1) == zero || abs(z__) >= y) {
#line 2552 "talldp.f"
	goto L410;
#line 2552 "talldp.f"
    }
#line 2553 "talldp.f"
    temp1 = temp * betain;
#line 2554 "talldp.f"
    d__1 = temp1 * beta;
#line 2554 "talldp.f"
    if (store_(&d__1) == z__) {
#line 2554 "talldp.f"
	goto L410;
#line 2554 "talldp.f"
    }
#line 2555 "talldp.f"
    ++i__;
#line 2556 "talldp.f"
    k += k;
#line 2557 "talldp.f"
    goto L400;
#line 2558 "talldp.f"
L410:
#line 2558 "talldp.f"
    if (*ibeta == 10) {
#line 2558 "talldp.f"
	goto L420;
#line 2558 "talldp.f"
    }
#line 2559 "talldp.f"
    *iexp = i__ + 1;
#line 2560 "talldp.f"
    mx = k + k;
#line 2561 "talldp.f"
    goto L450;
/* ----------------------------------------------------------------------- */
/*  This segment is for decimal machines only. */
/* ----------------------------------------------------------------------- */
#line 2565 "talldp.f"
L420:
#line 2565 "talldp.f"
    *iexp = 2;
#line 2566 "talldp.f"
    iz = *ibeta;
#line 2567 "talldp.f"
L430:
#line 2567 "talldp.f"
    if (k < iz) {
#line 2567 "talldp.f"
	goto L440;
#line 2567 "talldp.f"
    }
#line 2568 "talldp.f"
    iz *= *ibeta;
#line 2569 "talldp.f"
    ++(*iexp);
#line 2570 "talldp.f"
    goto L430;
#line 2571 "talldp.f"
L440:
#line 2571 "talldp.f"
    mx = iz + iz - 1;
/* ----------------------------------------------------------------------- */
/*  Loop to determine MINEXP, XMIN. */
/*  Exit from loop is signaled by an underflow. */
/* ----------------------------------------------------------------------- */
#line 2576 "talldp.f"
L450:
#line 2576 "talldp.f"
    *xmin = y;
#line 2577 "talldp.f"
    y *= betain;
/* ----------------------------------------------------------------------- */
/*  Check for underflow here. */
/* ----------------------------------------------------------------------- */
#line 2581 "talldp.f"
    d__1 = y * one;
#line 2581 "talldp.f"
    a = store_(&d__1);
#line 2582 "talldp.f"
    d__1 = y * t;
#line 2582 "talldp.f"
    temp = store_(&d__1);
#line 2583 "talldp.f"
    d__1 = a + a;
#line 2583 "talldp.f"
    if (store_(&d__1) == zero || abs(y) >= *xmin) {
#line 2583 "talldp.f"
	goto L460;
#line 2583 "talldp.f"
    }
#line 2584 "talldp.f"
    ++k;
#line 2585 "talldp.f"
    d__1 = temp * betain;
#line 2585 "talldp.f"
    temp1 = store_(&d__1);
#line 2586 "talldp.f"
    d__1 = temp1 * beta;
#line 2586 "talldp.f"
    if (store_(&d__1) != y) {
#line 2586 "talldp.f"
	goto L450;
#line 2586 "talldp.f"
    }
#line 2587 "talldp.f"
    nxres = 3;
#line 2588 "talldp.f"
    *xmin = y;
#line 2589 "talldp.f"
L460:
#line 2589 "talldp.f"
    *minexp = -k;
/* ----------------------------------------------------------------------- */
/*  Determine MAXEXP, XMAX. */
/* ----------------------------------------------------------------------- */
#line 2593 "talldp.f"
    if (mx > k + k - 3 || *ibeta == 10) {
#line 2593 "talldp.f"
	goto L500;
#line 2593 "talldp.f"
    }
#line 2594 "talldp.f"
    mx += mx;
#line 2595 "talldp.f"
    ++(*iexp);
#line 2596 "talldp.f"
L500:
#line 2596 "talldp.f"
    *maxexp = mx + *minexp;
/* ----------------------------------------------------------------- */
/*  Adjust IRND to reflect partial underflow. */
/* ----------------------------------------------------------------- */
#line 2600 "talldp.f"
    *irnd += nxres;
/* ----------------------------------------------------------------- */
/*  Adjust for IEEE-style machines. */
/* ----------------------------------------------------------------- */
#line 2604 "talldp.f"
    if (*irnd == 2 || *irnd == 5) {
#line 2604 "talldp.f"
	*maxexp += -2;
#line 2604 "talldp.f"
    }
/* ----------------------------------------------------------------- */
/*  Adjust for non-IEEE machines with partial underflow. */
/* ----------------------------------------------------------------- */
#line 2608 "talldp.f"
    if (*irnd == 3 || *irnd == 4) {
#line 2608 "talldp.f"
	*maxexp -= *it;
#line 2608 "talldp.f"
    }
/* ----------------------------------------------------------------- */
/*  Adjust for machines with implicit leading bit in binary */
/*  significand, and machines with radix point at extreme */
/*  right of significand. */
/* ----------------------------------------------------------------- */
#line 2614 "talldp.f"
    i__ = *maxexp + *minexp;
#line 2615 "talldp.f"
    if (*ibeta == 2 && i__ == 0) {
#line 2615 "talldp.f"
	--(*maxexp);
#line 2615 "talldp.f"
    }
#line 2616 "talldp.f"
    if (i__ > 20) {
#line 2616 "talldp.f"
	--(*maxexp);
#line 2616 "talldp.f"
    }
#line 2617 "talldp.f"
    if (a != y) {
#line 2617 "talldp.f"
	*maxexp += -2;
#line 2617 "talldp.f"
    }
#line 2618 "talldp.f"
    *xmax = one - *epsneg;
#line 2619 "talldp.f"
    d__1 = *xmax * one;
#line 2619 "talldp.f"
    if (store_(&d__1) != *xmax) {
#line 2619 "talldp.f"
	*xmax = one - beta * *epsneg;
#line 2619 "talldp.f"
    }
#line 2620 "talldp.f"
    *xmax /= beta * beta * beta * *xmin;
#line 2621 "talldp.f"
    i__ = *maxexp + *minexp + 3;
#line 2622 "talldp.f"
    if (i__ <= 0) {
#line 2622 "talldp.f"
	goto L520;
#line 2622 "talldp.f"
    }
#line 2623 "talldp.f"
    i__1 = i__;
#line 2623 "talldp.f"
    for (j = 1; j <= i__1; ++j) {
#line 2624 "talldp.f"
	if (*ibeta == 2) {
#line 2624 "talldp.f"
	    *xmax += *xmax;
#line 2624 "talldp.f"
	}
#line 2625 "talldp.f"
	if (*ibeta != 2) {
#line 2625 "talldp.f"
	    *xmax *= beta;
#line 2625 "talldp.f"
	}
#line 2626 "talldp.f"
/* L510: */
#line 2626 "talldp.f"
    }
#line 2627 "talldp.f"
L520:
#line 2627 "talldp.f"
    return 0;
/* ---------- LAST CARD OF MACHAR ---------- */
} /* machar_ */

/* Main program alias */ int tall_ () { MAIN__ (); return 0; }
