#include <math.h>
#include <errno.h>

extern int	errno ;
double	infnan(iarg)
int	iarg ;
{
	switch(iarg) {
	case	 ERANGE:	errno = ERANGE;	return(HUGE);
	case	-ERANGE:	errno = EDOM;	return(-HUGE);
	default:		errno = EDOM;	return(HUGE); /* HUGE instead of NaN */
	}
}
