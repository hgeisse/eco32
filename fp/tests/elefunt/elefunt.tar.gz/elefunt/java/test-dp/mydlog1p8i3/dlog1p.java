import java.lang.Math;

public class dlog1p
{
    final private static double ONE = 1.0D;
    final private static double ZERO = 0.0D;

    final private static double LOG10E = 0.43429448190325182765112891891660508229439700580366D;

    public static double dlog1p(double x)
    {
	/*
	 * (log1p)
	 * Return dlog(1 + x), taking care to avoid subtraction loss.
	 *
	 * This version uses minimax rational polynomials computed by Maple,
	 * e.g.,
	 *
	 *     with(numapprox):
	 *     Digits := 35:
	 *     minimax((log(1+x) - x + x^2/2)/x^3,
	 *             x = -0.5 .. -0.375, [4,4], 1, 'err');
	 *     printf("%.2e\n", err):
	 *
	 * on 8 subintervals, chosen to have accuracy adequate for IEEE 754
	 * and VAX 32-bit arithmetic.
	 * (17-Jun-2002)
	 */

	/* System generated locals */
	double ret_val;

	/*
	 * We handle the computation in three regions:
	 *
	 * x in [-Infinity, -0.5):  log(1+x)
	 * x in [-0.5, 0.5]:        minimax rational polynomials in 8 blocks
	 * x in (0.5, Infinity]:    log(1+x)
	 *
	 * The central region suffers loss of ONE or more bits if the
	 * simple formula is used.
	 *
	 * We also handle the cases of log1p(NaN) and log1p(0) specially,
	 * so as to preserve NaNs, and the sign of ZERO.
	 */

	if (x != x)
	    ret_val = x;
	else if (x == ZERO)
	    ret_val = x;
	else if (x < -0.5e+00)
	    ret_val = Math.log(ONE + x);
	else if (x <= -0.375e+00)
	{			/* Error = 1.69e-17 */
	    ret_val = x - 0.5e+00 * x * x + (x * x * x *
		(
		 (  1.5044545670710079e+00 +
		    (  3.1173897279344322e+00 +
		       (  2.0442431537473963e+00 +
			  (  4.1712687535471434e-01 +
			     (  8.1516528520299150e-04
				) * x) * x) * x) * x)
		 /
		 (  4.5133636193374363e+00 +
		    (  1.2737190480531017e+01 +
		       (  1.2977593729899539e+01 +
			  (  5.5989017034417300e+00 +
			     (  8.4926574396097469e-01
				) * x) * x) * x) * x) ) );
	}
	else if (x <= -0.25e+00)
	{			/* Error = 2.15e-18 */
	      ret_val = x - 0.5e+00 * x * x + (x * x * x *
		  (
		   (  8.7790679775139364e-01 +
		      (  1.7360315713524841e+00 +
			 (  1.0735444876633462e+00 +
			    (  2.0274333164517373e-01 +
			       (  2.5725626521736518e-04
				  ) * x) * x) * x) * x)
		   /
		   (  2.6337203923183282e+00 +
		      (  7.1833849840003401e+00 +
			 (  7.0279396943445726e+00 +
			    (  2.8860122861636111e+00 +
			       (  4.1146609079206572e-01
				  ) * x) * x) * x) * x) ) );
	}
	else if (x <= -0.125e+00)
	{			/* Error = 3.82e-19 */
	    ret_val = x - 0.5e+00 * x * x + (x * x * x *
		(
		 (  5.6591115699312601e-01 +
		    (  1.0737407598645193e+00 +
		       (  6.3010510126076044e-01 +
			  (  1.1103105594996662e-01 +
			     (  9.7591748656440219e-05
				) * x) * x) * x) * x)
		 /
		 (  1.6977334709769040e+00 +
		    (  4.4945223827091792e+00 +
		       (  4.2425670058275712e+00 +
			  (  1.6671717002999560e+00 +
			     (  2.2479228204416920e-01
				) * x) * x) * x) * x) ) );
	}
	else if (x <= 0.0e+00)
	{			/* Error = 8.64e-20 */
	    ret_val = x - 0.5e+00 * x * x + (x * x * x *
		(
		 (  3.9116926934174841e-01 +
		    (  7.1506212697108955e-01 +
		       (  4.0013646128506695e-01 +
			  (  6.6205709874505614e-02 +
			     (  4.2258124307893188e-05
				) * x) * x) * x) * x)
		 /
		 (  1.1735078080252452e+00 +
		    (  3.0253172369322022e+00 +
		       (  2.7652926267391334e+00 +
			  (  1.0441501615256853e+00 +
			     (  1.3379052000685916e-01
				) * x) * x) * x) * x) ) );
	}
	else if (x <= 0.125e+00)
	{			/* Error = 2.34e-20 */
	    ret_val = x - 0.5e+00 * x * x + (x * x * x *
		(
		 (  2.8468062923019744e-01 +
		    (  5.0301358589081052e-01 +
		       (  2.6944698743103883e-01 +
			  (  4.2077770944792887e-02 +
			     (  2.0219316198679881e-05
				) * x) * x) * x) * x)
		 /
		 (  8.5404188769059233e-01 +
		    (  2.1495721734403757e+00 +
		       (  1.9080949597590620e+00 +
			  (  6.9458217243306899e-01 +
			     (  8.4908446345027966e-02
				) * x) * x) * x) * x) ) );
	}
	else if (x <= 0.25e+00)
	{			/* Error = 7.30e-21 */
	    ret_val = x - 0.5e+00 * x * x + (x * x * x *
		(
		 (  2.1553052613801602e-01 +
		    (  3.6908572064840959e-01 +
		       (  1.8985870333812832e-01 +
			  (  2.8103922974841754e-02 +
			     (  1.0460404957327285e-05
				) * x) * x) * x) * x)
		 /
		 (  6.4659157841418361e-01 +
		    (  1.5922008457485210e+00 +
		       (  1.3757717974555282e+00 +
			  (  4.8411589621565236e-01 +
			     (  5.6644995485154120e-02
				) * x) * x) * x) * x) ) );
	}
	else if (x <= 0.375e+00)
	{			/* Error = 2.55e-21 */
	    ret_val = x - 0.5e+00 * x * x + (x * x * x *
		(
		 (  1.6834864216289497e-01 +
		    (  2.8001868168162966e-01 +
		       (  1.3869482255982835e-01 +
			  (  1.9531639995650827e-02 +
			     (  5.7626578108491004e-06
				) * x) * x) * x) * x)
		 /
		 (  5.0504592649639288e-01 +
		    (  1.2188404896672650e+00 +
		       (  1.0271872827125042e+00 +
			  (  3.5020401884722037e-01 +
			     (  3.9330117784720331e-02
				) * x) * x) * x) * x) ) );
	}
	else if (x <= 0.5e+00)
	{			/* Error = 9.77e-22 */
	    ret_val = x - 0.5e+00 * x * x + (x * x * x *
		(
		 (  1.3485476966342249e-01 +
		    (  2.1828277502475255e-01 +
		       (  1.0434104129322124e-01 +
			  (  1.4023055466072043e-02 +
			     (  3.3430505107013184e-06
				) * x) * x) * x) * x)
		 /
		 (  4.0456430907478272e-01 +
		    (  9.5827155487569852e-01 +
		       (  7.8898822640201256e-01 +
			  (  2.6112941313288883e-01 +
			     (  2.8215884017497197e-02
				) * x) * x) * x) * x) ) );
	}
	else
	    ret_val = Math.log(ONE + x);

	return (ret_val);
    }


    public static double dl1p10(double x)
    {
	/* (log1p10) */
	/* Return alog10(1 + x), taking care to avoid subtraction loss. */
	/* (17-Jun-2002) */

	return (dlog1p(x) * LOG10E);
    }
}
