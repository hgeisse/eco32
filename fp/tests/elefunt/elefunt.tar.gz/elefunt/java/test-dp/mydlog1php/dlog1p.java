import java.lang.Math;

public class dlog1p
{
    final private static double ONE = 1.0D;

    final private static double LOG10E = 0.43429448190325182765112891891660508229439700580366D;

    public static double dlog1p(double x)
    {
	/*
	 * (log1p)
	 * Return alog(1 + x), taking care to avoid subtraction loss.
	 *
	 * This version uses an algorithm developed for the HP-15C
	 * calculator, mentioned in the log1p implementation in Sun's
	 * Freely-Distributable Math Library, FDLIBM:
	 *
	 *  >> Note: Assuming log() return [sic] accurate answer, the
	 *  >>       following algorithm can be used to compute log1p(x)
	 *  >>       to within a few ULP:
	 *  >>
	 *  >>                u = 1+x;
	 *  >>                if(u==1.0D) return x ; else
	 *  >>                           return log(u)*(x/(u-1.0D));
	 *  >>
	 *  >>       See HP-15C Advanced Functions Handbook, p. 193.
	 *
	 * (22-Jun-2002)
	 */

	/* Initialized data */

	/* System generated locals */
	double ret_val;

	/* Local variables */
	double u;

	u = ONE + x;
	if (u == ONE)
	    ret_val = x;
	else
	    ret_val = Math.log(u) * (x / (u - ONE));

	return (ret_val);
    }


    public static double dl1p10(double x)
    {
	/* (log1p10) */
	/* Return alog10(1 + x), taking care to avoid subtraction loss. */
	/* (17-Jun-2002) */

	return (dlog1p(x) * LOG10E);
    }
}
