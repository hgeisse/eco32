import java.lang.Math;

public class dexpm1
{
    private static double EXP(double x) {return (Math.exp(x)); }

    /*
     *
     * CUTLO = ln(0.5) (really, ln(1-1/beta) for arbitrary base beta)
     *
     */
    final private static double CUTLO = -0.6931471805599453094172321214581765680755001343603;

    /*
     *
     * CUTHI = ln(1.5) (really, ln(1+1/beta) for arbitrary base beta)
     *
     */
    final private static double CUTHI = 0.4054651081081643819780131154643491365719904234625;

    final private static double ONE = 1.0;
    final private static double ZERO = 0.0;

    public static double expm1(double x)
    {
	/*
	 * (expm1)
	 * Return (exp(x) - 1), taking care to avoid subtraction loss.
	 *
	 * This version uses minimax rational polynomials computed by Maple,
	 * e.g.,
	 *
	 *     with(numapprox):
	 *     Digits := 20:
	 *     minimax((exp(x)-1-x)/x^2, x = -0.5 .. -0.25, [2,4], 1, 'err');
	 *     printf("%.2e\n", err):
	 *
	 * on 5 subintervals, chosen to have accuracy adequate for IEEE 754
	 * and VAX 32-bit arithmetic.
	 * (28-Jun-2002)
	 */

	double ret_val;

	/*
	 *
	 *     We handle the computation in three regions:
	 *
	 *     x in [-Infinity, CUTLO):  exp(x) - 1
	 *     x in [CUTLO, CUTHI]:      minimax rational polynomial
	 *     x in (CUTHI, Infinity]:   exp(x) - 1
	 *
	 *     The central region suffers loss of one or more bits if the
	 *     simple formula is used.
	 *
	 *     The following IF statements handle the case of NaN, signed zero,
	 *     and the three regions above.
	 *
	 */

	if (x != x)				/* then x is a NaN */
	    ret_val = x;
	else if (x == ZERO)			/* then x is +0 or -0 */
	    ret_val = x;			/* preserve sign of zero */
	else if (x < CUTLO)
	    ret_val = EXP(x) - ONE;
	else if (x < -0.50e+00) /* [-0.75,-0.50) Error = 1.54e-16 */
	    ret_val = x + (x * x *
		(
		 (  3.8989912286053430e-01 +
		  ( -2.8882046340622964e-02 +
		   (  5.4512449587041985e-03
		    ) * x) * x)
		 /
		 (  7.7979824391446047e-01 +
		  ( -3.1769686204763836e-01 +
		   (  5.1818147493317685e-02 +
		    ( -3.7949302563597960e-03 +
		     (  7.5078784336773636e-05
		      ) * x) * x) * x) * x) ) );
	else if (x < -0.25e+00) /* [-0.50,-0.25) Error = 1.84e-16 */
	    ret_val = x + (x * x *
		(
		 (  4.3047607933058647e-01 +
		  ( -3.0420323905470767e-02 +
		   (  6.0523043793850547e-03
		    ) * x) * x)
		 /
		 (  8.6095215861346822e-01 +
		  ( -3.4782470164735630e-01 +
		   (  5.6300154414043854e-02 +
		    ( -4.1305690642944567e-03 +
		     (  9.0604853093734416e-05
		      ) * x) * x) * x) * x) ) );
	else if (x < 0.0e+00) /* [-0.25,-0.0) Error = 2.17e-16 */
	    ret_val = x + (x * x *
		(
		 (  4.7542798600518708e-01 +
		  ( -3.2253455799147504e-02 +
		   (  6.7502300184090888e-03
		    ) * x) * x)
		 /
		 (  9.5085597201037374e-01 +
		  ( -3.8145890226858586e-01 +
		   (  6.1415429781247393e-02 +
		    ( -4.5311678730662972e-03 +
		     (  1.0881543591634231e-04
		      ) * x) * x) * x) * x) ) );
	else if (x < 0.25e+00) /* [0.0,0.25) Error = 6.08e-19  */
	    ret_val = x + (x * x *
		(
		 (  5.2593687320286602e-01 +
		  ( -3.8811514737428555e-02 +
		   (  8.4091491985826436e-03
		    ) * x) * x)
		 /
		 (  1.0518737464057320e+00 +
		  ( -4.2824761161010176e-01 +
		   (  7.1911356733440284e-02 +
		    ( -5.8143803853551491e-03 +
		     (  1.6110243439588698e-04 +
		      (  4.4745549016721645e-06
		       ) * x) * x) * x) * x) * x) ) );
	else if (x < 0.50e+00) /* [0.25,0.50) Error = 9.44e-19  */
	    ret_val = x + (x * x *
		(
		 (  5.8317226176903968e-01 +
		  ( -4.2576514699527594e-02 +
		   (  9.2488617290439876e-03
		    ) * x) * x)
		 /
		 (  1.1663445235391396e+00 +
		  ( -4.7393453726883370e-01 +
		   (  7.9280525808507673e-02 +
		    ( -6.3713737409098503e-03 +
		     (  1.7614766224757315e-04 +
		      (  4.5318600924798633e-06
		       ) * x) * x) * x) * x) * x) ) );
	else
	    ret_val = EXP(x) - ONE;

	return (ret_val);
    }
}
