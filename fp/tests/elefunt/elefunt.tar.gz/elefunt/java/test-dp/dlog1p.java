import java.lang.Math;

public class dlog1p
{
    final private static double ONE = 1.0D;
    final private static double LOG10E = 0.43429448190325182765112891891660508229439700580366e+00D;

    public static double dlog1p(double x)
    {
	double u;

	// This algorithm, from the HP15C Advanced Functions Handbook,
	// is the simplest way to get a reasonably accurate log1p()
	// function without a lot of extra work.

	u = ONE + x;
	if (u == ONE)
	    return (x);
	else
	    return (Math.log(u) * (x / (u - ONE)));
    }

    public static double dl1p10(double x)
    {
	return (dlog1p(x) * LOG10E);
    }
}
