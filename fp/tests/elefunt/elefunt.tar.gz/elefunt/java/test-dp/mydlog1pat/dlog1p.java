import java.lang.Math;

public class dlog1p
{
    final private static double CUTLO = -0.5D;	/* CUTLO = -1/beta, for arbitrary base beta */
    final private static double CUTHI = 0.5D;	/* CUTHI = 1/beta, for arbitrary base beta */

    final private static double ONE = 1.0D;
    final private static double TWO = 2.0D;
    final private static double ZERO = 0.0D;

    final private static double LOG10E = 0.43429448190325182765112891891660508229439700580366D;

    public static double dlog1p(double x)
    {
	/* (log1p) */
	/* Return alog(1 + x), taking care to avoid subtraction loss. */

	/* This version uses an alternate form of the Taylor series that */
	/* requires only about a quarter as many terms, and has only positive */
	/* terms. */
	/* (17-Jun-2002) */

	/* System generated locals */
	double ret_val;

	/* Local variables */
	double
	    term,
	    sum,
	    twonp1,
	    z,
	    zsq,
	    zsqton;

	/* We handle the computation in three regions:
	 *
	 * x in [-Infinity, CUTLO):  log(1+x)
	 * x in [CUTLO, CUTHI]:      alternate Taylor series
	 * x in (CUTHI, Infinity]:   log(1+x)
	 *
	 * The central region suffers loss of ONE or more bits if the
	 * simple formula is used.
	 *
	 * We also handle the cases of log1p(NaN) and log1p(0) specially,
	 * so as to preserve NaNs, and the sign of ZERO.
	 */

	if (x != x)
	    ret_val = x;
	else if (x == ZERO)
	    ret_val = x;
	else if (x < CUTLO)
	    ret_val = Math.log((ONE + x));
	else if (x <= CUTHI)
	{
	    sum = ZERO;
	    term = ONE;
	    twonp1 = ONE;
	    z = x / (TWO + x);
	    zsq = z * z;
	    zsqton = ONE;
	    while ((sum + term) != sum)
	    {
		sum += term;
		twonp1 += TWO;
		zsqton *= zsq;
		term = zsqton / twonp1;
	    }
	    ret_val = z * (sum + sum);
	}
	else
	    ret_val = Math.log((ONE + x));

	return (ret_val);
    }


    public static double dl1p10(double x)
    {
	/* (log1p10) */
	/* Return alog10(1 + x), taking care to avoid subtraction loss. */
	/* (17-Jun-2002) */

	return (dlog1p(x) * LOG10E);
    }
}
