import java.lang.Math;

public class dlog1p
{
    final private static double ONE = 1.0D;
    final private static double ZERO = 0.0D;

    final private static double LOG10E = 0.43429448190325182765112891891660508229439700580366D;

    public static double dlog1p(double x)
    {
	/*
	 * (log1p)
	 * Return dlog(1 + x), taking care to avoid subtraction loss.
	 *
	 * This version uses minimax rational polynomials computed by Maple,
	 * e.g.,
	 *
	 *     with(numapprox):
	 *     Digits := 35:
	 *     minimax((log(1+x)-x)/x^2, x = -0.5 .. -0.375, [4,4], 1, 'err');
	 *     printf("%.2e\n", err):
	 *
	 * on 8 subintervals, chosen to have accuracy adequate for IEEE 754
	 * and VAX 32-bit arithmetic.
	 * (17-Jun-2002)
	 */

	/* System generated locals */
	double ret_val;

	/*
	 * We handle the computation in three regions:
	 *
	 * x in [-Infinity, -0.5):  log(1+x)
	 * x in [-0.5, 0.5]:        minimax rational polynomials in 8 blocks
	 * x in (0.5, Infinity]:    log(1+x)
	 *
	 * The central region suffers loss of ONE or more bits if the
	 * simple formula is used.
	 *
	 * We also handle the cases of log1p(NaN) and log1p(0) specially,
	 * so as to preserve NaNs, and the sign of ZERO.
	 */

	if (x != x)
	    ret_val = x;
	else if (x == ZERO)
	    ret_val = x;
	else if (x < -0.5e+00)
	    ret_val = Math.log(ONE + x);
	else if (x <= -0.375e+00)
	{					/* Error = 3.61e-17 */
	    ret_val = x + (x * x *
		(
		 ( -2.1067672666150430e+00 +
		   ( -4.2824449504183015e+00 +
		     ( -2.7379532031064147e+00 +
		       ( -5.4207394909776909e-01 +
			 ( -3.3503377664620536e-03
			   ) * x) * x) * x) * x)
		 /
		 (  4.2135344070215753e+00 +
		    (  1.1373910634693916e+01 +
		       (  1.0951729914364848e+01 +
			  (  4.3836930292059099e+00 +
			     (  5.9819340471291773e-01
				) * x) * x) * x) * x) ) );
	}
	else if (x <= -0.25e+00)
	{					/* Error = 4.95e-18 */
	      ret_val = x + (x * x *
		  (
		   ( -1.2555535089136690e+00 +
		     ( -2.4231652942688882e+00 +
		       ( -1.4488297634459479e+00 +
			 ( -2.6133820609156552e-01 +
			   ( -1.1648260213895755e-03
			     ) * x) * x) * x) * x)
		   /
		   (  2.5111070163108593e+00 +
		      (  6.5204018931364974e+00 +
			 (  5.9890401685318254e+00 +
			    (  2.2596089206732964e+00 +
			       (  2.8533006195055604e-01
				  ) * x) * x) * x) * x) ) );
	}
	else if (x <= -0.125e+00)
	{					/* Error = 9.41e-19 */
	    ret_val = x + (x * x *
		(
		 ( -8.2574484202540701e-01 +
		   ( -1.5220596398831249e+00 +
		     ( -8.5705710067193204e-01 +
		       ( -1.4218241537477148e-01 +
			 ( -4.8080284563162187e-04
			   ) * x) * x) * x) * x)
		 /
		 (  1.6514896840466312e+00 +
		    (  4.1451124022653601e+00 +
		       (  3.6517776234049690e+00 +
			  (  1.3069228711838949e+00 +
			     (  1.5390276643618212e-01
				) * x) * x) * x) * x) ) );
	}
	else if (x <= 0.0e+00)
	{					/* Error = 2.26e-19 */
	    ret_val = x + (x * x *
		(
		 ( -5.8173932923442479e-01 +
		   ( -1.0287332510385179e+00 +
		     ( -5.4848284009904027e-01 +
		       ( -8.4309866797958571e-02 +
			 ( -2.2442237938435112e-04
			   ) * x) * x) * x) * x)
		 /
		 (  1.1634786584688496e+00 +
		    (  2.8331189410562682e+00 +
		       (  2.4039723116677090e+00 +
			  (  8.2009993422419316e-01 +
			     (  9.0617334974994608e-02
				) * x) * x) * x) * x) ) );
	}
	else if (x <= 0.125e+00)
	{					/* Error = 6.47e-20 */
	    ret_val = x + (x * x *
		(
		 ( -4.3108945661266986e-01 +
		   ( -7.3396166660196585e-01 +
		     ( -3.7212094075155467e-01 +
		       ( -5.3324115416485342e-02 +
			 ( -1.1490673030384065e-04
			   ) * x) * x) * x) * x)
		 /
		 (  8.6217891322533973e-01 +
		    (  2.0427092753541580e+00 +
		       (  1.6749586084599134e+00 +
			  (  5.4680423074955077e-01 +
			     (  5.6977402266381198e-02
				) * x) * x) * x) * x) ) );
	}
	else if (x <= 0.25e+00)
	{					/* Error = 2.12e-20 */
	    ret_val = x + (x * x *
		(
		 ( -3.3202949569260634e-01 +
		   ( -5.4584722527347350e-01 +
		     ( -2.6410010210848144e-01 +
		       ( -3.5461329955933539e-02 +
			 ( -6.3238705161628870e-05
			   ) * x) * x) * x) * x)
		 /
		 (  6.6405899138546901e-01 +
		    (  1.5344004447900814e+00 +
		       (  1.2191043387188950e+00 +
			  (  3.8208225510585988e-01 +
			     (  3.7703037081218612e-02
				) * x) * x) * x) * x) ) );
	}
	else if (x <= 0.375e+00)
	{					/* Error = 7.78e-21 */
	    ret_val = x + (x * x *
		(
		 ( -2.6362222534735272e-01 +
		   ( -4.1948059191428424e-01 +
		     ( -1.9426196116534747e-01 +
		       ( -2.4548408973981566e-02 +
			 ( -3.6879920770447739e-05
			   ) * x) * x) * x) * x)
		 /
		 (  5.2724445070969406e-01 +
		    (  1.1904574838183100e+00 +
		       (  9.1854002659347387e-01 +
			  (  2.7712581187517214e-01 +
			     (  2.5989498358647867e-02
				) * x) * x) * x) * x) ) );
	}
	else if (x <= 0.5e+00)
	{					/* Error = 3.11e-21 */
	    ret_val = x + (x * x *
		(
		 ( -2.1449676782221094e-01 +
		   ( -3.3103494044041502e-01 +
		     ( -1.4710714256697551e-01 +
		       ( -1.7561808331534105e-02 +
			 ( -2.2555618919370095e-05
			   ) * x) * x) * x) * x)
		 /
		 (  4.2899353581317399e-01 +
		    (  9.4806556744940616e-01 +
		       (  7.1176127170923616e-01 +
			  (  2.0719548059191995e-01 +
			     (  1.8524437616565961e-02
				) * x) * x) * x) * x) ) );
	}
	else
	    ret_val = Math.log(ONE + x);

	return (ret_val);
    }


    public static double dl1p10(double x)
    {
	/* (log1p10) */
	/* Return alog10(1 + x), taking care to avoid subtraction loss. */
	/* (17-Jun-2002) */

	return (dlog1p(x) * LOG10E);
    }
}
