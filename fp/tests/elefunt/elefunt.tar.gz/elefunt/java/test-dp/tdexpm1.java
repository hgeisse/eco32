/* -*-java-*- texpm1.java */

import java.io.*;
import java.lang.Math;

public class tdexpm1
{
    final private static double C16 = 16.0D;
    final private static double C45 = 45.0D;
    final private static double FIVE = 5.0D;
    final private static double ONE = 1.0D;
    final private static double TWO = 2.0D;
    final private static double ZERO = 0.0D;
    final private static double HALF = 0.5D;
    final private static double ONEP5 = 1.5D;

    // shorthands to avoid the need for fully-qualified names, sigh...
    private static double ABS(double x)			{ return (elefunt.ABS(x)); }
    private static double AINT(double x)		{ return (elefunt.AINT(x)); }
    private static double ALOG(double x)		{ return (elefunt.ALOG(x)); }
    private static double AMAX1(double x,double y)	{ return (elefunt.AMAX1(x,y)); }
    private static double EXP(double x)			{ return (elefunt.EXP(x)); }
    private static double EXPM1(double x)		{ return (dexpm1.expm1(x)); }
    private static double RAN()				{ return (elefunt.RAN()); }
    private static double SIGN(double x, double y)	{ return ((y >= ZERO) ? ABS(x) : -ABS(x)); }
    private static double SQRT(double x)		{ return (elefunt.SQRT(x)); }
    private static double STORE(double x)		{ return (elefunt.STORE(x)); }
    private static double TO_FP_T(long n)		{ return (elefunt.TO_FP_T(n)); }

    /*
     *     Program to test expm1
     *
     *     Data required
     *
     *        none
     *
     *     Subprograms required from this package
     *
     *        machar - An environmental inquiry program providing
     *                 information on the floating-point arithmetic
     *                 system.  Note that the call to machar can
     *                 be deleted provided the following four
     *                 parameters are assigned the values indicated
     *
     *                 ibeta - the radix of the floating-point system
     *                 it    - the number of base-ibeta digits in the
     *                         significand of a floating-point number
     *                 xmin  - the smallest non-vanishing floating-point
     *                         power of the radix
     *                 xmax  - the largest finite floating-point no.
     *
     *        ran(k) - a function subprogram returning random real
     *                 numbers uniformly distributed over (0,1)
     *
     *
     *     Standard Fortran subprograms required
     *
     *         abs, AINT, alog, AMAX1, EXPM1, double, SQRT
     *
     *     Latest revision - June 26, 2002
     *
     *     Author - Nelson H. F. Beebe
     *              Mathematics Department, University of Utah
     *
     *     Based on texp:
     *
     *     Latest revision - December 6, 1979
     *
     *     Author - W. J. Cody
     *              Argonne National Laboratory
     *
     */

    public static void texpm1()
    {
	int i,
	    iout,
	    i1,
	    j,
	    k1,
	    k2,
	    k3,
	    n;

	double a,
	    ait,
	    albeta,
	    b,
	    beta,
	    del,
	    r6,
	    r7,
	    temp,
	    v,
	    w,
	    x,
	    xl,
	    xn,
	    x1,
	    y,
	    z,
	    zz,
	    zzz;

	elefunt.banner("tdexpm1");

	ran.ranset(initseed.initseed());

	beta = TO_FP_T(machar.ibeta);
	albeta = ALOG(beta);
	ait = TO_FP_T(machar.it);

	n = (int)maxtest.maxtest();
	xn = TO_FP_T(n);
	i1 = 0;

	a = b = v = zzz = ZERO;		// keep Java compiler happy

	/*
	 *-----------------------------------------------------------------------
	 *     random argument accuracy tests
	 *-----------------------------------------------------------------------
	 */
	for (j = 0; j < 6; ++j)
	{
	    k1 = 0;
	    k3 = 0;
	    x1 = ZERO;
	    r6 = ZERO;
	    r7 = ZERO;

	    switch (j)
	    {
	    case 0:
		a = -ALOG(0.9e+00D * machar.xmax);
		b = ALOG(HALF * machar.epsneg);
		v = ONE / C16;
		break;

	    case 1:
		a = ALOG(HALF * machar.epsneg);
		b = -FIVE * ALOG(TWO);
		v = ONE / C16;
		break;

	    case 2:
		a = -FIVE * ALOG(TWO);
		b = ALOG(HALF);
		v = C45 / C16;
		break;

	    case 3:
		a = ALOG(HALF);
		b = -machar.xmin;
		v = ONE / C16;
		break;

	    case 4:
		a = machar.xmin;
		b = ALOG(ONEP5);
		v = C45 / C16;
		break;

	    case 5:
		a = ALOG(ONEP5);
		b = ALOG(0.9e+00D * machar.xmax);
		v = ONE / C16;
		break;

	    default:
		break;
	    }

	    del = (b - a) / xn;
	    xl = a;

	    for (i = 1; i <= n; ++i)
	    {
		x = xl + del * RAN();

		/*
		 *-----------------------------------------------------------------------
		 *     purify arguments
		 *-----------------------------------------------------------------------
		 */

		temp = x - v;
		y = STORE(temp);
		temp = y + v;
		x = STORE(temp);

		/*
		 *-----------------------------------------------------------------------
		 *           we have an additive formula, suitable for use with
		 *           uniformly-distributed pseudo-random arguments:
		 *
		 *           expm1(x - v) = expm1(-v)*(1 + expm1(x)) + expm1(x)
		 *                        = expm1(x)*(1 + expm1(-v)) + expm1(-v)
		 *
		 *           and we represent expm1(v) as c1 + c2, where c1 is exactly
		 *           representable, and c2 is a small correction term.
		 *-----------------------------------------------------------------------
		 */

		z = EXPM1(x);
		zz = EXPM1(y);
		switch (j)
		{
		case 0:		/* * j .eq. 0, v .eq. 1/16, expm1(-v) = -1/16 + 0.00191306... */
		    zzz = (z * 0.9375e+00D) +
			(z *
			 1.9130628134757861197108246223050845246808905494418220e-03D)
			+ (-0.0625e+00D +
			   1.9130628134757861197108246223050845246808905494418220e-03D);
		    break;

		case 1:		/* j .eq. 1, v .eq. 1/16, expm1(-v) = -1/16 + 0.00191306... */
		    zzz = (z * 0.9375e+00D) +
			((z *
			  1.9130628134757861197108246223050845246808905494418220e-03D)
			 + (-0.0625e+00D +
			    1.9130628134757861197108246223050845246808905494418220e-03D));
		    break;

		case 2:		/* j .eq. 2, v .eq. 45/16, expm1(-v) = -(15/16 + 0.0024453...) */
		    zzz = (z * 0.0625e+00D) -
			(z *
			 2.4453321046920570389443866922096486559947441807771923e-03D)
			- (0.9375e+00D +
			   2.4453321046920570389443866922096486559947441807771923e-03D);
		    break;

		case 3:		/* j .eq. 3, v .eq. 1/16, expm1(-v) = -1/16 + 0.00191306... */
		    zzz = (z * 0.9375e+00D) +
			((z *
			  1.9130628134757861197108246223050845246808905494418220e-03D)
			 + (-0.0625e+00D +
			    1.9130628134757861197108246223050845246808905494418220e-03D));
		    break;

		case 4:		/* j .eq. 4, v .eq. 45/16, expm1(-v) = -(15/16 + 0.0024453...) */
		    zzz = (z * 0.0625e+00D) -
			(z *
			 2.4453321046920570389443866922096486559947441807771923e-03D)
			- (0.9375e+00D +
			   2.4453321046920570389443866922096486559947441807771923e-03D);
		    break;

		case 5:		/* j .eq. 5, v .eq. 1/16, expm1(-v) = -1/16 + 0.00191306... */
		    zzz = (z * 0.9375e+00D) +
			((z *
			  1.9130628134757861197108246223050845246808905494418220e-03D)
			 + (-0.0625e+00D +
			    1.9130628134757861197108246223050845246808905494418220e-03D));
		    break;

		default:
		    break;
		}

		w = ONE;
		if (zzz != ZERO)
		    w = (zz - zzz) / zzz;
		if (w < ZERO)
		    k1 = k1 + 1;
		if (w > ZERO)
		    k3 = k3 + 1;
		w = ABS(w);
		if (w > r6)
		{
		    r6 = w;
		    x1 = x;
		}
		r7 = r7 + w * w;
		xl = a + TO_FP_T(i) * del;	/* OLD: xl = xl + del (bad for large n) */
	    }

	    k2 = n - k3 - k1;
	    r7 = SQRT(r7 / xn);

	    System.out.print("1TEST OF EXPM1(X-" + fmt.F(v,7,4) + ") VS EXPM1(" +
			     fmt.F(-v,7,4) + ")*(1 + EXPM1(X)) + EXPM1(X)\n\n\n");

	    System.out.print(" " + fmt.I(n,6) + " RANDOM ARGUMENTS WERE TESTED FROM THE INTERVAL\n");
	    System.out.print("      (" + fmt.E(a,15,4) + "," + fmt.E(b,15,4) + ")\n\n\n");

	    System.out.print(" EXPM1(X+V) WAS LARGER " + fmt.I(k1,5) + " TIMES,\n");
	    System.out.print("                AGREED " + fmt.I(k2,5) + " TIMES, AND\n");
	    System.out.print("           WAS SMALLER " + fmt.I(k3,5) + " TIMES.\n\n\n");
	    System.out.print("\n");

	    System.out.print(" THERE ARE " + fmt.I(machar.it,3) + " BASE " + fmt.I(machar.ibeta,3) +
			     " SIGNIFICANT DIGITS IN A FLOATING-POINT NUMBER\n\n\n");

	    w = -999.0e+00D;
	    if (r6 != ZERO)
		w = ALOG(ABS(r6)) / albeta;

	    System.out.print(" THE MAXIMUM RELATIVE ERROR OF " + fmt.E(r6,14,4) +
			     " = " + fmt.I(machar.ibeta,4) + " ** " + fmt.F(w,6,2) + "\n");
	    System.out.print("    OCCURRED FOR X = " + fmt.E(x1,16,6) + "\n");

	    w = AMAX1(ait + w, ZERO);
	    System.out.print(" THE ESTIMATED LOSS OF BASE " + fmt.I(machar.ibeta,3) +
			     " SIGNIFICANT DIGITS IS " + fmt.F(w,6,2) + "\n\n\n");

	    w = -999.0e+00D;
	    if (r7 != ZERO)
		w = ALOG(ABS(r7)) / albeta;

	    System.out.print(" THE ROOT MEAN SQUARE RELATIVE ERROR WAS " + fmt.E(r7,14,4) +
			     " = " + fmt.I(machar.ibeta,4) + " ** " + fmt.F(w,6,2) + "\n");

	    w = AMAX1(ait + w, ZERO);
	    System.out.print("\n");
	    System.out.print(" THE ESTIMATED LOSS OF BASE " + fmt.I(machar.ibeta,3) +
			     " SIGNIFICANT DIGITS IS " + fmt.F(w,6,2) + "\n\n\n");
	}

	/*
	 *-----------------------------------------------------------------------
	 *     special tests
	 *-----------------------------------------------------------------------
	 */


	System.out.print("1SPECIAL TESTS\n\n\n");

	System.out.print(" THE IDENTITY  1 + EXPM1(X) = -EXPM1(X)/EXPM1(-X)  WILL BE TESTED.\n\n");
	System.out.print("        X         1 + F(X) + F(X)/F(-X)\n\n");

	for (i = 1; i <= 5; ++i)
	{
	    x = RAN() * beta;
	    z = ONE + EXPM1(x) + EXPM1(x) / EXPM1(-x);

	    System.out.print(" " + fmt.E(x,14,7) + " " + fmt.E(z,14,7) + "\n\n");
	}

	System.out.print("\n\n");
	System.out.print(" TEST OF SPECIAL ARGUMENTS\n\n\n");

	x = ZERO;
	y = EXPM1(x) - ONE;
	System.out.print(" EXPM1(0.0) - 1.0 = " + fmt.E(y,15,7) + "\n");

	x = AINT(ALOG(machar.xmin));
	y = EXPM1(x);
	System.out.print(" EXPM1(" + fmt.E(x,13,6) + ") = " + fmt.E(y,13,6) + "\n");

	x = AINT(ALOG(machar.xmax));
	y = EXPM1(x);
	System.out.print(" EXPM1(" + fmt.E(x,13,6) + ") = " + fmt.E(y,13,6) + "\n");

	x = x / TWO;
	v = x / TWO;
	y = EXPM1(x);
	z = EXPM1(v);
	z = z * z;

	System.out.print("\n");
	System.out.print(" IF EXPM1(" + fmt.E(x,13,6) + ") = " + fmt.E(y,13,6) + " IS NOT ABOUT\n");
	System.out.print(" EXPM1(" + fmt.E(v,13,6) + ")**2 = " + fmt.E(z,13,6) + " THERE IS AN ARG RED ERROR\n");

	/*
	 *-----------------------------------------------------------------------
	 *     Tests of IEEE 754 subnormals (if available and enabled)
	 *-----------------------------------------------------------------------
	 */

	if (machar.xmin * HALF != ZERO)
	{
	    System.out.print("\n\n\n");
	    System.out.print(" TEST OF IEEE 754 SUBNORMAL ARGUMENTS\n\n");

	    k1 = 0;
	    k2 = 0;
	    w = machar.eps;
	    z = machar.xmin;
	    /*
	     * The choice of x here ensures that all significant bits are one, so
	     * that we can detect deficient implementations of dexpm1() that lose
	     * low-order bits. 
	     */
	    while (z != ZERO)
	    {
		x = z * (ONE - w);
		y = EXPM1(x);
		if (y != x)
		    k1 = k1 + 1;

		if (y != x)
		    System.out.print(" ERROR: EXPM1(" + fmt.E(x,15,6) +
				     ") RETURNED " + fmt.E(y,15,6) +
				     " INSTEAD OF CORRECT " + fmt.E(x,15,6) + "\n");

		y = EXPM1(-x);
		if (y != (-x))
		    k1 = k1 + 1;

		if (y != (-x))
		    System.out.print(" ERROR: EXPM1(" + fmt.E(-x,15,6) +
				     ") RETURNED " + fmt.E(y,15,6) +
				     " INSTEAD OF CORRECT " + fmt.E(-x,15,6) + "\n");

		k2 = k2 + 2;
		z = z * HALF;
		w += w;
	    }

	    if (k1 == 0)
		System.out.print(" ALL " + fmt.I(k2,3) +
				 " SUBNORMALS TESTED CORRECTLY SATISFY DEXPM1(X) = X\n\n\n");
	    else
		System.out.print(" " + fmt.I(k1,2) + " OF " + fmt.I(k2,3) +
				 " SUBNORMALS TESTED FAIL TO SATISFY DEXPM1(X) = X\n\n\n");
	}

	/*
	 *-----------------------------------------------------------------------
	 *     test of error returns
	 *-----------------------------------------------------------------------
	 */

	System.out.print("1TEST OF ERROR RETURNS\n\n\n");

	x = -ONE / SQRT(machar.xmin);
	System.out.print(" EXMP1 WILL BE CALLED WITH THE ARGUMENT " + fmt.E(x,14,4) + "\n");
	System.out.print(" THIS SHOULD TRIGGER AN ERROR MESSAGE\n\n\n");
	y = EXPM1(x);
	System.out.print(" EXPM1 RETURNED THE VALUE " + fmt.E(y,15,4) + "\n\n\n\n");

	x = -x;
	System.out.print(" EXMP1 WILL BE CALLED WITH THE ARGUMENT " + fmt.E(x,14,4) + "\n");
	System.out.print(" THIS SHOULD TRIGGER AN ERROR MESSAGE\n\n\n");
	y = EXPM1(x);
	System.out.print(" EXPM1 RETURNED THE VALUE " + fmt.E(y,15,4) + "\n\n\n\n");

	System.out.print(" THIS CONCLUDES THE TESTS\n");
    }

    public static void main(String[] args)
    {
	texpm1();
    }
}
