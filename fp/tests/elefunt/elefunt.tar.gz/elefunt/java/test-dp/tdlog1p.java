/* -*-java-*- tdlog1p.java */

import java.io.*;
import java.lang.Math;

public class tdlog1p
{
    final private static double ONE = 1.0D;
    final private static double TWO = 2.0D;
    final private static double ZERO = 0.0D;

    final private static double HALF = 0.5e+00D;
    final private static double EIGHT = 8.0e+00D;
    final private static double TENTH = 0.1e+00D;

    // shorthands to avoid the need for fully-qualified names, sigh...
    private static double ABS(double x)			{ return (elefunt.ABS(x)); }
    private static double ALOG(double x)		{ return (elefunt.ALOG(x)); }
    private static double DLOG1P(double x)		{ return (dlog1p.dlog1p(x)); }
    private static double DLOG1P10(double x)		{ return (dlog1p.dl1p10(x)); }
    private static double AMAX1(double x,double y)	{ return (elefunt.AMAX1(x,y)); }
    private static double EXP(double x)			{ return (elefunt.EXP(x)); }
    private static double RAN()				{ return (elefunt.RAN()); }
    private static double SIGN(double x, double y)	{ return ((y >= ZERO) ? ABS(x) : -ABS(x)); }
    private static double SQRT(double x)		{ return (elefunt.SQRT(x)); }
    private static double STORE(double x)		{ return (elefunt.STORE(x)); }
    private static double TO_FP_T(long n)		{ return (elefunt.TO_FP_T(n)); }

    /*
     *     Program to test DLOG1P/DLOG1P10
     *
     *     Data required
     *
     *        none
     *
     *     Subprograms required from this package
     *
     *        machar - An environmental inquiry program providing
     *                 information on the floating-point arithmetic
     *                 system.  Note that the call to machar can
     *                 be deleted provided the following four
     *                 parameters are assigned the values indicated
     *
     *                 ibeta - the radix of the floating-point system
     *                 it    - the number of base-ibeta digits in the
     *                         significand of a floating-point number
     *                 xmin  - the smallest non-vanishing floating-point
     *                         power of the radix
     *                 xmax  - the largest finite floating-point no.
     *
     *        ran(k) - a function subprogram returning random real
     *                 numbers uniformly distributed over (0,1)
     *
     *
     *     Standard Fortran subprograms required
     *
     *         abs, DLOG1P, DLOG1P10, amax1, exp, double, sign, sqrt
     *
     *
     *     Latest revision - June 19, 2002
     *
     *     Author - Nelson H. F. Beebe
     *              Mathematics Department, University of Utah
     *
     *     Based on talog:
     *
     *     Latest revision - December 6, 1979
     *
     *     Author - W. J. Cody
     *              Argonne National Laboratory
     *
     **/

    public static void tdlog1p()
    {
	int i,
	    iout,
	    j,
	    k1,
	    k2,
	    k3,
	    n;
	double a,
	    ait,
	    albeta,
	    b,
	    beta,
	    c,
	    d56,
	    d78,
	    del,
	    r6,
	    r7,
	    s,
	    w,
	    x,
	    xl,
	    xn,
	    x1,
	    y,
	    z,
	    zz;
	double temp;

	elefunt.banner("tdlog1p");

	ran.ranset(initseed.initseed());

	beta = TO_FP_T(machar.ibeta);
	albeta = ALOG(beta);
	ait = TO_FP_T(machar.it);
	j = machar.it / 3;

	x = z = zz = ZERO;		// keep Java compiler happy

	/*
	 * For regions 5 and 6, where the scale factor in the identity test
	 * is 17/16, find d56 = (smallest 1/beta**k such that the relative
	 * error in subtracting ln(s) from ln(s*(1 + 1/beta**k)) is larger
	 * than 1/beta), guaranteeing no leading bit loss.
	 */
	s = 17.0e+00D / 16.0e+00D;
	d56 = (ONE + machar.eps) * (EXP(beta * ALOG(s) / (beta - ONE))) / s - ONE;

	/*
	 * Do the same for regions 7 and 8.
	 */
	s = 11.0e+00D / 10.0e+00D;
	d78 = (ONE + machar.eps) * (EXP(beta * ALOG(s) / (beta - ONE))) / s - ONE;

	c = ONE;

	for (i = 1; i <= j; i++)
	    c = c / beta;

	a = -c;
	b = +c;
	n = (int)maxtest.maxtest();
	xn = TO_FP_T(n);

	/*
	 *-----------------------------------------------------------------------
	 *     Random argument accuracy tests
	 *-----------------------------------------------------------------------
	 */
	for (j = 1; j <= 8; ++j)
	{
	    k1 = 0;
	    k3 = 0;
	    x1 = ZERO;
	    r6 = ZERO;
	    r7 = ZERO;
	    del = (b - a) / xn;
	    xl = a;

	    for (i = 1; i <= n; ++i)
	    {
		x = del * RAN() + xl;

		switch (j)
		{
		case 1:
		    y = x;
		    zz = DLOG1P(x);
		    z = ONE / 3.0e+00D;
		    z = y * (z - y / 4.0e+00D);
		    z = (z - HALF) * y * y + y;
		    break;

		case 2:
		    temp = x + EIGHT;
		    temp = STORE(temp) - EIGHT;
		    x = STORE(temp);
		    y = x + x / 16.0e+00D;
		    z = DLOG1P(x - ONE);

		    /*
		     *# zz = DLOG1P(y - ONE) - (log(17/16) = 31/512 + delta);
		     *
		     * Original summation order:
		     *
		     * zz = DLOG1P(y - ONE) -
		     *      7.774681643484258060613204042026328620247514472377081452e-05D;
		     * zz = zz - 31.0e+00D / 512.0e+00D;
		     *
		     * Revised summation order (smallest to largest):
		     */

		    zz = DLOG1P(y - ONE) - (31.0e+00D / 512.0e+00D +
					    7.77468164348425806061320404202632862024751447237708145e-05D);
		    break;

		case 3:
		    temp = x + EIGHT;
		    temp = STORE(temp) - EIGHT;
		    x = STORE(temp);
		    y = x + x * TENTH;
		    z = DLOG1P10(x - ONE);

		    /*
		     *# zz = DLOG1P10(y - one) - (log10(1.1) = 21/512 + delta)
		     */

		    zz = DLOG1P10(y - ONE) -
			3.770601582250407501999712430242417067021904664530945965e-04D;
		    zz = zz - 21.0e+00D / 512.0e+00D;
		    break;

		case 4:
		    z = DLOG1P(x * x - ONE);
		    zz = DLOG1P(x - ONE);
		    zz = zz + zz;
		    break;

		case 5:		/* FALLTHRU */
		case 6:
		    /*
		     * With x in (0.5,1.5), adding and subtracting 16 clears 4
		     * low-order bits, so that 17x/16 is exactly computable.
		     */

		    temp = x + 16.0e+00D;
		    temp = STORE(temp) - 16.0e+00D;
		    x = STORE(temp);
		    y = x + x / 16.0e+00D;
		    z = DLOG1P(x - ONE);

		    /*
		     * zz = DLOG1P(y - ONE) - (log(17/16) = 31/512 + delta)
		     *
		     * Original summation order:
		     *
		     * zz = DLOG1P(y - ONE) -
		     *      7.774681643484258060613204042026328620247514472377081452e-05D;
		     * zz = zz - 31.0E+00D / 512.0E+00D;
		     *
		     * Revised summation order (smallest to largest):
		     */

		    zz = DLOG1P(y - ONE) - (31.0e+00D / 512.0e+00D +
					    7.77468164348425806061320404202632862024751447237708145e-05D);
		    break;

		case 7:		/* FALLTHRU */
		case 8:
		    temp = x + 16.0e+00D;
		    temp = STORE(temp) - 16.0e+00D;
		    x = STORE(temp);
		    y = x + x * TENTH;
		    z = DLOG1P10(x - ONE);

		    /*
		     *# zz = DLOG1P10(y - one) - (log10(11/10) = 21/512 + delta)
		     */

		    zz = DLOG1P10(y - ONE) -
			3.770601582250407501999712430242417067021904664530945965e-04D;
		    zz = zz - 21.0e+00D / 512.0e+00D;
		    break;

		default:
		    break;
		}

		w = ONE;
		if (z != ZERO)
		    w = (z - zz) / z;
		z = SIGN(w, z);
		if (z > ZERO)
		    k1 = k1 + 1;
		if (z < ZERO)
		    k3 = k3 + 1;

		w = ABS(w);
		if (w > r6)
		{
		    r6 = w;
		    x1 = x;
		}
		r7 = r7 + w * w;
		xl = a + TO_FP_T(i) * del;	/* OLD: xl = xl + del (bad for large n) */
	    } /* end for (i = 1; i <= n; ++i) */

	    k2 = n - k3 - k1;
	    r7 = SQRT(r7 / xn);

	    switch (j)
	    {
	    case 1:
		System.out.print("1TEST OF DLOG1P(X) VS T.S. EXPANSION OF DLOG1P(X)\n\n\n");
		break;

	    case 2:
		System.out.print("1TEST OF DLOG1P(X-1) VS DLOG1P(17(X-1)/16)-DLOG1P(17/16)\n\n");
		System.out.print(" IF BASE (= " + machar.ibeta +
				 ") IS NOT A POWER OF 2, EXPECT BIT LOSSES 1 OR 2 BITS LARGER THAN NORMAL.\n\n\n");
		break;

	    case 3:
		System.out.print("1TEST OF DL1P10(X-1) VS DL1P10(11(X-1)/10)-DL1P10(11/10)\n\n");
		System.out.print(" IF BASE (= " + machar.ibeta +
				 ") IS NOT 10, EXPECT BIT LOSSES 1 OR 2 BITS LARGER THAN NORMAL.\n\n\n");
		break;

	    case 4:
		System.out.print("1TEST OF DLOG1P((X-1)*(X-1)) VS 2 * DLOG1P(X-1)\n\n\n");
		break;

	    case 5:
		System.out.print("1TEST OF DLOG1P(X-1) VS DLOG1P(17(X-1)/16)-DLOG1P(17/16)\n\n");
		System.out.print(" IF BASE (= " + machar.ibeta +
				 ") IS NOT A POWER OF 2, EXPECT BIT LOSSES 1 OR 2 BITS LARGER THAN NORMAL.\n\n\n");
		break;

	    case 6:
		System.out.print("1TEST OF DLOG1P(X-1) VS DLOG1P(17(X-1)/16)-DLOG1P(17/16)\n\n");
		System.out.print(" IF BASE (= " + machar.ibeta +
				 ") IS NOT A POWER OF 2, EXPECT BIT LOSSES 1 OR 2 BITS LARGER THAN NORMAL.\n\n\n");
		break;

	    case 7:
		System.out.print("1TEST OF DL1P10(X-1) VS DL1P10(11(X-1)/10)-DL1P10(11/10)\n\n");
		System.out.print(" IF BASE (= " + machar.ibeta +
				 ") IS NOT 10, EXPECT BIT LOSSES 1 OR 2 BITS LARGER THAN NORMAL.\n\n\n");
		break;

	    case 8:
		System.out.print("1TEST OF DL1P10(X-1) VS DL1P10(11(X-1)/10)-DL1P10(11/10)\n\n");
		System.out.print(" IF BASE (= " + machar.ibeta +
				 ") IS NOT 10, EXPECT BIT LOSSES 1 OR 2 BITS LARGER THAN NORMAL.\n\n\n");
		break;

	    default:
		break;
	    }

	    System.out.print(" " + fmt.I(n,6) + " RANDOM ARGUMENTS WERE TESTED FROM THE INTERVAL\n");
	    if (j == 1)
		System.out.print("      (-EPS,+EPS), WHERE EPS = " +
				 fmt.E(c,14,4) + "\n\n\n");
	    else
		System.out.print("      (" + fmt.E(a,15,4) + "," +
				 fmt.E(b,15,4) + ")\n\n\n");

	    if ((j == 3) || (j == 7) || (j == 8))
		System.out.print(" DL1P10(X) WAS LARGER " + fmt.I(k1,5) + " TIMES,\n");
	    else
		System.out.print(" DLOG1P(X) WAS LARGER " + fmt.I(k1,5) + " TIMES,\n");

	    System.out.print("               AGREED " + fmt.I(k2,5) + " TIMES, AND\n");
	    System.out.print("          WAS SMALLER " + fmt.I(k3,5) + " TIMES.\n\n\n");

	    System.out.print(" THERE ARE " + fmt.I(machar.it,3) +
			     " BASE " + fmt.I(machar.ibeta,3) +
			     " SIGNIFICANT DIGITS IN A FLOATING-POINT NUMBER\n\n\n");

	    w = -999.0e+00D;
	    if (r6 != ZERO)
		w = ALOG(ABS(r6)) / albeta;

	    System.out.print(" THE MAXIMUM RELATIVE ERROR OF " + fmt.E(r6,14,4) +
			     " = " + fmt.I(machar.ibeta,4) +
			     " ** " + fmt.F(w,6,2) + "\n");
	    System.out.print("    OCCURRED FOR X = " + fmt.E(x1,16,6) + "\n");
	    w = AMAX1(ait + w, ZERO);

	    System.out.print(" THE ESTIMATED LOSS OF BASE " + fmt.I(machar.ibeta,3) +
			     " SIGNIFICANT DIGITS IS " + fmt.F(w,6,2) + "\n\n\n");
	    w = -999.0e+00D;
	    if (r7 != ZERO)
		w = ALOG(ABS(r7)) / albeta;

	    System.out.print(" THE ROOT MEAN SQUARE RELATIVE ERROR WAS " + fmt.E(r7,14,4) +
			     " = " + fmt.I(machar.ibeta,4) + " ** " + fmt.F(w,6,2) + "\n");
	    w = AMAX1(ait + w, ZERO);

	    System.out.print(" THE ESTIMATED LOSS OF BASE " + fmt.I(machar.ibeta,3) +
			     " SIGNIFICANT DIGITS IS " + fmt.F(w,6,2) + "\n\n\n");

	    switch (j)
	    {
	    case 1:
		a = SQRT(HALF);
		b = 15.0e+00D / 16.0e+00D;
		break;

	    case 2:
		a = SQRT(TENTH);
		b = 0.9e+00D;
		break;

	    case 3:
		a = 16.0e+00D;
		b = 240.0e+00D;
		break;

	    case 4:
		a = ONE - ONE / beta;
		b = ONE - d56;
		break;

	    case 5:
		a = ONE + d56;
		b = ONE + ONE / beta;
		break;

	    case 6:
		a = ONE - ONE / beta;
		b = ONE - d78;
		break;

	    case 7:
		a = ONE + d78;
		b = ONE + ONE / beta;
		break;

	    default:
		break;

	    }
	} /* for (j = 1; j <= 8; ++j) */

	/*
	 *-----------------------------------------------------------------------
	 *     SPECIAL TESTS
	 *-----------------------------------------------------------------------
	 */

	System.out.print("1SPECIAL TESTS\n\n\n");

	System.out.print(" THE IDENTITY  DLOG1P(X-1) = -DLOG1P((1/X)-1)  WILL BE TESTED.\n\n");
	System.out.print("        X         F(X-1) + F((1/X)-1)\n\n");

	for (i = 1; i <= 5; ++i)
	{
	    x = RAN();
	    x = x + x + 15.0e+00D;
	    y = ONE / x;
	    z = DLOG1P(x - ONE) + DLOG1P(y - ONE);
	    zz = z / machar.eps;
	    System.out.print(" " + fmt.F(x,14,7) + " " + fmt.F(z,16,7) + " " + fmt.F(zz,14,2) + " ULPS\n\n");
	}

	System.out.print("\n");
	System.out.print(" THE IDENTITY  DLOG1P(X) = X - X**2/2  FOR ABS(X) .LE. SQRT(3*EPS)/BETA WILL BE TESTED.\n");
	System.out.print(" NONZERO RESULTS SUGGEST THAT DLOG1P(X) HAS BEEN SLOPPILY IMPLEMENTED AS ALOG(1+X)\n\n");
	System.out.print("        X         F(X) - F(X - X**2/2)\n\n");

	x = SQRT(machar.eps + machar.eps + machar.eps) / beta;
	for (i = 1; i <= 5; ++i)
	{
	    y = DLOG1P(x);
	    z = y - (x - HALF * x * x);
	    zz = z / machar.eps;
	    System.out.print(" " + fmt.E(x,16,7) + " " + fmt.E(z,16,7) + " " + fmt.F(zz,15,2) + " ULPS\n\n");

	    x = -x;
	    y = DLOG1P(x);
	    z = y - (x - HALF * x * x);
	    zz = z / machar.eps;
	    System.out.print(" " + fmt.E(x,16,7) + " " + fmt.E(z,16,7) + " " + fmt.F(zz,15,2) + " ULPS\n\n");

	    x = -x * HALF;
	}

	System.out.print("\n\n");
	System.out.print(" TEST OF SPECIAL ARGUMENTS\n\n\n");

	x = -ZERO;
	y = DLOG1P(x);
	System.out.print(" DLOG1P(" + fmt.E(x,16,7) + ") = " + fmt.E(y,16,7) + "\n\n\n");

	x = ZERO;
	y = DLOG1P(x);
	System.out.print(" DLOG1P(" + fmt.E(x,16,7) + ") = " + fmt.E(y,16,7) + "\n\n\n");

	x = -(ONE - machar.epsneg);
	y = DLOG1P(x);
	System.out.print(" DLOG1P(" + fmt.E(x,16,7) + ") = " + fmt.E(y,16,7) + "\n\n\n");

	x = -machar.eps;
	y = DLOG1P(x);
	System.out.print(" DLOG1P(" + fmt.E(x,16,7) + ") = " + fmt.E(y,16,7) + "\n\n\n");

	x = machar.eps;
	y = DLOG1P(x);
	System.out.print(" DLOG1P(" + fmt.E(x,16,7) + ") = " + fmt.E(y,16,7) + "\n\n\n");

	x = -(machar.eps + machar.eps / (beta * beta * beta * beta));
	y = DLOG1P(x);
	System.out.print(" DLOG1P(" + fmt.E(x,16,7) + ") = " + fmt.E(y,16,7) + "\n\n\n");

	x = machar.eps + machar.eps / (beta * beta * beta * beta);
	y = DLOG1P(x);
	System.out.print(" DLOG1P(" + fmt.E(x,16,7) + ") = " + fmt.E(y,16,7) + "\n\n\n");

	x = machar.xmin;
	y = DLOG1P(x);
	System.out.print(" DLOG1P(XMIN) = DLOG1P(" + fmt.E(x,16,7) + ") = " + fmt.E(y,16,7) + "\n\n\n");

	x = machar.xmax;
	y = DLOG1P(x);
	System.out.print(" DLOG1P(XMAX) = DLOG1P(" + fmt.E(x,16,7) + ") = " + fmt.E(y,16,7) + "\n\n\n");

	/*
	 *-----------------------------------------------------------------------
	 *     Tests of IEEE 754 subnormals (if available and enabled)
	 *-----------------------------------------------------------------------
	 */

	if (machar.xmin * HALF != ZERO)
	{
	    System.out.print(" TEST OF IEEE 754 SUBNORMAL ARGUMENTS\n\n");

	    k1 = 0;
	    k2 = 0;
	    w = machar.eps;
	    z = machar.xmin;
	    /*
	     * The choice of x here ensures that all significant bits are one, so
	     * that we can detect deficient implementations of dlog1p() that lose
	     * low-order bits. 
	     */
	    while (z != ZERO)
	    {
		x = z * (ONE - w);
		y = DLOG1P(x);
		if (y != x)
		{
		    k1 = k1 + 1;
		    System.out.print(" ERROR: DLOG1P(" + fmt.E(x,15,6) +
				     ") RETURNED " + fmt.E(y,15,6) +
				     " INSTEAD OF CORRECT " + fmt.E(x,15,6) + "\n");
		}

		y = DLOG1P(-x);
		if (y != (-x))
		{
		    k1 = k1 + 1;
		    System.out.print(" ERROR: DLOG1P(" + fmt.E(-x,15,6) +
				     ") RETURNED " + fmt.E(y,15,6) +
				     " INSTEAD OF CORRECT " + fmt.E(-x,15,6) + "\n");
		}

		k2 = k2 + 2;
		z = z * HALF;
		w += w;
	    }

	    if (k1 == 0)
		System.out.print(" ALL " + fmt.I(k2,3) +
				 " SUBNORMALS TESTED CORRECTLY SATISFY DLOG1P(X) = X\n\n\n");
	    else
		System.out.print(" " + fmt.I(k1,2) + " OF " + fmt.I(k2,3) +
				 " SUBNORMALS TESTED FAIL TO SATISFY DLOG1P(X) = X\n\n\n");
	}

	/*
	 *-----------------------------------------------------------------------
	 *     TEST OF ERROR RETURNS
	 *-----------------------------------------------------------------------
	 */

	System.out.print("1TEST OF ERROR RETURNS\n\n\n");

	x = -TWO;
	System.out.print(" DLOG1P WILL BE CALLED WITH THE ARGUMENT " + fmt.E(x,14,4) + "\n");
	System.out.print(" THIS SHOULD TRIGGER AN ERROR MESSAGE\n\n\n");
	y = DLOG1P(x);
	System.out.print(" DLOG1P RETURNED THE VALUE " + fmt.E(y,15,4) + "\n\n\n\n");

	x = -ONE;
	System.out.print(" DLOG1P WILL BE CALLED WITH THE ARGUMENT " + fmt.E(x,15,4) + "\n");
	System.out.print(" THIS SHOULD TRIGGER AN ERROR MESSAGE\n\n\n");
	y = DLOG1P(x);
	System.out.print(" DLOG1P RETURNED THE VALUE " + fmt.E(y,15,4) + "\n\n\n\n");

	System.out.print(" THIS CONCLUDES THE TESTS\n");
    }

    public static void main(String[] args)
    {
	tdlog1p();
    }
}
