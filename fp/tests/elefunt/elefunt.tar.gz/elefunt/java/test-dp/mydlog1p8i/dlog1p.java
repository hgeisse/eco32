import java.lang.Math;

public class dlog1p
{
    final private static double ONE = 1.0D;
    final private static double ZERO = 0.0D;

    final private static double LOG10E = 0.43429448190325182765112891891660508229439700580366D;

    public static double dlog1p(double x)
    {
	/*
	 * (log1p)
	 * Return dlog(1 + x), taking care to avoid subtraction loss.
	 *
	 * This version uses minimax rational polynomials computed by Maple,
	 * e.g.,
	 *
	 *     with(numapprox):
	 *     Digits := 35:
	 *     minimax(log(1+x)/x, x = -0.5 .. -0.375, [2,2], 1, 'err');
	 *     printf("%.2e\n", err):
	 *
	 * on 8 subintervals, chosen to have accuracy adequate for IEEE 754
	 * and VAX 32-bit arithmetic.
	 * (17-Jun-2002)
	 */

	/* System generated locals */
	double ret_val;

	/*
	 * We handle the computation in three regions:
	 *
	 * x in [-Infinity, -0.5):  log(1+x)
	 * x in [-0.5, 0.5]:        minimax rational polynomials in 8 blocks
	 * x in (0.5, Infinity]:    log(1+x)
	 *
	 * The central region suffers loss of ONE or more bits if the
	 * simple formula is used.
	 *
	 * We also handle the cases of log1p(NaN) and log1p(0) specially,
	 * so as to preserve NaNs, and the sign of ZERO.
	 */

	if (x != x)
	    ret_val = x;
	else if (x == ZERO)
	    ret_val = x;
	else if (x < -0.5e+00)
	    ret_val = Math.log(ONE + x);
	else if (x <= -0.375e+00)
	{			/* Error = 1.09e-18 */
	    ret_val = x *
		(
		 (  4.5777041374710203e+00 +
		    (  1.0824898530772859e+01 +
		       (  8.7557377520069871e+00 +
			  (  2.7344283266106404e+00 +
			     (  2.4810243295973145e-01
				) * x) * x) * x) * x)
		 /
		 (  4.5777041621511807e+00 +
		    (  1.3113751096331051e+01 +
		       (  1.3786716041984948e+01 +
			  (  6.4009818606418736e+00 +
			     (  1.2159763564861204e+00 +
				(  6.1310243714265162e-02
				   ) * x) * x) * x) * x) * x) );
	}
	else if (x <= -0.25e+00)
	{			/* Error = 1.28e-17 */
	      ret_val = x *
		  (
		   (  2.3664631320024130e+00 +
		      (  4.5710195455002802e+00 +
			 (  2.7506008228429064e+00 +
			    (  5.1549473085824271e-01 +
			       (  9.2891291613275938e-03
				  ) * x) * x) * x) * x)
		   /
		   (  2.3664631299161469e+00 +
		      (  5.7542510555704432e+00 +
			 (  4.8389046840665906e+00 +
			    (  1.6084752098772164e+00 +
			       (  1.6581346171846399e-01
				  ) * x) * x) * x) * x) );
	}
	else if (x <= -0.125e+00)
	{			/* Error = 2.61e-18 */
	    ret_val = x *
		(
		 (  1.5960762199530835e+00 +
		    (  2.9352163636366689e+00 +
		       (  1.6546073870952289e+00 +
			  (  2.8230129711964226e-01 +
			     (  4.2326486667577103e-03
				) * x) * x) * x) * x)
		 /
		 (  1.5960762199470763e+00 +
		    (  3.7332544733236624e+00 +
		       (  2.9892092111718665e+00 +
			  (  9.3150673029520678e-01 +
			     (  8.7680814287194334e-02
				) * x) * x) * x) * x) );
	}
	else if (x <= 0.0e+00)
	{			/* Error = 6.70e-19 */
	    ret_val = x *
		(
		 (  1.1512453839840972e+00 +
		    (  2.0254530049869735e+00 +
		       (  1.0758992666739165e+00 +
			  (  1.6851943765528674e-01 +
			     (  2.1555311347408590e-03
				) * x) * x) * x) * x)
		 /
		 (  1.1512453839840972e+00 +
		    (  2.6010756969790211e+00 +
		       (  1.9926886538352088e+00 +
			  (  5.8564987822829283e-01 +
			     (  5.0770765871786014e-02
				) * x) * x) * x) * x) );
	}
	else if (x <= 0.125e+00)
	{			/* Error = 2.03e-19 */
	    ret_val = x *
		(
		 (  8.7217154834940371e-01 +
		    (  1.4735803475030032e+00 +
		       (  7.4104978890591803e-01 +
			  (  1.0728917920828274e-01 +
			     (  1.1932542494206477e-03
				) * x) * x) * x) * x)
		 /
		 (  8.7217154834940371e-01 +
		    (  1.9096661216777048e+00 +
		       (  1.4051590002950247e+00 +
			  (  3.9135619254573872e-01 +
			     (  3.1467238052671070e-02
				) * x) * x) * x) * x) );
	}
	else if (x <= 0.25e+00)
	{			/* Error = 7.05e-20 */
	    ret_val = x *
		(
		 (  6.8586847632866200e-01 +
		    (  1.1162704451935568e+00 +
		       (  5.3349324796156986e-01 +
			  (  7.1805647010229331e-02 +
			     (  7.0487933751550271e-04
				) * x) * x) * x) * x)
		 /
		 (  6.8586847632907489e-01 +
		    (  1.4592046833358813e+00 +
		       (  1.0344727647207399e+00 +
			  (  2.7410757975888509e-01 +
			     (  2.0561960480928906e-02
				) * x) * x) * x) * x) );
	}
	else if (x <= 0.375e+00)
	{			/* Error = 2.71e-20 */
	    ret_val = x *
		(
		 (  5.5535871709637993e-01 +
		    (  8.7291295080225353e-01 +
		       (  3.9774905334807039e-01 +
			  (  5.0013874499665808e-02 +
			     (  4.3861052898128761e-04
				) * x) * x) * x) * x)
		 /
		 (  5.5535871712120465e-01 +
		    (  1.1505923085672550e+00 +
		       (  7.8792564680867556e-01 +
			  (  1.9928550707725046e-01 +
			     (  1.4016402522284274e-02
				) * x) * x) * x) * x) );
	}
	else if (x <= 0.5e+00)
	{			/* Error = 1.14e-20 */
	    ret_val = x *
		(
		 (  4.6035401976382008e-01 +
		    (  7.0032345920176128e-01 +
		       (  3.0507378915783908e-01 +
			  (  3.5990424762222504e-02 +
			     (  2.8479865231883178e-04
				) * x) * x) * x) * x)
		 /
		 (  4.6035402005083824e-01 +
		    (  9.3050046252633180e-01 +
		       (  6.1687275191461434e-01 +
			  (  1.4934802167217304e-01 +
			     (  9.8909138386133843e-03
				) * x) * x) * x) * x) );
	}
	else
	    ret_val = Math.log(ONE + x);

	return (ret_val);
    }


    public static double dl1p10(double x)
    {
	/* (log1p10) */
	/* Return alog10(1 + x), taking care to avoid subtraction loss. */
	/* (17-Jun-2002) */

	return (dlog1p(x) * LOG10E);
    }
}
