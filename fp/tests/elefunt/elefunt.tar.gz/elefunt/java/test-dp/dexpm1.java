import java.lang.Math;

public class dexpm1
{
    final private static double ONE = 1.0D;

    public static double expm1(double x)
    {				// TO DO: replace with more accurate algorithm
	return (Math.exp(x) - ONE);
    }
}
