/* -*-java-*- elefunt.java */

import java.io.*;
import java.lang.Math;

public final class elefunt
{
    // VERSION and DATE must be updated with every change!
    public static final String VERSION = "1.00";
    public static final String DATE = "Wed May 29 17:12:35 2002";

    public static final int MAXTEST = 2000;
    public static final double ONE = 1.0;
    public static final double ZERO = 0.0;
    public static final double TWO = 2.0;
    public static final double TEN = 10.0;

    public static double ABS(double x)			{ return (Math.abs(x)); }
    public static double AINT(double x)			{ return ((double)((long)x)); }
    public static double ACOS(double x)			{ return (Math.acos(x)); }
    public static double ALOG(double x)			{ return (Math.log(x)); }
    public static double ALOG10(double x)		{ return (extmath.log10(x)); }
    public static double AMAX1(double x, double y)	{ return (Math.max(x,y)); }
    public static double ASIN(double x)			{ return (Math.asin(x)); }
    public static double ATAN(double x)			{ return (Math.atan(x)); }
    public static double ATAN2(double x, double y)	{ return (Math.atan2(x,y)); }
    public static double COS(double x)			{ return (Math.cos(x)); }
    public static double COSH(double x)			{ return (extmath.cosh(x)); }
    public static double COTAN(double x)		{ return (extmath.cotan(x)); }
    public static double EXP(double x)			{ return (Math.exp(x)); }
    public static double FLOOR(double x)		{ return (Math.floor(x)); }
    public static double IPOW(double x,int n)		{ return (ipow.ipow(x,n)); }
    public static double LOG(double x)			{ return (Math.log(x)); }
    public static double LOG10(double x)		{ return (extmath.log10(x)); }
    public static double POW(double x, double y)	{ return (Math.pow(x,y)); }
    public static double RAN()				{ return (ran.ran()); }
    public static double RANDL(double x)		{ return (randl.randl(x)); }
    public static double SIGN(double x, double y)	{ return ((y >= ZERO) ? ABS(x) : -ABS(x)); }
    public static double SIN(double x)			{ return (Math.sin(x)); }
    public static double SINH(double x)			{ return (extmath.sinh(x)); }
    public static double SQRT(double x)			{ return (Math.sqrt(x)); }
    public static double STORE(double x)		{ return (store.store(x)); }
    public static double TAN(double x)			{ return (Math.tan(x)); }
    public static double TANH(double x)			{ return (extmath.tanh(x)); }
    public static double TO_FP_T(float x)		{ return ((double)x); }
    public static double TO_FP_T(int n)			{ return ((double)n); }

    public static int INT(double x)			{ return ((int)(x)); }

    public static double errout(String message)
    {
	System.err.println(message);
	System.out.println(message);
	return (java.lang.Double.NaN);
    }

    public static void banner(String testname)
    {
	System.out.println(" This is " + testname +
			   ": ELEFUNT in Java: version " + elefunt.VERSION +
			   " of " + elefunt.DATE + "\n");
    }
}
