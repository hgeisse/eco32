#! /bin/sh 

PATH=/usr/local/test/bin:$PATH
export PATH

for f in talldp.o talog.o tasin.o tatan.o texp.o tmachar.o tpower.o tsin.o tsinh.o tsqrt.o ttan.o ttanh.o
do
	g=`basename $f .o`
	gcj -g --encoding=UTF-8 --main=$g -o $g.exe *.o ../common/*.o
	ls -l $g.exe
done
