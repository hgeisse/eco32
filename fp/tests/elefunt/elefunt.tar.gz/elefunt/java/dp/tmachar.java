/* -*-java-*- tmachar.java */

import java.io.*;

public class tmachar
{
    public static void tmachar()
    {
	System.out.println("ibeta............ " + machar.ibeta);
	System.out.println("it............... " + machar.it);
	System.out.println("irnd............. " + machar.irnd);
	System.out.println("ngrd............. " + machar.ngrd);
	System.out.println("machep........... " + machar.machep);
	System.out.println("negep............ " + machar.negep);
	System.out.println("iexp............. " + machar.iexp);
	System.out.println("minexp........... " + machar.minexp);
	System.out.println("maxexp........... " + machar.maxexp);
	System.out.println("eps.............. " + machar.eps);
	System.out.println("epsneg........... " + machar.epsneg);
	System.out.println("xmin............. " + machar.xmin);
	System.out.println("xmax............. " + machar.xmax);
    }

    public static void main(String[] args)
    {
	tmachar();
    }
}
