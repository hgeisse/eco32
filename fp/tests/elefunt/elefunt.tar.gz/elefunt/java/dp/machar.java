/* -*-java-*- machar.java */

import java.io.*;

public class machar
{
    /* Java's floating-point model is required to be a
    platform-independent subset of IEEE 754 arithmetic, so we simply
    define all of the environmental inquiry values as immutable
    constants. */

    public static final int ibeta	= 2;
    public static final int it		= 53;
    public static final int irnd	= 5;
    public static final int ngrd	= 0;
    public static final int machep	= -52;
    public static final int negep	= -53;
    public static final int iexp	= 11;
    public static final int minexp	= -1022;
    public static final int maxexp	= 1024;
    public static final double eps	= 2.22044604925031308e-16;
    public static final double epsneg	= 1.11022302462515654e-16;
    public static final double xmin	= Math.pow(2.0, -1022.0); // NOT Double.MIN_VALUE == 4.9E-324 == Math.pow(2.0, -1074.0)
    public static final double xmax	= Double.MAX_VALUE;	// 1.79769313486231571e+308

    public static void main(String[] args)
    {
	System.out.println("ibeta............ " + ibeta);
	System.out.println("it............... " + it);
	System.out.println("irnd............. " + irnd);
	System.out.println("ngrd............. " + ngrd);
	System.out.println("machep........... " + machep);
	System.out.println("negep............ " + negep);
	System.out.println("iexp............. " + iexp);
	System.out.println("minexp........... " + minexp);
	System.out.println("maxexp........... " + maxexp);
	System.out.println("eps.............. " + eps);
	System.out.println("epsneg........... " + epsneg);
	System.out.println("xmin............. " + xmin);
	System.out.println("xmax............. " + xmax);
    }
}
