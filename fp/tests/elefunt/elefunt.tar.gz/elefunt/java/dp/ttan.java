/* -*-java-*- ttan.java */

import java.io.*;

public class ttan
{
    // shorthands to avoid the need for fully-qualified names, sigh...
    private static double ABS(double x)			{ return (elefunt.ABS(x)); }
    private static double ALOG(double x)		{ return (elefunt.ALOG(x)); }
    private static double AMAX1(double x,double y)	{ return (elefunt.AMAX1(x,y)); }
    private static double COTAN(double x)		{ return (elefunt.COTAN(x)); }
    private static double IPOW(double x, int n)		{ return (elefunt.IPOW(x,n)); }
    private static double POW(double x,double y)	{ return (elefunt.POW(x,y)); }
    private static double RAN()				{ return (elefunt.RAN()); }
    private static double SQRT(double x)		{ return (elefunt.SQRT(x)); }
    private static double TAN(double x)			{ return (elefunt.TAN(x)); }
    private static double TO_FP_T(long n)		{ return (elefunt.TO_FP_T(n)); }

    public static void ttan()
    {
	/*#     program to test tan/cotan
	#
	#     data required
	#
	#        none
	#
	#     subprograms required from this package
	#
	#        machar - an environmental inquiry program providing
	#                 information on the floating-point arithmetic
	#                 system.  note that the call to machar can
	#                 be deleted provided the following three
	#                 parameters are assigned the values indicated
	#
	#                 ibeta  - the radix of the floating-point system
	#                 it     - the number of base-ibeta digits in the
	#                          significand of a floating-point number
	#                 minexp - the largest in magnitude negative
	#                          integer such that float(ibeta)**minexp
	#                          is a positive floating-point number
	#
	#        ran(k) - a function subprogram returning random real
	#                 numbers uniformly distributed over (0,1)
	#
	#
	#     standard fortran subprograms required
	#
	#         abs, alog, amax1, cotan, float, tan, sqrt
	#
	#
	#     latest revision - december 6, 1979
	#
	#     author - w. j. cody
	#              argonne national laboratory
	#
	# */

	final double ait = TO_FP_T(machar.it);
	final double beta = TO_FP_T(machar.ibeta);
	final double albeta = ALOG(beta);
	final double ONE = elefunt.ONE;
	final double ZERO = elefunt.ZERO;

	int i,
	    j,
	    k1,
	    k2,
	    k3,
	    n;

	double
	    a,
	    b,
	    betap,
	    c1,
	    c2,
	    del,
	    half,
	    pi,
	    r6,
	    r7,
	    w,
	    x,
	    xl,
	    xn,
	    x1,
	    y,
	    z,
	    zz;

	/*******************************************************************/

	elefunt.banner("ttan");

	ran.ranset(initseed.initseed());

	half = 0.5e0;
	pi = 3.14159265e0;
	a = ZERO;
	b = pi * 0.25e0;
	n = (int)maxtest.maxtest();
	xn = TO_FP_T(n);
	z = ZERO;

	/* random argument accuracy tests */

	for (j = 1; j <= 4; ++j)
	{
	    k1 = 0;
	    k3 = 0;
	    x1 = ZERO;
	    r6 = ZERO;
	    r7 = ZERO;
	    del = (b - a) / xn;
	    xl = a;

	    for (i = 1; i <= n; ++i)
	    {
		x = del * RAN() + xl;
		y = x * half;
		x = y + y;
		if (j == 4)
		{
		    z = COTAN(x);
		    zz = COTAN(y);
		    w = 1.0e0;
		    if (z != ZERO)
		    {
			w = ((half - zz) + half) * ((half + zz) + half);
			w = (z + w / (zz + zz)) / z;
		    }
		}
		else
		{
		    z = TAN(x);
		    zz = TAN(y);
		    w = 1.0e0;
		    if (z != ZERO)
		    {
			w = ((half - zz) + half) * ((half + zz) + half);
			w = (z - (zz + zz) / w) / z;
		    }
		}
		if (w > ZERO)
		    k1 = k1 + 1;
		if (w < ZERO)
		    k3 = k3 + 1;
		w = ABS(w);
		if (w > r6)
		{
		    r6 = w;
		    x1 = x;
		}
		r7 = r7 + w * w;
		xl = a + TO_FP_T(i) * del;	/* OLD: xl = xl + del (bad for large n) */
	    }

	    k2 = n - k3 - k1;
	    r7 = SQRT(r7 / xn);
	    if (j != 4)
		System.out.print("1TEST OF TAN(X) VS 2*TAN(X/2)/(1-TAN(X/2)**2)\n\n\n");
	    if (j == 4)
		System.out.print("1TEST OF COT(X) VS (COT(X/2)**2-1)/(2*COT(X/2))\n\n\n");
	    System.out.print(fmt.I(n,7) + " RANDOM ARGUMENTS WERE TESTED FROM THE INTERVAL\n");
	    System.out.print("    (" + fmt.E(a,15,4) + "," + fmt.E(b,15,4) + ")\n\n\n");
	    if (j != 4)
	    {
		System.out.print(" TAN(X) WAS LARGER" + fmt.I(k1,6) + " TIMES,\n");
		System.out.print("            AGREED" + fmt.I(k2,6) + " TIMES, AND\n");
		System.out.print("       WAS SMALLER" + fmt.I(k3,6) + " TIMES.\n\n");
	    }
	    if (j == 4)
	    {
		System.out.print(" COT(X) WAS LARGER" + fmt.I(k1,6) + " TIMES,\n");
		System.out.print("            AGREED" + fmt.I(k2,6) + " TIMES, AND\n");
		System.out.print("       WAS SMALLER" + fmt.I(k3,6) + " TIMES.\n\n\n");
	    }
	    System.out.print(" THERE ARE" + fmt.I(machar.it,4) + " BASE" + fmt.I(machar.ibeta,4) +
			     " SIGNIFICANT DIGITS IN A FLOATING-POINT NUMBER\n\n\n");
	    w = -999.0e0;
	    if (r6 != ZERO)
		w = ALOG(ABS(r6)) / albeta;
	    System.out.print(" THE MAXIMUM RELATIVE ERROR OF" + fmt.E(r6,15,4) +
			     " = " + fmt.I(machar.ibeta,4) + " **" + fmt.F(w,7,2) + "\n");
	    System.out.print("    OCCURRED FOR X =" + fmt.E(x1,17,6) + "\n");
	    w = AMAX1(ait + w, ZERO);
	    System.out.print(" THE ESTIMATED LOSS OF BASE" + fmt.I(machar.ibeta,4) +
			     " SIGNIFICANT DIGITS IS" + fmt.F(w,7,2) + "\n\n\n");
	    w = -999.0e0;
	    if (r7 != ZERO)
		w = ALOG(ABS(r7)) / albeta;
	    System.out.print(" THE ROOT MEAN SQUARE RELATIVE ERROR WAS" + fmt.E(r7,15,4) +
			     " = " + fmt.I(machar.ibeta,4) + " **" + fmt.F(w,7,2) + "\n");
	    w = AMAX1(ait + w, ZERO);
	    System.out.print(" THE ESTIMATED LOSS OF BASE" + fmt.I(machar.ibeta,4) +
			     " SIGNIFICANT DIGITS IS" + fmt.F(w,7,2) + "\n\n\n");
	    if (j != 1)
	    {
		a = pi * 6.0e0;
		b = a + pi * 0.25e0;
	    }
	    else
	    {
		a = pi * 0.875e0;
		b = pi * 1.125e0;
	    }
	}

	/* special tests */

	System.out.print("1SPECIAL TESTS\n\n\n");
	System.out.print(" THE IDENTITY  TAN(-X) = -TAN(X)  WILL BE TESTED.\n\n");
	System.out.print("        X         F(X) + F(-X)\n\n");

	for (i = 1; i <= 5; ++i)
	{
	    x = RAN() * a;
	    z = TAN(x) + TAN(-x);
	    System.out.print(fmt.E(x,15,7) + fmt.E(z,15,7) + "\n\n");
	}

	System.out.print(" THE IDENTITY TAN(X) = X , X SMALL, WILL BE TESTED.\n\n");
	System.out.print("        X         X - F(X)\n\n");
	betap = IPOW(beta, machar.it);
	x = RAN() / betap;

	for (i = 1; i <= 5; ++i)
	{
	    z = x - TAN(x);
	    System.out.print(fmt.E(x,15,7) + fmt.E(z,15,7) + "\n\n");
	    x = x / beta;
	}

	System.out.print(" TEST OF UNDERFLOW FOR VERY SMALL ARGUMENT.\n\n");
	x = POW(beta, TO_FP_T(machar.minexp) * 0.75e0);
	y = TAN(x);
	System.out.print("       TAN(" + fmt.E(x,13,6) + ") =" + fmt.E(y,13,6) + "\n\n");
	c1 = -225.0e0;
	c2 = -0.950846454195142026e0;
	x = 11.0e0;
	y = TAN(x);
	w = ((c1 - y) + c2) / (c1 + c2);
	z = ALOG(ABS(w)) / albeta;
	System.out.print(" THE RELATIVE ERROR IN TAN(11) IS" + fmt.E(w,15,7) +
			 " = " + fmt.I(machar.ibeta,4) + " **" + fmt.F(z,7,2) + " WHERE\n\n");
	System.out.print("      TAN(" + fmt.E(x,13,6) + ") =" + fmt.E(y,13,6) + "\n\n");
	w = AMAX1(ait + z, ZERO);
	System.out.print(" THE ESTIMATED LOSS OF BASE" + fmt.I(machar.ibeta,4) + " SIGNIFICANT DIGITS IS" + fmt.F(w,7,2) + "\n\n\n");

	/* test of error returns */

	System.out.print("1TEST OF ERROR RETURNS\n\n\n");

	x = POW(beta, TO_FP_T(machar.it / 2));
	System.out.print(" TAN WILL BE CALLED WITH THE ARGUMENT" + fmt.E(x,15,4) + "\n");
	System.out.print(" THIS SHOULD NOT TRIGGER AN ERROR MESSAGE\n\n\n");
	try
	{
	    y = TAN(x);
	}
	catch (ArithmeticException e)
	{
	    y = elefunt.errout("ERROR: TAN(" + x + ") raised " + e);
	}
	System.out.print(" TAN RETURNED THE VALUE" + fmt.E(y,15,4) + "\n\n\n\n");

	x = betap;
	System.out.print("\nTAN WILL BE CALLED WITH THE ARGUMENT" + fmt.E(x,15,4) + "\n");
	System.out.print(" THIS SHOULD TRIGGER AN ERROR MESSAGE\n\n\n");
	try
	{
	    y = TAN(x);
	}
	catch (ArithmeticException e)
	{
	    y = elefunt.errout("ERROR: TAN(" + x + ") raised " + e);
	}
	System.out.print(" TAN RETURNED THE VALUE" + fmt.E(y,15,4) + "\n\n\n\n");

	System.out.print(" THIS CONCLUDES THE TESTS\n");
    }

    public static void main(String[] args)
    {
	ttan();
    }
}
