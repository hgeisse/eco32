/* -*-java-*- store.java */

public class store
{
    public static double store(double value)
    {
	return (value);
    }
}
