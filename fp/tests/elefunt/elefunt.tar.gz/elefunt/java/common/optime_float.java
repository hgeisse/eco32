// Time elementary float operations in Java.
//
// Sample results (all times in nanosec) with:
//
//	javac -O optime_float.java
//	time java -DMAXTEST=1000000 optime_float
//
//	/usr/local/test/bin/gcj -g --encoding=UTF-8 --main=optime_float =
//		-R/usr/local/test/lib:/usr/local/test/lib/gcc-lib/sparc-sun-solaris2.8/3.1 \
//		optime_float.java && time ./a.out
//
// Unless otherwise noted at the end of the row, results are
// independent of Java compiler optimization level.
//
//	============================================================================================
//						Type = float
//	============================================================================================
//	Vendor and O/S		CPU		Java	MHz	add	divide	multiply power	sqrt
//	============================================================================================
//	Apple Darwin 5.4	PowerPC		1.3.3	533	 7	 37	 7	 1301	 202
//	DEC Alpha OSF/1 4.0	Alpha 21164	1.0	466	14	 63	11	  545	 391
//	Intel GNU/Linux RH7.2	Intel Pentium 4	1.2.2	600	14	 62	17	 2587	 136
//	SGI IRIX 6.5		MIPS R10000	1.3	180	10	 79	10	 1320	 529
//	Sun GNU/Linux RH6.2	SuperSPARC	kaf1.1	 50	94	154	98	12300	 960
//	Sun Solaris 2.8		UltraSPARC II	1.1	400	 0	  0	 0	 1098	 320
//	Sun Solaris 2.8		UltraSPARC II	1.2	400	10	 37	10	 2133	  79
//	Sun Solaris 2.8		UltraSPARC II	1.4	400	12	 41	13	 2184	 494
//	Sun Solaris 2.8		UltraSPARC II	gcj-3.1	400	11	 44	11	 1785	2451 (-g)
//	Sun Solaris 2.8		UltraSPARC II	gcj-3.1	400	 1	  1	 1	 1729	  91 (-O)
//	============================================================================================
//						Type = double
//	============================================================================================
//	Vendor and O/S		CPU		Java	MHz	add	divide	multiply power	sqrt
//	============================================================================================
//	Apple Darwin 5.4	PowerPC		1.3.3	533	  7	 62	  7	 1247	 194
//	DEC Alpha OSF/1 4.0	Alpha 21164	1.0	466	 12	124	 11	  592	 373
//	Intel GNU/Linux RH7.2	Intel Pentium 4	1.2.2	600	 14	 62	 17	 1927	  96
//	SGI IRIX 6.5		MIPS R10000	1.3	180	 10	118	 10	 1346	 526
//	Sun GNU/Linux RH6.2	SuperSPARC	kaf1.1	 50	113	234	113	12030	1075
//	Sun Solaris 2.8		UltraSPARC II	1.1	400	  0	  0	  0	 1126	 322
//	Sun Solaris 2.8		UltraSPARC II	1.2	400	 10	 67	 10	 2097	  82
//	Sun Solaris 2.8		UltraSPARC II	1.4	400	 12	 69	 12	 2141	 486
//	Sun Solaris 2.8		UltraSPARC II	gcj-3.1	400	 11	 68	 11	 1688	3339 (-g)
//	Sun Solaris 2.8		UltraSPARC II	gcj-3.1	400	  1	  1	  1	 1624	  77 (-O)
//	============================================================================================

public class optime_float
{
    public static long longPropertyValue(String property_name, long default_value)
    {
	Long the_value;
	String p;

	p = System.getProperty(property_name);
	if (p != null)
	{
	    try
	    {
		the_value = new Long(p);
		return (the_value.longValue());
	    }
	    catch (java.lang.NumberFormatException e)
	    {
		System.err.println("Ignoring bad number format in " + property_name + " = " + p);
	    }
	}
	return (default_value);
    }

    final private static long MAXTEST = longPropertyValue("MAXTEST", 1000000);
    final private static float MINNORMAL = (float)Math.pow(2.0,-126.0);

    public static void test_add()
    {
	float result;
	float term = (1.0F + (float)Math.random()) * MINNORMAL;
	long millis;

	millis = System.currentTimeMillis();
	for (long i = 0; i < MAXTEST; ++i)
	{
	    result = 1.0F;
	    result +=
		term + term + term + term + term + term + term + term + term + term +
		term + term + term + term + term + term + term + term + term + term +
		term + term + term + term + term + term + term + term + term + term +
		term + term + term + term + term + term + term + term + term + term +
		term + term + term + term + term + term + term + term + term + term +
		term + term + term + term + term + term + term + term + term + term +
		term + term + term + term + term + term + term + term + term + term +
		term + term + term + term + term + term + term + term + term + term +
		term + term + term + term + term + term + term + term + term + term +
		term + term + term + term + term + term + term + term + term + term ;
	}
	millis = System.currentTimeMillis() - millis;
	System.out.println("Average float add     time = " +
			   (long)Math.ceil((double)(millis * 1000000L) / (100.0 * (double)MAXTEST)) +
			   " nsec");
    }

    public static void test_divide()
    {
	float result;
	float term = (1.0F + (float)(Math.random() * Math.pow(2.0,-20.0)));
	long millis;

	millis = System.currentTimeMillis();
	for (long i = 0; i < MAXTEST; ++i)
	{
	    result = 1.0F;
	    result /=
		term / term / term / term / term / term / term / term / term / term /
		term / term / term / term / term / term / term / term / term / term /
		term / term / term / term / term / term / term / term / term / term /
		term / term / term / term / term / term / term / term / term / term /
		term / term / term / term / term / term / term / term / term / term /
		term / term / term / term / term / term / term / term / term / term /
		term / term / term / term / term / term / term / term / term / term /
		term / term / term / term / term / term / term / term / term / term /
		term / term / term / term / term / term / term / term / term / term /
		term / term / term / term / term / term / term / term / term / term ;
	}
	millis = System.currentTimeMillis() - millis;
	System.out.println("Average float divide  time = " +
			   (long)Math.ceil((double)(millis * 1000000L) / (100.0 * (double)MAXTEST)) +
			   " nsec");
    }

    public static void test_multiply()
    {
	float result = 1.0F;
	float term = (1.0F + (float)Math.random());
	long millis;

	millis = System.currentTimeMillis();
	for (long i = 0; i < MAXTEST; ++i)
	{
	    result = 1.0F;
	    result *=
		term * term * term * term * term * term * term * term * term * term *
		term * term * term * term * term * term * term * term * term * term *
		term * term * term * term * term * term * term * term * term * term *
		term * term * term * term * term * term * term * term * term * term *
		term * term * term * term * term * term * term * term * term * term *
		term * term * term * term * term * term * term * term * term * term *
		term * term * term * term * term * term * term * term * term * term *
		term * term * term * term * term * term * term * term * term * term *
		term * term * term * term * term * term * term * term * term * term *
		term * term * term * term * term * term * term * term * term * term ;
	}
	millis = System.currentTimeMillis() - millis;
	System.out.println("Average float multiply time = " +
			   (long)Math.ceil((double)(millis * 1000000L) / (100.0 * (double)MAXTEST)) +
			   " nsec");
    }

    public static void test_power()
    {
	double a = (double)(1.0F + (float)Math.random());
	float r;
	long millis;
	long maxtest = MAXTEST / 100; // because tests show that Math.pow() is 60 to 180 times slower than multiply

	millis = System.currentTimeMillis();
	for (long i = 0; i < maxtest; ++i)
	{
	    r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);
	    r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);
	    r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);
	    r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);
	    r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);

	    r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);
	    r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);
	    r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);
	    r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);
	    r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);

	    r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);
	    r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);
	    r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);
	    r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);
	    r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);

	    r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);
	    r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);
	    r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);
	    r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);
	    r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);

	    r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);
	    r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);
	    r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);
	    r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);
	    r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);  r = (float)Math.pow(a,a);
	}
	millis = System.currentTimeMillis() - millis;
	System.out.println("Average float power   time = " +
			   (long)Math.ceil((double)(millis * 1000000L) / (100.0 * (double)maxtest)) +
			   " nsec");
    }

    public static void test_sqrt()
    {
	double a = (double)Float.MAX_VALUE * (float)Math.random();
	float r;
	long millis;
	long maxtest = MAXTEST / 10; // because tests show that Math.sqrt() is 10 to 25 times slower than multiply

	millis = System.currentTimeMillis();
	for (long i = 0; i < maxtest; ++i)
	{
	    r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);
	    r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);
	    r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);
	    r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);
	    r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);

	    r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);
	    r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);
	    r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);
	    r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);
	    r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);

	    r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);
	    r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);
	    r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);
	    r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);
	    r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);

	    r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);
	    r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);
	    r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);
	    r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);
	    r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);

	    r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);
	    r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);
	    r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);
	    r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);
	    r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);  r = (float)Math.sqrt(a);
	}
	millis = System.currentTimeMillis() - millis;
	System.out.println("Average float sqrt    time = " +
			   (long)Math.ceil((double)(millis * 1000000L) / (100.0 * (double)maxtest)) +
			   " nsec");
    }

    public static void main(String[] args)
    {
	test_add();
	test_divide();
	test_multiply();
	test_power();
	test_sqrt();
    }
}
