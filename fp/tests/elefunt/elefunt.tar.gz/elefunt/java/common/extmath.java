/* -*-java-*- extmath.java */

import java.lang.Math;

// Provide some more mathematical elementary functions a la C/C++/Fortran.
//
// This class provides everything that java.lang.Math provides, plus
// these extensions:
//
//	public static double toDegrees(double angrad)	[also in java.lang.Math in Java 1.2 and later]
//	public static double toRadians(double angdeg)	[also in java.lang.Math in Java 1.2 and later]
// 
//	public static boolean isNegativeZero(double x)
// 
//	public static double cotan(double x)
//	public static double cosh(double x)
//	public static double sinh(double x)
//	public static double log2(double x)
//	public static double log10(double x)
//	public static double tanh(double x)
//
// NB: We cannot use "extends java.lang.Math" because that is a final
// class!  Instead, we provide wrapper functions so that we can
// uniformly replace Math.foo by extmath.foo in Java code.

public final class extmath
{
    private static final double ZERO = 0.0e+00;
    private static final double HALF = 0.5e+00;
    private static final double ONE  = 1.0e+00;
    private static final double TWO  = 2.0e+00;

    // I extracted the public interface of java.lang.Math with
    //
    //		grep public java/lang/Math.java | sort -k4
    //
    // to put functions in name order (a la David Flanagan's ``Java in
    // a Nutshell'', O'Reilly (1996), ISBN 1-56592-183-6, p. 317), and
    // then edited that text into these declarations and function
    // definitions.

    // *******************************Base section******************************

    // Constants
    public static final double E				= Math.E;
    public static final double PI				= Math.PI;

    // Wrapped methods
    public static double IEEEremainder(double f1, double f2)	{ return (Math.IEEEremainder(f1,f2)); }
    public static double abs(double a)				{ return (Math.abs(a)); }
    public static float abs(float a)				{ return (Math.abs(a)); }
    public static int abs(int a)				{ return (Math.abs(a)); }
    public static long abs(long a)				{ return (Math.abs(a)); }
    public static double acos(double a)				{ return (Math.acos(a)); }
    public static double asin(double a)				{ return (Math.asin(a)); }
    public static double atan(double a)				{ return (Math.atan(a)); }
    public static double atan2(double y, double x)		{ return (Math.atan2(y,x)); }
    public static double ceil(double a)				{ return (Math.ceil(a)); }
    public static double cos(double a)				{ return (Math.cos(a)); }
    public static double exp(double a)				{ return (Math.exp(a)); }
    public static double floor(double a)			{ return (Math.floor(a)); }
    public static double log(double a)				{ return (Math.log(a)); }
    public static double max(double a, double b)		{ return (Math.max(a,b)); }
    public static float max(float a, float b)			{ return (Math.max(a,b)); }
    public static int max(int a, int b)				{ return (Math.max(a,b)); }
    public static long max(long a, long b)			{ return (Math.max(a,b)); }
    public static double min(double a, double b)		{ return (Math.min(a,b)); }
    public static float min(float a, float b)			{ return (Math.min(a,b)); }
    public static int min(int a, int b)				{ return (Math.min(a,b)); }
    public static long min(long a, long b)			{ return (Math.min(a,b)); }
    public static double pow(double a, double b)		{ return (Math.pow(a,b)); }
    public static double random()				{ return (Math.random()); }
    public static double rint(double a)				{ return (Math.rint(a)); }
    public static long round(double a)				{ return (Math.round(a)); }
    public static int round(float a)				{ return (Math.round(a)); }
    public static double sin(double a)				{ return (Math.sin(a)); }
    public static double sqrt(double a)				{ return (Math.sqrt(a)); }
    public static double tan(double a)				{ return (Math.tan(a)); }

    // These two functions are defined in Java 1.2, 1.3, and 1.4, but not in earlier Java versions, sigh...
    // public static double toDegrees(double angrad)		{ return (Math.toDegrees(angrad)); }
    // public static double toRadians(double angdeg)		{ return (Math.toRadians(angdeg)); }
    //
    // Therefore, provide our own private implementations:
    public static double toDegrees(double angrad)		{ return (angrad * 180.0 / PI); }
    public static double toRadians(double angdeg)		{ return (angdeg / 180.0 * PI); }

    // ****************************Extension section****************************

    // Extra public methods provided by class extmath:

    public static boolean isNegativeZero(double x)
    {
	return ((x == ZERO) && (ONE/x < ZERO));	// clean, but possibly slower than bit twiddling with Double.doubleToLongBits()!
    }

    // WARNING: These are relative simple implementations of cotan(),
    // cosh(), and sinh(): they will be filled out later.  Fancier
    // implementations could use the recipes in Cody & Waite's book,
    // ``Software Manual for the Elementary Functions'', Prentice-Hall
    // (1980), ISBN 0-13-822064-6.  See, e.g, the companion
    // ../doc/sqrt.pdf and ../doc/tanh.pdf file for documentation of
    // Fortran code for sqrt() and tanh() that implement Cody &
    // Waite's recipes.

    public static double cotan(double x)
    {
	// Cody & Waite's algorithm for tan() and cotan() computes a
	// numerator and a denominator, then returns either
	// numerator/denominator (for tan()), or denominator/numerator
	// (for cotan()), thereby avoiding the cost of an extra
	// division, plus the possible loss of an additional half bit
	// (rounding) or full bit (truncating) of accuracy.
	//
	// Without direct access to the native tan() internals, or
	// reimplementing that function ourselves, we cannot improve
	// upon using the reciprocal.
	//
	// In IEEE 754 arithmetic both 1/MAXNORMAL and 1/MINNORMAL are
	// representable.  However, 1/MINSUBNORMAL == Infinity, so
	// there are cases near odd powers of PI/2 for which tan()
	// returns Infinity, but cotan() should be finite nonzero, but
	// instead, will be incorrectly returned as zero by this
	// function.
	//
	// The runtime cost is that neither the internal division in
	// tan(), nor this one, are pipelineable.
	//
	// Timing tests (see optime_float.java and optime_double.java)
	// show that Java floating-point divides cost 3 to 10 times as
	// much as a multiply.
	//
	// The reciprocal works correctly for signed zero, NaN, and
	// Infinity, except for the subnormal value problem noted
	// above.
	return (ONE / Math.tan(x));
    }

    public static double cosh(double x)
    {
	// WARNING: The mathematical definition suffers premature
	// overflow for ex near Double.MAX_VALUE.
	// From Maple:
	//	Digits := 50:
	//	solve(cosh(x) = 1.7976931348623157e+308, x);
	//		710.47586007394394203710966283815873754380199144026
	//	solve(exp(x) + exp(-x) = 1.7976931348623157e+308, x);
	//		709.78271289338399672769243071670056097572649130590
	// Thus, we overflow for x in (709.782..., 710.475...) when the
	// result should be finite and representable!  We solve that by
	// using the half-argument formula:
	//	cosh(x) = 1 + 2*sinh(x/2)^2	(NB: 1 is negligible for large x)

	final double XOVERFLOW = 709.782712893e+00;
	x = Math.abs(x);	// to guarantee symmetry: cosh(x) = cosh(-x)
	if (x > XOVERFLOW)
	{
	    double s_half_x = sinh(HALF * x);

	    return (TWO * s_half_x * s_half_x); // omitted term "+ 1" is negligible to machine precision
	}
	else
	    return (cosh_simple(x));
    }

    public static double sinh(double x)
    {
	// Old simple code (very bad for small x!, and like cosh(), overflowing prematurely)
	//	double ex = Math.exp(x);
	//	return (HALF * (ex - ONE/ex));

	// From Maple:
	//	Digits := 50:
	//	solve(exp(x)-exp(-x) = 0.5, x);
	//		complex root, plus 0.24746646154726345294478154978835928925376690309857
	// For x at or below this value, the subtraction loses one or more bits, so we
	// switch to the Taylor's series, which converges rapidly:
	// From hoc:
	//	func t() {return ($1^(2*$2 + 1) / factorial(2*$2 + 1)) }
	//	x = 0.24746646154726345294478154978835928925376690309857
	//	for (k = 0; k < 10; ++k) println k, t(x,k)/t(x,0)
	//	0 1
	//	1 0.01020660826947071
	//	2 3.1252455709928382e-05
	//	3 4.5568796127174589e-08
	//	4 3.8758570948453761e-11
	//	5 2.1577830041201205e-14
	//	6 8.4706330206060679e-18
	//	7 2.4701838010219876e-21
	//	8 5.5615143552846207e-25
	//	9 9.9586312998996647e-29
	//	x = 0.001
	//	hoc> for (k = 0; k < 10; ++k) println k, t(x,k)/t(x,0)
	//	0 1
	//	1 1.6666666666666668e-07
	//	2 8.3333333333333336e-15
	//	3 1.9841269841269843e-22
	//	4 2.7557319223985897e-30
	//	5 2.5052108385441724e-38
	//	6 1.6059043836821618e-46
	//	7 7.6471637318198189e-55
	//	8 2.8114572543455212e-63
	//	9 8.2206352466243322e-72
	// Thus, for Java double (IEEE 754 64-bit), we never need more
	// than 7 terms, and often many fewer.  For Java float, at
	// most 4 terms are needed.

	final double XCUTOFF = 0.24746646154726345294478154978835928925376690309857e+00;

	// From Maple:
	//	Digits := 50:
	//	solve(sinh(x) = 1.7976931348623157e+308, x);
	//		710.47586007394394203710966283815873754380199144026
	//	solve(exp(x) - exp(-x) = 1.7976931348623157e+308, x);
	//		709.78271289338399672769243071670056097572649130590
	// Thus, we overflow for x in (709.782..., 710.475...) when the
	// result should be finite and representable!  We solve that by
	// using the half-argument formula:
	//	sinh(x) = 2*sinh(x/2)*cosh(x/2)

	final double XINFINITE = 710.47586007394394203710966283815873754380199144026e+00;
	final double XOVERFLOW = 709.782712893e+00;

	if (java.lang.Double.isNaN(x))
	    return (Double.NaN);
	else if (x == ZERO)	// special test to handle sinh(-0) = -0, sinh(+0) = +0
	    return (x);		// NB: preserves sign of zero!
	else if (x > XINFINITE)
	    return (Double.POSITIVE_INFINITY);
	else if (x < -XINFINITE)
	    return (Double.NEGATIVE_INFINITY);
	else
	{
	    // since sinh(-x) = -sinh(x), guarantee antisymmetry by
	    // computing sinh(xabs), then flipping the sign if needed
	    double xabs = Math.abs(x);
	    double result;

	    if (xabs > XOVERFLOW)
	    {
		double xhalf = xabs * HALF;
		result = (TWO * sinh(xhalf) * cosh(xhalf));
	    }
	    else if (xabs > XCUTOFF)
		result = (sinh_simple(xabs));
	    else
		result = (sinh_taylor(xabs));
	    return ((x < ZERO) ? -result : result);
	}
    }

    public static double log2(double x)
    {
	// 1.44... = 1/ln(2)
	return (1.4426950408889634073599246810018921374266459541530e+00 * Math.log(x));
    }

    public static double log10(double x)
    {
	//  0.434... = 1/ln(10)
	return (0.43429448190325182765112891891660508229439700580366e+00 * Math.log(x));
    }

    // We have four implementations of the hyperbolic tangent to
    // choose from: tanh_simple(), tanh_taylor(), tanh_direct(), and
    // tanh_cody_waite().  The first two have accuracy problems, and
    // handle Infinity, NaN, and negative zero incorrectly.  The
    // second also has a limited domain of convergence.  The third and
    // fourth are therefore the only practical candidates.  The third
    // requires only accurate sinh() and cosh().  The fourth is
    // independent of sinh() and cosh(), but needs approximation
    // polynomial coefficients.
    //
    // Here is an accuracy assessment from ELEFUNT ttanh() output,
    // with MAXTEST = 2,000,000 (instead of the default 2000). MRE and
    // RMS values are in units of bits lost.  Percent values record
    // "AGREED nnn TIMES" successes):
    //
    //	Interval		tanh_direct()			tanh_cody_waite()
    //	0.125,   0.5493		MRE 3.06   RMS 0.87  29.8%	MRE 1.87   RMS 0.00  55.9%
    //	0.6743, 19.4081		MRE 2.37   RMS 0.42  32.3%	MRE 2.27   RMS 0.00  46.2%
    //
    // We therefore select the Cody & Waite algorithm for extmath.tanh():

    public static double tanh(double x) { return (tanh_cody_waite(x)); }

    // Private test functions and alternate inferior implementations

    private static double cosh_simple(double x)
    {
	double ex = Math.exp(x);
	return (HALF * (ex + ONE/ex)); // WARNING: premature overflow (see cosh() discussion above)!
    }

    private static double cosh_taylor(double x)
    {
	// From Maple (the series is simple, but I'm feeling post-lunch lazy just now)
	//
	//	taylor(cosh(x), x = 0, 16);
	//	         2         4          6            8              10                12
	//	1 + 1/2 x  + 1/24 x  + 1/720 x  + 1/40320 x  + 1/3628800 x   + 1/479001600 x
	//
	//	                      14      16
	//	     + 1/87178291200 x   + O(x  )

	double sum, xsq;
	xsq = x * x;
	sum = 1e+00
	    + (1e+00/2e+00) * xsq
	    + (1e+00/24e+00) * xsq * xsq
	    + (1e+00/720e+00) * xsq * xsq * xsq
	    + (1e+00/40320e+00) * xsq * xsq * xsq * xsq
	    + (1e+00/3628800e+00) * xsq * xsq * xsq * xsq * xsq
	    + (1e+00/479001600e+00) * xsq * xsq * xsq * xsq * xsq * xsq
	    + (1e+00/87178291200e+00) * xsq * xsq * xsq * xsq * xsq * xsq * xsq;
	return (sum);
    }

    private static double sinh_simple(double x)
    {
	double ex = Math.exp(x);
	return (HALF * (ex - ONE/ex)); // WARNING: premature overflow (see cosh() discussion above)!
    }

    private static double sinh_taylor(double x)
    {
	double old_sum, sum, term, denom, xsq;
	int n;

	old_sum = ZERO;
	sum = term = x;
	xsq = x * x;
	n = 0;
	do
	{
	    n++;
	    denom = (double)((2*n + 1) * (2*n)); // short sequence, so never get integer overflow
	    term *= xsq/denom;
	    old_sum = sum;
	    sum += term;
	    // System.out.println("sinh_taylor(" + x + "): n = " + n + " sum = " + old_sum + " + " + term + " = " + sum);
	}
	while (old_sum != sum);
	return (sum);
    }

    private static double tanh_cody_waite(double x)
    {
	// This code was manually translated to Java from a Fortran
	// version developed for the Mathematics 119 course at the
	// University of Utah in 1991: see
	//
	//	http://www.math.utah.edu/~beebe/software/ieee/dtanh.f
	//	http://www.math.utah.edu/~beebe/software/ieee/tanh.f
	//	http://www.math.utah.edu/~beebe/software/ieee/tanh.pdf
	//
	// Implement the hyperbolic tangent using the Cody-Waite
	// algoritm.  The computation is divided into 4 regions:
	//
	// 0 <= x < XSMALL                 tanh(x) = x
	// XSMALL <= x < XMEDIUM           tanh(x) = rational polynomial
	// XMEDIUM <= x < XLARGE           tanh(x) = 1 - 2/(1 + exp(2x))
	// XLARGE <= x <= infinity         tanh(x) = 1
	// (07-Feb-1991)

	// In this implementation, t = 53, B = 2 (IEEE 754 double)
	//
	// XLARGE = (ln(2) + (t + 1)ln(B))/2
	//        = smallest value for which tanh(x) = 1
	final double XLARGE = 19.06154746539849600897e+00;

	// XMEDIUM = ln(3)/2
	//         = cutoff for second approximation
	final double XMEDIUM = 0.54930614433405484570e+00;

	// XSMALL = sqrt(3) * B**((-t-1)/2)
	//        = cutoff for third approximation
	final double XSMALL = 1.29047841397589243466e-08;

	double xabs, result;	// xabs was named f in the Fortran version
	double p[] =
	    {
		-0.16134119023996228053e+04,
		-0.99225929672236083313e+02,
		-0.96437492777225469787e+00
	    };
	double q[] =
	    {
		0.48402357071988688686e+04,
		0.22337720718962312926e+04,
		0.11274474380534949335e+03,
		1.00000000000000000000e+00
	    };

	xabs = Math.abs(x);
	if (Double.isNaN(xabs))
	    result = xabs + xabs;	// x is a NaN, so tanh is too--generate a run-time trap [uncatchable in Java]
	else if (xabs >= XLARGE)
	    result = ONE;
	else if (xabs >= XMEDIUM)
	{
	    // These two statements could be replaced by
	    //		result = ONE - TWO / (Math.exp(xabs + xabs) + ONE);
	    // since Java is guaranteed to have IEEE 754 arithmetic:
	    // no IBM S/360 wobbling precision worries!
	    result = HALF - ONE / (Math.exp(xabs + xabs) + ONE);
	    result = result + result;
	}
	else if (xabs >= XSMALL)
	{
	    double g, r;

	    g = xabs * xabs;
	    r = ((p[2] * g + p[1]) * g + p[0]) * g /
		(((g + q[2])*g + q[1]) * g + q[0]); // NB: q[3]*g reduced to g to avoid multiplication by 1
	    result = xabs + xabs * r;
	}
	else
	    result = xabs;

	if (x < ZERO)
	    result = -result;	// guarantee antisymmetry: tanh(-x) = -tanh(x)

	return (result);
    }

    private static double tanh_direct(double x)
    {
	// For generality, we consider two cases: rounding arithmetic
	// and truncating arithmetic.  Then tanh(x) is 1 to machine
	// precision if the (p+1)th base-beta digit is as large as
	// floor(0.5*(beta-1)) (rounding), or (beta-1) (truncating).
	// Cody & Waite (book, p. 239) solve this analytically for the
	// worst-case (truncating); see XLARGE in tanh_cody_waite()
	// below.  Their result agrees with ours here.  Because Java
	// arithmetic is guaranteed to round, we can use the larger
	// solution.
	//
	// From Maple:
	//	Digits := 50:
	//	p := 52:
	//	beta := 2:
	//	negeps := beta^(-p - 1):
	//	evalf(solve(tanh(x) = 1 - negeps*(beta-1)/beta, x));	# truncating arithmetic
	//		19.061547465398495995096095532285398634781366665556
	//	evalf(solve(tanh(x) = 1 - negeps*floor(0.5*(beta-1))/beta, x));	# rounding arithmetic
	// 		---no answer---
	//	evalf(solve(tanh(x) = 1 - negeps*      0.5*(beta-1) /beta, x));	# rounding arithmetic
	//		19.408121055678468656743605496921715440911560487347

	final double XCUTOFF = 19.408121055678468656743605496921715440911560487347e+00;

	if (java.lang.Double.isNaN(x))
	    return (Double.NaN);
	else if (x == ZERO)	// special test to handle tanh(-0) = -0, tanh(+0) = +0
	    return (x);		// NB: preserves sign of zero!
	else if (x < -XCUTOFF)
	    return (-1.0);
	else if (x > XCUTOFF)
	    return (1.0);
	else // safe and accurate now, albeit slower than a polynomial approximation
	    return (sinh(x)/cosh(x)); // NB: antisymmetry guaranteed by our implementations of cosh() and sinh()
    }

    private static double tanh_simple(double x)
    {
	double ex = Math.exp(x);
	double exinv = ONE/ex;
	return ((ex - exinv)/(ex + exinv));
    }

    private static double tanh_taylor(double x)
    {
	// From Maple (the coefficients involve Bernouilli numbers, which have no simple representation):
	//	taylor(tanh(x)/x, x = 0, 16);
	//
	//	         2         4   17   6    62   8    1382   10    21844   12    929569
	//	1 - 1/3 x  + 2/15 x  - --- x  + ---- x  - ------ x   + ------- x   - ---------
	//	                       315      2835      155925       6081075       638512875
	//
	//	     14      15
	//	    x   + O(x  )

	double sum, xsq;

	xsq = x * x;
	sum = x * (1e+00
		   - (1e+00/3e+00) * xsq
		   + (2e+00/15e+00) * xsq * xsq
		   - (17e+00/315e+00) * xsq * xsq * xsq
		   + (62e+00/2835e+00) * xsq * xsq * xsq * xsq
		   - (1382e+00/155925e+00) * xsq * xsq * xsq * xsq * xsq
		   + (21844e+00/6081075e+00) * xsq * xsq * xsq * xsq * xsq * xsq
		   - (929569e+00/638512875e+00) * xsq * xsq * xsq * xsq * xsq * xsq * xsq
		   );
	return (sum);
    }

    private static void test_cosh(double x)
    {
	double accurate = cosh(x);
	double simple = cosh_simple(x);

	System.out.println("TEST:        cosh(" + x + ") = " + accurate);
	System.out.print  ("TEST: cosh_simple(" + x + ") = " + simple);
	test_print_relerr(accurate, simple);

	if (Math.abs(x) < ONE)	// test Taylor series when it converges rapidly
	{
	    double taylor = cosh_taylor(x);

	    System.out.print  ("TEST: cosh_taylor(" + x + ") = " + taylor);
	    test_print_relerr(accurate, taylor);
	}

	System.out.println("");
    }

    private static void test_cosh_all()
    {
	test_cosh_twice(Double.NaN);
	test_cosh_twice(Double.POSITIVE_INFINITY);
	test_cosh_twice(Double.MAX_VALUE);
	test_cosh_twice(709.782e+00); 		// before overflow cutoff
	test_cosh_twice(709.782712892e+00);	// before overflow cutoff
	test_cosh_twice(709.782712893e+00);	// before overflow cutoff (see XOVERFLOW in cosh() above)
	test_cosh_twice(709.78271289338399672769243071670056097572649130590e+00); // at overflow cutoff
	test_cosh_twice(709.782712894e+00);	// after overflow cutoff
	test_cosh_twice(709.782712895e+00);	// after overflow cutoff
	test_cosh_twice(709.783e+00);		// above overflow cutoff
	test_cosh_twice(709.8e+00);
	test_cosh_twice(709.9e+00);
	test_cosh_twice(710.0e+00);
	test_cosh_twice(710.1e+00);
	test_cosh_twice(710.2e+00);
	test_cosh_twice(710.3e+00);
	test_cosh_twice(710.4e+00);
	test_cosh_twice(710.4758600739e+00);     // below overflow limit
	test_cosh_twice(710.47586007394394203710966283815873754380199144026e+00); // at overflow limit
	test_cosh_twice(710.4758600740e+00);     // above overflow limit
	test_cosh_twice(710.5e+00);
	test_cosh_twice(0.25e+00);
	test_cosh_twice(0.247466461547262e+00); // below sinh() Taylor limit (sinh_simple() loses 1 or more bits)
	test_cosh_twice(0.247466461547263e+00); // at sinh() Taylor limit (sinh_simple() loses 1 bit)
	test_cosh_twice(0.247466461547264e+00); // above sinh() Taylor limit (sinh_simple() okay)
	test_cosh_twice(1.0e-01);
	test_cosh_twice(1.0e-02);
	test_cosh_twice(1.0e-03);
	test_cosh_twice(1.0e-04);
	test_cosh_twice(1.0e-05);
	test_cosh_twice(1.0e-06);
	test_cosh_twice(1.0e-12);
	test_cosh_twice(machar.eps);
	test_cosh_twice(machar.epsneg);
	test_cosh_twice(1.0e-24);
	test_cosh_twice(1.0e-36);
	test_cosh_twice(1.0e-72);
	test_cosh_twice(1.0e-144);
	test_cosh_twice(1.0e-288);
	test_cosh_twice(Math.pow(2.0,-1022.0)); // smallest normalized
	test_cosh_twice(Double.MIN_VALUE);	// smallest subnormal
	test_cosh_twice(0.0e+00);
    }

    private static void test_cosh_twice(double x)
    {
	test_cosh(x);
	test_cosh(-x);
    }

    private static void test_print_relerr(double accurate, double simple)
    {
	if (Double.isNaN(accurate) || Double.isInfinite(accurate) || (accurate == ZERO))
	    System.out.println("");
	else
	{
	    double relerr;
	    long ulps;

	    relerr = (accurate - simple) / accurate;
	    ulps = Math.round(Math.ceil(Math.abs(relerr / machar.eps)));
	    System.out.println(" relerr = " + relerr + " [" + ulps + " ulps]" +
			       ((ulps < 8L) ? "" : " !!WARNING!!") +
			       ((Double.isNaN(relerr) || Double.isInfinite(relerr)) ? " !!DISASTER!! " : ""));
	}
    }

    private static void test_sinh(double x)
    {
	double accurate = sinh(x);
	double simple = sinh_simple(x);

	System.out.println("TEST:        sinh(" + x + ") = " + accurate);
	System.out.print  ("TEST: sinh_simple(" + x + ") = " + simple);
	test_print_relerr(accurate, simple);

	if (Math.abs(x) < ONE)	// test Taylor series when it converges rapidly
	{
	    double taylor = sinh_taylor(x);

	    System.out.print  ("TEST: sinh_taylor(" + x + ") = " + taylor);
	    test_print_relerr(accurate, taylor);
	}

	System.out.println("");
    }

    private static void test_sinh_all()
    {
	test_sinh_twice(Double.NaN);
	test_sinh_twice(Double.POSITIVE_INFINITY);
	test_sinh_twice(Double.MAX_VALUE);
	test_sinh_twice(709.782e+00);		// before overflow cutoff
	test_sinh_twice(709.782712892e+00);	// before overflow cutoff
	test_sinh_twice(709.782712893e+00);	// before overflow cutoff (see XOVERFLOW in cosh() above)
	test_sinh_twice(709.78271289338399672769243071670056097572649130590e+00); // at overflow cutoff
	test_sinh_twice(709.782712894e+00);	// after overflow cutoff
	test_sinh_twice(709.782712895e+00);	// after overflow cutoff
	test_sinh_twice(709.783e+00);		// above overflow cutoff
	test_sinh_twice(709.8e+00);
	test_sinh_twice(709.9e+00);
	test_sinh_twice(710.0e+00);
	test_sinh_twice(710.1e+00);
	test_sinh_twice(710.2e+00);
	test_sinh_twice(710.3e+00);
	test_sinh_twice(710.4e+00);
	test_sinh_twice(710.4758600739e+00); // below overflow limit
	test_sinh_twice(710.47586007394394203710966283815873754380199144026e+00); // at overflow limit
	test_sinh_twice(710.4758600740e+00); // above overflow limit
	test_sinh_twice(0.25e+00);
	test_sinh_twice(0.247466461547262e+00); // below Taylor limit (sinh_simple() loses 1 or more bits)
	test_sinh_twice(0.247466461547263e+00); // at Taylor limit (sinh_simple() loses 1 bit)
	test_sinh_twice(0.247466461547264e+00); // above Taylor limit (sinh_simple() okay)
	test_sinh_twice(1.0e-01);
	test_sinh_twice(1.0e-02);
	test_sinh_twice(1.0e-03);
	test_sinh_twice(1.0e-04);
	test_sinh_twice(1.0e-05);
	test_sinh_twice(1.0e-06);
	test_sinh_twice(1.0e-12);
	test_sinh_twice(machar.eps);
	test_sinh_twice(machar.epsneg);
	test_sinh_twice(1.0e-24);
	test_sinh_twice(1.0e-36);
	test_sinh_twice(1.0e-72);
	test_sinh_twice(1.0e-144);
	test_sinh_twice(1.0e-288);
	test_sinh_twice(Math.pow(2.0,-1022.0)); // smallest normalized
	test_sinh_twice(Double.MIN_VALUE);	// smallest subnormal
	test_sinh_twice(0.0e+00);
    }

    private static void test_sinh_twice(double x)
    {
	test_sinh(x);
	test_sinh(-x);
    }

    private static void test_tanh(double x)
    {
	double accurate = tanh(x);
	double simple = tanh_simple(x);
	double cody_waite = tanh_cody_waite(x);

	System.out.println("TEST:            tanh(" + x + ") = " + accurate);
	System.out.print  ("TEST: tanh_cody_waite(" + x + ") = " + cody_waite);
	test_print_relerr(accurate, cody_waite);
	System.out.print  ("TEST:     tanh_simple(" + x + ") = " + simple);
	test_print_relerr(accurate, simple);

	if (Math.abs(x) < ONE)	// test Taylor series when it converges rapidly
	{
	    double taylor = tanh_taylor(x);

	    System.out.print  ("TEST:     tanh_taylor(" + x + ") = " + taylor);
	    test_print_relerr(accurate, taylor);
	}

	System.out.println("");
    }

    private static void test_tanh_all()
    {
	test_tanh_twice(Double.NaN);
	test_tanh_twice(Double.POSITIVE_INFINITY);
	test_tanh_twice(Double.MAX_VALUE);
	test_tanh_twice(709.782e+00);		// before overflow cutoff
	test_tanh_twice(709.782712892e+00);	// before overflow cutoff
	test_tanh_twice(709.782712893e+00);	// before overflow cutoff (see XOVERFLOW in cosh() above)
	test_tanh_twice(709.78271289338399672769243071670056097572649130590e+00); // at overflow cutoff
	test_tanh_twice(709.782712894e+00);	// after overflow cutoff
	test_tanh_twice(709.782712895e+00);	// after overflow cutoff
	test_tanh_twice(709.783e+00);		// above overflow cutoff
	test_tanh_twice(709.8e+00);
	test_tanh_twice(709.9e+00);
	test_tanh_twice(710.0e+00);
	test_tanh_twice(710.1e+00);
	test_tanh_twice(710.2e+00);
	test_tanh_twice(710.3e+00);
	test_tanh_twice(710.4e+00);
	test_tanh_twice(710.4758600739e+00); // below overflow limit
	test_tanh_twice(710.47586007394394203710966283815873754380199144026e+00); // at overflow limit
	test_tanh_twice(710.4758600740e+00); // above overflow limit
	test_tanh_twice(0.25e+00);
	test_tanh_twice(0.247466461547262e+00); // below sinh() Taylor limit (sinh_simple() loses 1 or more bits)
	test_tanh_twice(0.247466461547263e+00); // at sinh() Taylor limit (sinh_simple() loses 1 bit)
	test_tanh_twice(0.247466461547264e+00); // above sinh() Taylor limit (sinh_simple() okay)
	test_tanh_twice(1.0e-01);
	test_tanh_twice(1.0e-02);
	test_tanh_twice(1.0e-03);
	test_tanh_twice(1.0e-04);
	test_tanh_twice(1.0e-05);
	test_tanh_twice(1.0e-06);
	test_tanh_twice(1.0e-12);
	test_tanh_twice(machar.eps);
	test_tanh_twice(machar.epsneg);
	test_tanh_twice(1.0e-24);
	test_tanh_twice(1.0e-36);
	test_tanh_twice(1.0e-72);
	test_tanh_twice(1.0e-144);
	test_tanh_twice(1.0e-288);
	test_tanh_twice(Math.pow(2.0,-1022.0)); // smallest normalized
	test_tanh_twice(Double.MIN_VALUE);	// smallest subnormal
	test_tanh_twice(0.0e+00);
    }

    private static void test_tanh_twice(double x)
    {
	test_tanh(x);
	test_tanh(-x);
    }

    public static void main(String[] args)
    {
	test_cosh_all();
	test_sinh_all();
	test_tanh_all();
    }
}
