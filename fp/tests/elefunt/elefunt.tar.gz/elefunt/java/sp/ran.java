import java.lang.Math;
import java.text.*;

class ran
{
    private static final long DEFAULT_INITIAL_SEED = ranbase.INITIALSEED;
    private static long iy = DEFAULT_INITIAL_SEED;
    private static long LONG_MAX = Integer.MAX_VALUE;

    public static long ranset(long seed)
    {
	long old_seed;

	old_seed = iy;
	if (seed < 0)
	    seed = -seed;
	if (seed < 0)			/* then had seed = LONG_MIN  */
	    seed = LONG_MAX;
	iy = (seed == 0) ? DEFAULT_INITIAL_SEED : seed;

	/* Guard against bad DEFAULT_INITIAL_SEED */
	if (iy < 0)
	    iy = -iy;
	if (iy < 0)
	    iy = LONG_MAX;

	/* Ensure that (iy * 125) is positive (i.e., does not overflow) */
	if (iy > (LONG_MAX / 125))		/* see below for magic constant 125 */
	    iy = (LONG_MAX / 125);

	return (old_seed);
    }

    public static float ran()
    {
	float result;

	iy = iy * 125;
	iy = iy - (iy / 2796203L) * 2796203L;
	result = ((float) (iy)) / 2796203.0e+00F;

	return (result);
    }

    public static void main(String[] args)
    {
	final int N = 100;
	int ntoken;

	ranset(initseed.initseed());
	System.out.println(N + " uniformly-distributed random numbers on (0,1)");
	ntoken = 0;
	for (int k = 0; k < N; ++k)
	{
	    if (ntoken == 10)
	    {
		System.out.println("");
		ntoken = 0;
	    }
	    System.out.print(fmt.F(ran(),8,4));
	    ntoken++;
	}
	System.out.println("");
    }
}
