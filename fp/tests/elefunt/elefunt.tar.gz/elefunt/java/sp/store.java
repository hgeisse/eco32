/* -*-java-*- store.java */

public class store
{
    public static float store(float value)
    {
	return (value);
    }
}
