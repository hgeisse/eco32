/* -*-java-*- tpower.java */

import java.io.*;

public class tpower
{
    // shorthands to avoid the need for fully-qualified names, sigh...
    private static float ABS(float x)			{ return (elefunt.ABS(x)); }
    private static float ALOG(float x)			{ return (elefunt.ALOG(x)); }
    private static float AMAX1(float x,float y)		{ return (elefunt.AMAX1(x,y)); }
    private static float EXP(float x)			{ return (elefunt.EXP(x)); }
    private static float POW(float x,float y)		{ return (elefunt.POW(x,y)); }
    private static float RAN()				{ return (elefunt.RAN()); }
    private static float SQRT(float x)			{ return (elefunt.SQRT(x)); }
    private static float STORE(float x)			{ return (elefunt.STORE(x)); }
    private static float TO_FP_T(long n)		{ return (elefunt.TO_FP_T(n)); }

    public static void tpower()
    {
	/*#     program to test power function (**)
	#
	#     data required
	#
	#        none
	#
	#     subprograms required from this package
	#
	#        machar - an environmental inquiry program providing
	#                 information on the floating-point arithmetic
	#                 system.  note that the call to machar can
	#                 be deleted provided the following six
	#                 parameters are assigned the values indicated
	#
	#                 ibeta  - the radix of the floating-point system
	#                 it     - the number of base-ibeta digits in the
	#                          significand of a floating-point number
	#                 minexp - the largest in magnitude negative
	#                          integer such that  float(ibeta)**minexp
	#                          is a positive floating-point number
	#                 maxexp - the largest positive integer exponent
	#                          for a finite floating-point number
	#                 xmin   - the smallest non-vanishing floating-point
	#                          power of the radix
	#                 xmax   - the largest finite floating-point
	#                          number
	#
	#        ran(k) - a function subprogram returning random real
	#                 numbers uniformly distributed over (0,1)
	#
	#
	#     standard fortran subprograms required
	#
	#         abs, alog, amax1, exp, float, sqrt
	#
	#
	#     latest revision - december 6, 1979
	#
	#     author - w. j. cody
	#              argonne national laboratory
	#
	#**********************************************************************/

	final float ait = TO_FP_T(machar.it);
	final float alxmax = ALOG(machar.xmax);
	final float beta = TO_FP_T(machar.ibeta);
	final float albeta = ALOG(beta);
	final float ONE = elefunt.ONE;
	final float TWO = elefunt.TWO;
	final float ZERO = elefunt.ZERO;

	int i,
	    j,
	    k1,
	    k2,
	    k3,
	    n;

	float
	    a,
	    b,
	    c,
	    del,
	    dely,
	    onep5,
	    r6,
	    r7,
	    scale,
	    w,
	    x,
	    xl,
	    xn,
	    xsq,
	    x1,
	    y,
	    y1,
	    y2,
	    z,
	    zz;

	/*******************************************************************/

	elefunt.banner("tpower");

	ran.ranset(initseed.initseed());

	onep5 = (TWO + ONE) / TWO;
	scale = ONE;
	j = (machar.it + 1) / 2;
	for (i = 1; i <= j; i++)	/* do i = 1, j */
	    scale = scale * beta;
	a = ONE / beta;
	b = ONE;
	c = -AMAX1(alxmax, -ALOG(machar.xmin)) / ALOG(100e0F);
	dely = -c - c;
	n = (int)maxtest.maxtest();
	w = ZERO;
	xn = TO_FP_T(n);
	y = ZERO;
	y1 = ZERO;
	zz = ZERO;

	/* random argument accuracy tests */

	for (j = 1; j <= 4; j++)
	{				/* do j = 1, 4 */
	    k1 = 0;
	    k3 = 0;
	    x1 = ZERO;
	    r6 = ZERO;
	    r7 = ZERO;
	    del = (b - a) / xn;
	    xl = a;

	    for (i = 1; i <= n; i++)
	    {			/* DO I = 1, N */
		x = del * RAN() + xl;
		if (j == 1)
		{
		    zz = POW(x, ONE);	/* zz=x**ONE */
		    z = x;
		}
		else
		{
		    w *= scale;
		    w = STORE(w);
		    x += w;
		    x = STORE(x);
		    x -= w;
		    x = STORE(x);
		    xsq = x * x;
		    if (j != 4)
		    {
			zz = POW(xsq, onep5);	/* zz = xsq ** onep5; */
			z = x * xsq;
		    }
		    else
		    {
			y = dely * RAN() + c;
			y2 = (y / TWO + y) - y;
			y = y2 + y2;
			z = POW(x, y);	/* z=x ** y; */
			zz = POW(xsq, y2);	/* zz=xsq ** y2; */
		    }
		}
		w = ONE;
		if (z != ZERO)	/* */
		    w = (z - zz) / z;
		if (w > ZERO)
		    k1 = k1 + 1;
		if (w <= ZERO)
		    k3 = k3 + 1;
		w = ABS(w);
		if (w > r6)
		{
		    r6 = w;
		    x1 = x;
		    if (j == 4)
			y1 = y;
		}
		r7 = r7 + w * w;
		xl = a + TO_FP_T(i) * del;	/* OLD: xl = xl + del (bad for large n) */
	    }

	    k2 = n - k3 - k1;
	    r7 = SQRT(r7 / xn);
	    if (j == 1)
	    {
		System.out.print("1TEST OF X**1.0 VS X\n\n\n");
		System.out.print(fmt.I(n,7) + " RANDOM ARGUMENTS WERE TESTED FROM THE INTERVAL\n");
		System.out.print("      (" + fmt.E(a,15,4) + "," + fmt.E(b,15,4) + ")\n\n\n");
		System.out.print(" X**1.0 WAS LARGER" + fmt.I(k1,6) + " TIMES,\n");
		System.out.print("            AGREED" + fmt.I(k2,6) + " TIMES, AND\n");
		System.out.print("       WAS SMALLER" + fmt.I(k3,6) + " TIMES.\n\n\n");
	    }
	    else if (j != 4)
	    {
		System.out.print("1TEST OF XSQ**1.5 VS XSQ*X\n\n\n");
		System.out.print(fmt.I(n,7) + " RANDOM ARGUMENTS WERE TESTED FROM THE INTERVAL\n");
		System.out.print("      (" + fmt.E(a,15,4) + "," + fmt.E(b,15,4) + ")\n\n\n");
		System.out.print(" X**1.5 WAS LARGER" + fmt.I(k1,6) + " TIMES,\n");
		System.out.print("            AGREED" + fmt.I(k2,6) + " TIMES, AND\n");
		System.out.print("       WAS SMALLER" + fmt.I(k3,6) + " TIMES.\n\n\n");
	    }
	    else
	    {
		System.out.print("1TEST OF X**Y VS XSQ**(Y/2)\n\n\n");
		w = c + dely;
		System.out.print(" " + fmt.I(n,6) + " RANDOM ARGUMENTS WERE TESTED FROM THE REGION\n");
		System.out.print("      X IN (" + fmt.E(a,15,4) + "," + fmt.E(b,15,4) +
				 "), Y IN (" + fmt.E(c,15,4) + "," + fmt.E(w,15,4) + ")\n\n\n");
		System.out.print(" X**Y  WAS LARGER" + fmt.I(k1,6) + " TIMES,\n");
		System.out.print("           AGREED" + fmt.I(k2,6) + " TIMES, AND\n");
		System.out.print("      WAS SMALLER" + fmt.I(k3,6) + " TIMES.\n\n\n");
	    }
	    System.out.print(" THERE ARE " + fmt.I(machar.it,4) + " BASE " + fmt.I(machar.ibeta,4) +
			     " SIGNIFICANT DIGITS IN A FLOATING-POINT NUMBER\n\n\n");
	    w = -999.0e0F;
	    if (r6 != ZERO)
		w = ALOG(ABS(r6)) / albeta;
	    if (j != 4)
	    {
		System.out.print(" THE MAXIMUM RELATIVE ERROR OF " + fmt.E(r6,15,4) +
				 " = " + fmt.I(machar.ibeta,4) + " ** " + fmt.F(w,7,2) + "\n");
		System.out.print("    OCCURRED FOR X =" + fmt.E(x1,17,6) + "\n");
	    }
	    if (j == 4)
	    {
		System.out.print(" THE MAXIMUM RELATIVE ERROR OF " + fmt.E(r6,15,4) +
				 " = " + fmt.I(machar.ibeta,4) + " ** " + fmt.F(w,7,2) + "\n");
		System.out.print("    OCCURRED FOR X =" + fmt.E(x1,17,6) + " Y =" + fmt.E(y1,17,6) + "\n");
	    }
	    w = AMAX1(ait + w, ZERO);
	    System.out.print(" THE ESTIMATED LOSS OF BASE" + fmt.I(machar.ibeta,4) +
			     " SIGNIFICANT DIGITS IS" + fmt.F(w,7,2) + "\n\n\n");
	    w = -999.0e0F;
	    if (r7 != ZERO)
		w = ALOG(ABS(r7)) / albeta;
	    System.out.print(" THE ROOT MEAN SQUARE RELATIVE ERROR WAS " + fmt.E(r7,15,4) + " = " +
			     fmt.I(machar.ibeta,4) + " **" + fmt.F(w,7,2) + "\n");
	    w = AMAX1(ait + w, ZERO);
	    System.out.print(" THE ESTIMATED LOSS OF BASE" + fmt.I(machar.ibeta,4) +
			     " SIGNIFICANT DIGITS IS" + fmt.F(w,7,2) + "\n\n\n");
	    if (j != 1)
	    {
		b = 10.0e0F;
		a = 0.01e0F;
		if (j != 3)
		{
		    a = ONE;
		    b = EXP(alxmax / 3.0e0F);
		}
	    }
	}

	/* special tests */

	System.out.print("1SPECIAL TESTS\n\n\n");
	System.out.print(" THE IDENTITY  X ** Y = (1/X) ** (-Y)  WILL BE TESTED.\n\n");
	System.out.print("        X              Y         (X**Y-(1/X)**(-Y)) / X**Y\n\n");
	b = 10.0e0F;

	for (i = 1; i <= 5; i++)
	{				/* DO I = 1, 5 	 */
	    x = RAN() * b + ONE;
	    y = RAN() * b + ONE;
	    z = POW(x, y);		/* z=x ** y */
	    zz = POW((ONE / x), -y);/* zz=(ONE/x) ** (-y) */
	    w = (z - zz) / z;
	    System.out.print(fmt.E(x,15,7) + fmt.E(y,15,7) + "      " + fmt.E(z,15,7) + "\n\n");
	}

	/* test of error returns */

	System.out.print("1TEST OF ERROR RETURNS\n\n\n");
	x = beta;
	y = TO_FP_T(machar.minexp);
	System.out.print(" (" + fmt.E(x,14,7) + ") ** (" + fmt.E(y,14,7) + ") WILL BE COMPUTED.\n");
	System.out.print(" THIS SHOULD NOT TRIGGER AN ERROR MESSAGE\n\n\n");
	try
	{
	    z = POW(x, y);		/* Z = X ** Y */
	}
	catch (ArithmeticException e)
	{
	    z = elefunt.errout("ERROR: POW(" + x + "," + y + ") raised " + e);
	}
	System.out.print(" THE VALUE RETURNED IS " + fmt.E(z,15,4) + "\n\n\n\n");

	y = TO_FP_T(machar.maxexp - 1);
	System.out.print(" (" + fmt.E(x,14,7) + ") ** (" + fmt.E(y,14,7) + ") WILL BE COMPUTED.\n");
	System.out.print(" THIS SHOULD NOT TRIGGER AN ERROR MESSAGE\n\n\n");
	try
	{
	    z = POW(x, y);		/* Z = X ** Y */
	}
	catch (ArithmeticException e)
	{
	    z = elefunt.errout("ERROR: POW(" + x + "," + y + ") raised " + e);
	}
	System.out.print(" THE VALUE RETURNED IS " + fmt.E(z,15,4) + "\n\n\n\n");

	x = ZERO;
	y = TWO;
	System.out.print(" (" + fmt.E(x,14,7) + ") ** (" + fmt.E(y,14,7) + ") WILL BE COMPUTED.\n");
	System.out.print(" THIS SHOULD NOT TRIGGER AN ERROR MESSAGE\n\n\n");
	try
	{
	    z = POW(x, y);		/* Z = X ** Y */
	}
	catch (ArithmeticException e)
	{
	    z = elefunt.errout("ERROR: POW(" + x + "," + y + ") raised " + e);
	}
	System.out.print(" THE VALUE RETURNED IS " + fmt.E(z,15,4) + "\n\n\n\n");

	x = -y;
	y = ZERO;
	System.out.print(" (" + fmt.E(x,14,7) + ") ** (" + fmt.E(y,14,7) + ") WILL BE COMPUTED.\n");
	System.out.print(" THIS SHOULD TRIGGER AN ERROR MESSAGE\n\n\n");
	try
	{
	    z = POW(x, y);		/* Z = X ** Y */
	}
	catch (ArithmeticException e)
	{
	    z = elefunt.errout("ERROR: POW(" + x + "," + y + ") raised " + e);
	}
	System.out.print(" THE VALUE RETURNED IS " + fmt.E(z,15,4) + "\n\n\n\n");

	y = TWO;
	System.out.print(" (" + fmt.E(x,14,7) + ") ** (" + fmt.E(y,14,7) + ") WILL BE COMPUTED.\n");
	System.out.print(" THIS SHOULD TRIGGER AN ERROR MESSAGE\n\n\n");
	try
	{
	    z = POW(x, y);		/* Z = X ** Y */
	}
	catch (ArithmeticException e)
	{
	    z = elefunt.errout("ERROR: POW(" + x + "," + y + ") raised " + e);
	}
	System.out.print(" THE VALUE RETURNED IS " + fmt.E(z,15,4) + "\n\n\n\n");

	x = ZERO;
	y = ZERO;
	System.out.print(" (" + fmt.E(x,14,7) + ") ** (" + fmt.E(y,14,7) + ") WILL BE COMPUTED.\n");
	System.out.print(" THIS SHOULD TRIGGER AN ERROR MESSAGE\n\n\n");
	try
	{
	    z = POW(x, y);		/* Z = X ** Y */
	}
	catch (ArithmeticException e)
	{
	    z = elefunt.errout("ERROR: POW(" + x + "," + y + ") raised " + e);
	}
	System.out.print(" THE VALUE RETURNED IS " + fmt.E(z,15,4) + "\n\n\n\n");
	System.out.print(" THIS CONCLUDES THE TESTS\n");
    }

    public static void main(String[] args)
    {
	tpower();
    }
}
