/* -*-java-*- randl.java */

import java.lang.Math;

/***********************************************************************

Returns pseudo  random numbers  logarithmically distributed  over
(1,exp(x)).  Thus a*randl(ln(b/a)) is logarithmically distributed
in (a,b).

Other subroutines required:

	exp(x) - The exponential routine.

	ran() - A function program returning random real
		numbers uniformly distributed over (0,1).

***********************************************************************/

public class randl
{
    public static float randl(float x)
    {
	return ((float)Math.exp(x * ran.ran()));
    }

    public static void main(String[] args)
    {
	final float A = 1.0F;
	final float B = 10240.0F;
	final float RANDL_ARG = (float)Math.log(B/A);
	final int N = 100;
	int ntoken;

	ran.ranset(initseed.initseed());
	System.out.println(N + " logarithmically-distributed random numbers on (" +
			   (int)A + "," + (int)B + ")");
	ntoken = 0;
	for (int k = 0; k < N; ++k)
	{
	    if (ntoken == 6)
	    {
		System.out.println("");
		ntoken = 0;
	    }
	    System.out.print(fmt.E(randl(RANDL_ARG),12,4));
	    ntoken++;
	}
	System.out.println("");
    }
}
