/* -*-java-*- ipow.java */

import java.lang.Math;

public class ipow
{
    public static float ipow(float x, int n)
    {
	float value;
	int k;

	value = 1.0F;
	for (k = 1; k <= Math.abs(n); ++k)
	    value *= x;
	if (n < 0)
	    value = 1.0F / value;
	return (value);
    }
}
