/* -*-java-*- tsinh.java */

import java.io.*;

public class tsinh
{
    // shorthands to avoid the need for fully-qualified names, sigh...
    private static float ABS(float x)			{ return (elefunt.ABS(x)); }
    private static float ALOG(float x)			{ return (elefunt.ALOG(x)); }
    private static float AMAX1(float x,float y)		{ return (elefunt.AMAX1(x,y)); }
    private static float COSH(float x)			{ return (elefunt.COSH(x)); }
    private static float IPOW(float x, int n)		{ return (elefunt.IPOW(x,n)); }
    private static float POW(float x,float y)		{ return (elefunt.POW(x,y)); }
    private static float RAN()				{ return (elefunt.RAN()); }
    private static float SINH(float x)			{ return (elefunt.SINH(x)); }
    private static float SQRT(float x)			{ return (elefunt.SQRT(x)); }
    private static float TO_FP_T(long n)		{ return (elefunt.TO_FP_T(n)); }

    private static int INT(float x)			{ return (elefunt.INT(x)); }

    public static void tsinh()
    {
	/*#     program to test sinh/cosh
	#
	#     data required
	#
	#        none
	#
	#     subprograms required from this package
	#
	#        machar - an environmental inquiry program providing
	#                 information on the floating-point arithmetic
	#                 system.  note that the call to machar can
	#                 be deleted provided the following six
	#                 parameters are assigned the values indicated
	#
	#                 ibeta  - the radix of the floating-point system
	#                 it     - the number of base-ibeta digits in the
	#                          significand of a floating-point number
	#                 irnd   - 0 if floating-point addition chops,
	#                          1 if floating-point addition rounds
	#                 minexp - the largest in magnitude negative
	#                          integer such that float(ibeta)**minexp
	#                          is a positive floating-point number
	#                 eps    - the smallest positive floating-point
	#                          number such that 1.0+eps != 1.0
	#                 xmax   - the largest finite floating-point no.
	#
	#        ran(k) - a function subprogram returning random real
	#                 numbers uniformly distributed over (0,1)
	#
	#
	#     standard fortran subprograms required
	#
	#         abs, alog, amax1, cosh, float, int, sinh, sqrt
	#
	#
	#     latest revision - december 6, 1979
	#
	#     author - w. j. cody
	#              argonne national laboratory
	#
	#*/

	final float ait = TO_FP_T(machar.it);
	final float alxmax = ALOG(machar.xmax);
	final float beta = TO_FP_T(machar.ibeta);
	final float albeta = ALOG(beta);
	final float ONE = elefunt.ONE;
	final float TWO = elefunt.TWO;
	final float ZERO = elefunt.ZERO;

	int i,
	    ii,
	    i2,
	    j,
	    k1,
	    k2,
	    k3,
	    n,
	    nit;

	float
	    a,
	    aind,
	    b,
	    betap,
	    c,
	    c0,
	    del,
	    den,
	    five,
	    r6,
	    r7,
	    three,
	    w,
	    x,
	    xl,
	    xn,
	    x1,
	    xsq,
	    y,
	    z,
	    zz;

	/*******************************************************************/

	elefunt.banner("tsinh");

	ran.ranset(initseed.initseed());

	three = 3.0e0F;
	five = 5.0e0F;
	c0 = five / 16.0e0F + 1.152713683194269979e-2F;
	a = ZERO;
	b = 0.5e0F;
	c = (ait + ONE) * 0.35e0F;
	if (machar.ibeta == 10)
	    c = c * three;
	n = (int)maxtest.maxtest();
	xn = TO_FP_T(n);
	i2 = 2;
	nit = 2 - (INT(ALOG(machar.eps) * three)) / 20;
	aind = TO_FP_T(nit + nit + 1);
	w = ZERO;

	/* random argument accuracy tests */

	for (j = 1; j <= 4; ++j)
	{
	    if (j == 2)
	    {
		aind = aind - ONE;
		i2 = 1;
	    }
	    k1 = 0;
	    k3 = 0;
	    x1 = ZERO;
	    r6 = ZERO;
	    r7 = ZERO;
	    del = (b - a) / xn;
	    xl = a;

	    for (i = 1; i <= n; ++i)
	    {
		x = del * RAN() + xl;
		if (j > 2)
		{
		    y = x;
		    x = y - ONE;
		    w = x - ONE;
		    if (j == 4)
		    {
			z = COSH(x);
			zz = (COSH(y) + COSH(w)) * c0;
		    }
		    else
		    {
			z = SINH(x);
			zz = (SINH(y) + SINH(w)) * c0;
		    }
		}
		else
		{
		    xsq = x * x;
		    zz = ONE;
		    den = aind;

		    for (ii = i2; ii <= nit; ++ii)
		    {
			w = zz * xsq / (den * (den - ONE));
			zz = w + ONE;
			den = den - 2.0e0F;
		    }

		    if (j == 2)
		    {
			z = COSH(x);
			if (machar.irnd == 0)
			{
			    w = (ONE - zz) + w;
			    zz = zz + (w + w);
			}
		    }
		    else
		    {
			w = x * xsq * zz / 6.0e0F;
			zz = x + w;
			z = SINH(x);
			if (machar.irnd == 0)
			{
			    w = (x - zz) + w;
			    zz = zz + (w + w);
			}
		    }
		}
		w = ONE;
		if (z != ZERO)
		    w = (z - zz) / z;
		if (w > ZERO)
		    k1 = k1 + 1;
		if (w < ZERO)
		    k3 = k3 + 1;
		w = ABS(w);
		if (w > r6)
		{
		    r6 = w;
		    x1 = x;
		}
		r7 = r7 + w * w;
		xl = a + TO_FP_T(i) * del;	/* OLD: xl = xl + del (bad for large n) */
	    }

	    k2 = n - k3 - k1;
	    r7 = SQRT(r7 / xn);
	    i = (j / 2) * 2;
	    if (j == 1)
		System.out.print("1TEST OF SINH(X) VS T.S. EXPANSION OF SINH(X)\n\n");
	    else if (j == 2)
		System.out.print("1TEST OF COSH(X) VS T.S. EXPANSION OF COSH(X)\n\n");
	    else if (j == 3)
		System.out.print("1TEST OF SINH(X) VS C*(SINH(X+1)+SINH(X-1))\n\n");
	    else if (j == 4)
		System.out.print("1TEST OF COSH(X) VS C*(COSH(X+1)+COSH(X-1))\n\n");
	    System.out.print(fmt.I(n,7) + " RANDOM ARGUMENTS WERE TESTED FROM THE INTERVAL\n");
	    System.out.print("      (" + fmt.E(a,15,4) + "," + fmt.E(b,15,4) + ")\n\n\n");
	    if (i != j)
	    {
		System.out.print(" SINH(X) WAS LARGER" + fmt.I(k1,6) + " TIMES,\n");
		System.out.print("             AGREED" + fmt.I(k2,6) + " TIMES, AND\n");
		System.out.print("        WAS SMALLER" + fmt.I(k3,6) + " TIMES.\n\n\n");
	    }
	    else
	    {
		System.out.print(" COSH(X) WAS LARGER" + fmt.I(k1,6) + " TIMES,\n");
		System.out.print("             AGREED" + fmt.I(k2,6) + " TIMES, AND\n");
		System.out.print("        WAS SMALLER" + fmt.I(k3,6) + " TIMES.\n\n\n");
	    }
	    System.out.print(" THERE ARE" + fmt.I(machar.it,4) + " BASE" + fmt.I(machar.ibeta,4) +
			     " SIGNIFICANT DIGITS IN A FLOATING-POINT NUMBER\n\n\n");
	    w = -999.0e0F;
	    if (r6 != ZERO)
		w = ALOG(ABS(r6)) / albeta;
	    System.out.print(" THE MAXIMUM RELATIVE ERROR OF" + fmt.E(r6,15,4) +
			     " = " + fmt.I(machar.ibeta,4) + " **" + fmt.F(w,7,2) + "\n");
	    System.out.print("    OCCURRED FOR X =" + fmt.E(x1,17,6) + "\n");
	    w = AMAX1(ait + w, ZERO);
	    System.out.print(" THE ESTIMATED LOSS OF BASE" + fmt.I(machar.ibeta,4) +
			     " SIGNIFICANT DIGITS IS" + fmt.F(w,7,2) + "\n\n\n");
	    w = -999.0e0F;
	    if (r7 != ZERO)
		w = ALOG(ABS(r7)) / albeta;	/* */
	    System.out.print(" THE ROOT MEAN SQUARE RELATIVE ERROR WAS" + fmt.E(r7,15,4) +
			     " = " + fmt.I(machar.ibeta,4) + " **" + fmt.F(w,7,2) + "\n");
	    w = AMAX1(ait + w, ZERO);
	    System.out.print(" THE ESTIMATED LOSS OF BASE" + fmt.I(machar.ibeta,4) +
			     " SIGNIFICANT DIGITS IS" + fmt.F(w,7,2) + "\n\n\n");
	    if (j == 2)
	    {
		b = alxmax;
		a = three;
	    }
	}

	/* special tests */

	System.out.print("1SPECIAL TESTS\n\n");
	System.out.print(" THE IDENTITY  SINH(-X) = -SINH(X)  WILL BE TESTED.\n\n");
	System.out.print("        X            F(X) + F(-X)\n\n");

	for (i = 1; i <= 5; ++i)
	{
	    x = RAN() * a;
	    z = SINH(x) + SINH(-x);
	    System.out.print(fmt.E(x,15,7) + fmt.E(z,15,7) + "\n\n");
	}

	System.out.print(" THE IDENTITY SINH(X) = X , X SMALL, WILL BE TESTED.\n\n");
	System.out.print("        X         X - F(X)\n\n");
	betap = IPOW(beta, machar.it);
	x = RAN() / betap;

	for (i = 1; i <= 5; ++i)
	{
	    z = x - SINH(x);
	    System.out.print(fmt.E(x,15,7) + fmt.E(z,15,7) + "\n\n");
	    x = x / beta;
	}

	System.out.print(" THE IDENTITY  COSH(-X) = COSH(X)  WILL BE TESTED.\n\n");
	System.out.print("        X         F(X) - F(-X)\n\n");

	for (i = 1; i <= 5; ++i)
	{
	    x = RAN() * a;
	    z = COSH(x) - COSH(-x);
	    System.out.print(fmt.E(x,15,7) + fmt.E(z,15,7) + "\n\n");
	}

	System.out.print(" TEST OF UNDERFLOW FOR VERY SMALL ARGUMENT.\n\n");
	x = POW(beta, TO_FP_T(machar.minexp) * 0.75e0F);
	y = SINH(x);
	System.out.print("      SINH(" + fmt.E(x,13,6) + ") =" + fmt.E(y,13,6) + "\n\n");

	/* test of error returns */

	System.out.print("1TEST OF ERROR RETURNS\n\n\n");

	x = alxmax + 0.125e0F;
	System.out.print(" SINH WILL BE CALLED WITH THE ARGUMENT" + fmt.E(x,15,4) + "\n");
	System.out.print(" THIS SHOULD NOT TRIGGER AN ERROR MESSAGE\n\n\n");
	try
	{
	    y = SINH(x);
	}
	catch (ArithmeticException e)
	{
	    y = elefunt.errout("ERROR: SINH(" + x + ") raised " + e);
	}
	System.out.print(" SINH RETURNED THE VALUE" + fmt.E(y,15,4) + "\n\n\n");

	x = betap;
	System.out.print("\nSINH WILL BE CALLED WITH THE ARGUMENT" + fmt.E(x,15,4) + "\n");
	System.out.print(" THIS SHOULD TRIGGER AN ERROR MESSAGE\n\n\n");
	try
	{
	    y = SINH(x);
	}
	catch (ArithmeticException e)
	{
	    y = elefunt.errout("ERROR: SINH(" + x + ") raised " + e);
	}
	System.out.print(" SINH RETURNED THE VALUE" + fmt.E(y,15,4) + "\n\n\n\n");

	System.out.print(" THIS CONCLUDES THE TESTS\n\n");
    }

    public static void main(String[] args)
    {
	tsinh();
    }
}
