/* -*-java-*- texp.java */

import java.io.*;

public class texp
{
    // shorthands to avoid the need for fully-qualified names, sigh...
    private static float ABS(float x)			{ return (elefunt.ABS(x)); }
    private static float AINT(float x)			{ return (elefunt.AINT(x)); }
    private static float ALOG(float x)			{ return (elefunt.ALOG(x)); }
    private static float AMAX1(float x,float y)		{ return (elefunt.AMAX1(x,y)); }
    private static float EXP(float x)			{ return (elefunt.EXP(x)); }
    private static float IPOW(float x, int n)		{ return (elefunt.IPOW(x,n)); }
    private static float RAN()				{ return (elefunt.RAN()); }
    private static float SQRT(float x)			{ return (elefunt.SQRT(x)); }
    private static float TO_FP_T(long n)		{ return (elefunt.TO_FP_T(n)); }

    public static void texp()
    {
	/***********************************************************************
	#     program to test exp
	#
	#     data required
	#
	#        none
	#
	#     subprograms required from this package
	#
	#        machar - an environmental inquiry program providing
	#                 information on the floating-point arithmetic
	#                 system.  note that the call to machar can
	#                 be deleted provided the following four
	#                 parameters are assigned the values indicated
	#
	#                 ibeta - the radix of the floating-point system
	#                 it    - the number of base-ibeta digits in the
	#                         significand of a floating-point number
	#                 xmin  - the smallest non-vanishing floating-point
	#                         power of the radix
	#                 xmax  - the largest finite floating-point no.
	#
	#        ran(k) - a function subprogram returning random real
	#                 numbers uniformly distributed over (0,1)
	#
	#
	#     standard fortran subprograms required
	#
	#         abs, aint, alog, AMAX1, exp, float, sqrt
	#
	#
	#     latest revision - december 6, 1979
	#
	#     author - w. j. cody
	#              argonne national laboratory
	#
	#
	***********************************************************************/

	final float ait = TO_FP_T(machar.it);
	final float beta = TO_FP_T(machar.ibeta);
	final float albeta = ALOG(beta);
	final float eight = 8.0e0F;
	final float half = 0.5e0F;
	final float tenth = 0.1e0F;
	final float ONE = elefunt.ONE;
	final float TEN = elefunt.TEN;
	final float TWO = elefunt.TWO;
	final float ZERO = elefunt.ZERO;

	int i,
	    j,
	    k1,
	    k2,
	    k3,
	    n;

	float
	    a,
	    b,
	    d,
	    del,
	    r6,
	    r7,
	    v,
	    w,
	    x,
	    xl,
	    xn,
	    x1,
	    y,
	    z,
	    zz;

	/*******************************************************************/

	elefunt.banner("texp");

	ran.ranset(initseed.initseed());

	v = 0.0625e0F;
	a = TWO;
	b = ALOG(a) * 0.5e0F;
	a = -b + v;
	d = ALOG(0.9e0F * machar.xmax);
	n = (int)maxtest.maxtest();
	xn = TO_FP_T(n);

	/* random argument accuracy tests */
	for (j = 1; j <= 3; ++j)
	{
	    k1 = 0;
	    k3 = 0;
	    x1 = ZERO;
	    r6 = ZERO;
	    r7 = ZERO;
	    del = (b - a) / xn;
	    xl = a;

	    for (i = 1; i <= n; ++i)
	    {
		x = del * RAN() + xl;

		/* purify arguments */
		y = x - v;
		if (y < ZERO)
		    x = y + v;
		z = EXP(x);
		zz = EXP(y);
		if (j == 1)
		    z = z - z * 6.058693718652421388e-2F;
		else
		{
		    if (machar.ibeta != 10)
			z = z * 0.0625e0F - z * 2.4453321046920570389e-3F;
		    else
			z = z * 6.0e-2F + z * 5.466789530794296106e-5F;
		}
		w = ONE;
		if (zz != ZERO)
		    w = (z - zz) / zz;
		if (w < ZERO)
		    k1 = k1 + 1;
		if (w > ZERO)
		    k3 = k3 + 1;
		w = ABS(w);
		if (w > r6)
		{
		    r6 = w;
		    x1 = x;
		}
		r7 = r7 + w * w;
		xl = a + TO_FP_T(i) * del;	/* OLD: xl = xl + del (bad for large n) */
	    }

	    k2 = n - k3 - k1;
	    r7 = SQRT(r7 / xn);

	    System.out.print("1TEST OF EXP(X-" + fmt.F(v,7,4) + ") VS EXP(X)/EXP(" + fmt.F(v,7,4) + ")\n\n\n");
	    System.out.print(fmt.I(n,7) + " RANDOM ARGUMENTS WERE TESTED FROM THE INTERVAL\n");
	    System.out.print("      (" + fmt.E(a,15,4) + "," + fmt.E(b,15,4) + ")\n\n\n");
	    System.out.print(" EXP(X-V) WAS LARGER" + fmt.I(k1,6) + " TIMES,\n");
	    System.out.print("              AGREED" + fmt.I(k2,6) + " TIMES, AND\n");
	    System.out.print("         WAS SMALLER" + fmt.I(k3,6) + " TIMES.\n\n\n");
	    System.out.print(" THERE ARE " + fmt.I(machar.it,4) + " BASE " +
			     fmt.I(machar.ibeta,4) + " SIGNIFICANT DIGITS IN A FLOATING-POINT NUMBER\n\n\n");
	    w = -999.0e0F;
	    if (r6 != ZERO)
		w = ALOG(ABS(r6)) / albeta;
	    System.out.print(" THE MAXIMUM RELATIVE ERROR OF" + fmt.E(r6,15,4) +
			     " = " + fmt.I(machar.ibeta,4) + " **" + fmt.F(w,7,2) + "\n");
	    System.out.print("    OCCURRED FOR X =" + fmt.E(x1,17,6) + "\n");
	    w = AMAX1(ait + w, ZERO);
	    System.out.print(" THE ESTIMATED LOSS OF BASE" + fmt.I(machar.ibeta,4) +
			     " SIGNIFICANT DIGITS IS" + fmt.F(w,7,2) + "\n\n\n");
	    w = -999.0e0F;
	    if (r7 != ZERO)
		w = ALOG(ABS(r7)) / albeta;
	    System.out.print(" THE ROOT MEAN SQUARE RELATIVE ERROR WAS" + fmt.E(r7,15,4) +
			     " = " + fmt.I(machar.ibeta,4) + " **" + fmt.F(w,7,2) + "\n");
	    w = AMAX1(ait + w, ZERO);
	    System.out.print(" THE ESTIMATED LOSS OF BASE" + fmt.I(machar.ibeta,4) +
			     " SIGNIFICANT DIGITS IS" + fmt.F(w,7,2) + "\n\n\n");
	    if (j == 2)
	    {
		a = -TWO * a;
		b = TEN * a;
		if (b < d)
		    b = d;
	    }
	    else
	    {
		v = 45.0e0F / 16.0e0F;
		a = -TEN * b;
		b = 4.0e0F * machar.xmin * IPOW(beta, machar.it);
		b = ALOG(b);
	    }
	}

	/* special tests */
	System.out.print("1SPECIAL TESTS\n\n\n");
	System.out.print(" THE IDENTITY EXP(X)*EXP(-X) = 1.0  WILL BE TESTED.\n\n");
	System.out.print("       X        F(X)*F(-X) - 1\n\n");

	for (i = 1; i <= 5; ++i)
	{
	    x = RAN() * beta;
	    y = -x;
	    z = EXP(x) * EXP(y) - ONE;
	    System.out.print(fmt.E(x,15,7) + fmt.E(z,15,7) + "\n\n");
	}

	System.out.print("\n\n TEST OF SPECIAL ARGUMENTS\n\n\n");
	x = ZERO;
	y = EXP(x) - ONE;
	System.out.print(" EXP(0.0) - 1.0E0F = " + fmt.E(y,15,7) + "\n\n");
	x = AINT(ALOG(machar.xmin));
	y = EXP(x);
	System.out.print(" EXP(" + fmt.E(x,13,6) + ") =" + fmt.E(y,13,6) + "\n\n");
	x = AINT(ALOG(machar.xmax));
	y = EXP(x);
	System.out.print(" EXP(" + fmt.E(x,13,6) + ") =" + fmt.E(y,13,6) + "\n\n");
	x = x / TWO;
	v = x / TWO;
	y = EXP(x);
	z = EXP(v);
	z = z * z;
	System.out.print(" IF EXP(" + fmt.E(x,13,6) + ") = " + fmt.E(y,13,6) + " IS NOT ABOUT\n");
	System.out.print(" EXP(" + fmt.E(v,13,6) + ")**2 =" + fmt.E(z,13,6) + " THERE IS AN ARG RED ERROR\n");

	/* test of error returns */

	System.out.print("1TEST OF ERROR RETURNS\n\n\n");
	x = -ONE / SQRT(machar.xmin);
	System.out.print(" EXP WILL BE CALLED WITH THE ARGUMENT" + fmt.E(x,15,4) + "\n");
	System.out.print(" THIS SHOULD TRIGGER AN ERROR MESSAGE\n\n\n");
	try
	{
	    y = EXP(x);
	}
	catch (ArithmeticException e)
	{
	    y = elefunt.errout("ERROR: EXP(" + x + ") raised " + e);
	}
	System.out.print(" EXP RETURNED THE VALUE" + fmt.E(y,15,4) + "\n\n\n\n");

	x = -x;
	System.out.print(" EXP WILL BE CALLED WITH THE ARGUMENT" + fmt.E(x,15,4) + "\n");
	System.out.print(" THIS SHOULD TRIGGER AN ERROR MESSAGE\n\n\n");
	try
	{
	    y = EXP(x);
	}
	catch (ArithmeticException e)
	{
	    y = elefunt.errout("ERROR: EXP(" + x + ") raised " + e);
	}
	System.out.print(" EXP RETURNED THE VALUE" + fmt.E(y,15,4) + "\n\n\n\n");
	System.out.print(" THIS CONCLUDES THE TESTS\n");
    }

    public static void main(String[] args)
    {
	texp();
    }
}
