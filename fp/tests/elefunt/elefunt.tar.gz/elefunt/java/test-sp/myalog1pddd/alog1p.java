import java.lang.Math;

public class alog1p
{
    final private static double CUTLO = -0.5;	/* CUTLO = -1/beta, for arbitrary base beta */
    final private static double CUTHI = 0.5;	/* CUTHI = 1/beta, for arbitrary base beta */

    final private static double ONE = 1.0;
    final private static double ZERO = 0.0;

    final private static float LOG10E = 0.43429448190325182765112891891660508229439700580366F;

    public static float alog1p(float x)
    {
	/*
	 * (log1p)
	 * Return alog(1 + x), taking care to avoid subtraction loss.
	 *
	 * This version does internal computations in double precision.
	 *
	 * (17-Jun-2002)
	 */

	return ((float)dlog1p((double)x));
    }

    private static double dlog1p(double x)
    {
	/* (dlog1p) */
	/* Return dlog(1 + x), taking care to avoid subtraction loss. */
	/* (17-Jun-2002) */

	/* System generated locals */
	double ret_val;

	/* Local variables */
	double sum,
	    term,
	    xn,
	    xtons;

	/*
	 *     We handle the computation in three regions:
	 *
	 *     x in [-Infinity, CUTLO):  log(1+x)
	 *     x in [CUTLO, CUTHI]:      Taylor series
	 *     x in (CUTHI, Infinity]:   log(1+x)
	 *
	 *     The central region suffers loss of ONE or more bits if the
	 *     simple formula is used.
	 *
	 *     We also handle the cases of log1p(NaN) and log1p(0) specially,
	 *     so as to preserve NaNs, and the sign of ZERO.
	 */
	if (x != x)
	    ret_val = x;
	else if (x == ZERO)
	    ret_val = x;
	else if (x < CUTLO)
	    ret_val = (float)Math.log(ONE + x);
	else if (x <= CUTHI)
	{
	    term = x;
	    sum = ZERO;
	    xn = ONE;
	    xtons = x;
	    while ((sum + term) != sum)
	    {
		sum += term;
		xn += ONE;
		xtons = -xtons * x;
		term = xtons / xn;
	    }
	    ret_val = sum;
	}
	else
	    ret_val = (float)Math.log(ONE + x);

	return (ret_val);
    }


    public static float al1p10(float x)
    {
	/* (log1p10) */
	/* Return alog10(1 + x), taking care to avoid subtraction loss. */
	/* (17-Jun-2002) */

	return (alog1p(x) * LOG10E);
    }
}
