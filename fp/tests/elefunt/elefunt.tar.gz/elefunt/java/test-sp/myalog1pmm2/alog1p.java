import java.lang.Math;

public class alog1p
{
    final private static float CUTLO = -0.5F;	/* CUTLO = -1/beta, for arbitrary base beta */
    final private static float CUTHI = 0.5F;	/* CUTHI = 1/beta, for arbitrary base beta */
    final private static float ONE = 1.0F;
    final private static float ZERO = 0.0F;
    final private static float LOG10E = 0.43429448190325182765112891891660508229439700580366F;

    public static float alog1p(float x)
    {
	/*
	 * (log1p)
	 * Return alog(1 + x), taking care to avoid subtraction loss.
	 *
	 * This version uses a [3,3]-degree rational minimax polynomial
	 * computed in Maple by
	 *
	 *     with(numapprox):
	 *     Digits := 50:
	 *     minimax((ln(1+x)-x)/x^2, x = -0.5..0.5, [3,3], 1, 'err');
	 *     printf("%0.2Fe\n", err);
	 *
	 * The reported absolute error is 1.20e-09, below the IEEE 754
	 * machine epsilon of 2**(-23) = 1.19e-07  This is the lowest
	 * degree, and thus optimal, minimax polynomial whose error is below
	 * that limit.
	 * (24-Jun-2002)
	 */

	/* System generated locals */
	float ret_val;

	/*
	 * We handle the computation in three regions:
	 *
	 * x in [-Infinity, -0.5):  log(1+x)
	 * x in [-0.5, 0.5]:        minimax rational polynomials in 8 blocks
	 * x in (0.5, Infinity]:    log(1+x)
	 *
	 * The central region suffers loss of ONE or more bits if the
	 * simple formula is used.
	 *
	 * We also handle the cases of log1p(NaN) and log1p(0) specially,
	 * so as to preserve NaNs, and the sign of ZERO.
	 */

	if (x != x)
	    ret_val = x;
	else if (x == ZERO)
	    ret_val = x;
	else if (x < CUTLO)
	    ret_val = (float)Math.log((double)(ONE + x));
	else if (x <= CUTHI)
	{
	    ret_val = x +
		(x * x *
		 (
		  ( -4.36853891e-01F +
		    ( -5.55650140e-01F +
		      ( -1.59005713e-01F +
			( -1.08045674e-03F
			  ) * x) * x) * x)
		  /
		  (  8.73707794e-01F +
		     (  1.69377203e+00F +
			(  1.01033764e+00F +
			   (  1.78318685e-01F
			      ) * x) * x) * x) ) );
	}
	else
	    ret_val = (float)Math.log((double)(ONE + x));

	return (ret_val);
    }


    public static float al1p10(float x)
    {
	/* (log1p10) */
	/* Return alog10(1 + x), taking care to avoid subtraction loss. */
	/* (17-Jun-2002) */

	return (alog1p(x) * LOG10E);
    }
}
