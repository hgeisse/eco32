import java.lang.Math;

public class expm1
{
    private static float EXP(float x) {return ((float)Math.exp(x)); }

    /*
     *
     * CUTLO = ln(0.5) (really, ln(1-1/beta) for arbitrary base beta)
     *
     */
    final private static float CUTLO = -0.6931471805599453094172321214581765680755001343603F;

    /*
     *
     * CUTHI = ln(1.5) (really, ln(1+1/beta) for arbitrary base beta)
     *
     */
    final private static float CUTHI = 0.4054651081081643819780131154643491365719904234625F;

    final private static float ONE = 1.0F;
    final private static float ZERO = 0.0F;

    public static float expm1f(float x)
    {
	/*
	 * (expm1)
	 * Return (exp(x) - 1), taking care to avoid subtraction loss.
	 *
	 * This version uses a [1,5]-degree Pad� approximation computed in
	 * Maple by
	 *
	 *     with(numapprox):
	 *     Digits := 20:
	 *     pade((exp('x') - 1 - 'x')/'x'^2, 'x' = (ln(1/2)+ln(3/2))/2, [1,5]);
	 *
	 * The coefficients in this approximation are exactly representable.
	 * The computed relative error is 2.34e-08, below the IEEE 754
	 * machine epsilon of 2**(-23) = 1.19e-07.  This is the lowest
	 * degree, and thus optimal, Pad� approximation whose error is below
	 * that limit.
	 * (29-Jun-2002)
	 */

	float ret_val;

	/*
	 *
	 *     We handle the computation in three regions:
	 *
	 *     x in [-Infinity, CUTLO):  exp(x) - 1
	 *     x in [CUTLO, CUTHI]:      Pad� approximation
	 *     x in (CUTHI, Infinity]:   exp(x) - 1
	 *
	 *     The central region suffers loss of one or more bits if the
	 *     simple formula is used.
	 *
	 *     The following IF statements handle the case of NaN, signed zero,
	 *     and the three regions above.
	 *
	 */

	if (x != x)				/* then x is a NaN */
	    ret_val = x;
	else if (x == ZERO)			/* then x is +0 or -0 */
	    ret_val = x;			/* preserve sign of zero */
	else if (x < CUTLO)
	    ret_val = EXP(x) - ONE;
	else if (x <= CUTHI)		/* region of accuracy loss from exp(x)-1 */
	    ret_val =  x + 
		(x * x * (
			  ( -4.76864369e-01F )
			  /
			  ( -9.53728738e-01F +
			    (  3.17909579e-01F +
			       ( -2.64924692e-02F +
				 ( -1.76620182e-03F +
				   (  1.46998263e-04F +
				      (  3.46118080e-05F
					 ) * x) * x) * x) * x) * x) ) );
	else
	    ret_val = EXP(x) - ONE;

	return (ret_val);
    }
}
