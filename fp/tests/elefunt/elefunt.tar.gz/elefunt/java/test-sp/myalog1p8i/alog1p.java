import java.lang.Math;

public class alog1p
{
    final private static float CUTLO = -0.5F;	/* CUTLO = -1/beta, for arbitrary base beta */
    final private static float CUTHI = 0.5F;	/* CUTHI = 1/beta, for arbitrary base beta */

    final private static float ONE = 1.0F;
    final private static float ZERO = 0.0F;

    final private static float LOG10E = 0.43429448190325182765112891891660508229439700580366F;

    public static float alog1p(float x)
    {
	/*
	 * (log1p)
	 * Return alog(1 + x), taking care to avoid subtraction loss.
	 *
	 * This version uses minimax rational polynomials computed by Maple,
	 * e.g.,
	 *
	 *     with(numapprox):
	 *     Digits := 35:
	 *     minimax(log(1+x)/x, x = -0.5 .. -0.375, [2,2], 1, 'err');
	 *     printf("%0.2e\n", err):
	 *
	 * on 8 subintervals, chosen to have accuracy adequate for IEEE 754
	 * and VAX 32-bit arithmetic.
	 * (25-Jun-2002)
	 */

	/* System generated locals */
	float ret_val;

	/*
	 * We handle the computation in three regions:
	 *
	 * x in [-Infinity, -0.5):  log(1+x)
	 * x in [-0.5, 0.5]:        minimax rational polynomials in 8 blocks
	 * x in (0.5, Infinity]:    log(1+x)
	 *
	 * The central region suffers loss of ONE or more bits if the
	 * simple formula is used.
	 *
	 * We also handle the cases of log1p(NaN) and log1p(0) specially,
	 * so as to preserve NaNs, and the sign of ZERO.
	 */

	if (x != x)
	    ret_val = x;
	else if (x == ZERO)
	    ret_val = x;
	else if (x < -0.5F)
	    ret_val = (float)Math.log((double)(ONE + x));
	else if (x <= -0.375F)
	{				/* Error = 2.33e-09F */
	    ret_val = x *
		( (2.0736809495170730569526488072009611F +
		   (1.8074981540767447649971483610324688F +
		    0.15652476189895140399279843662755363F * x) * x) /
		  (2.0734588989563504345624703324023525F +
		   (2.8420950499755572854232165106870135F +
		    0.87897308008963039837187563842309652F * x) * x) );
	}
	else if (x <= -0.25F)
	{				/* Error = 5.74e-08F */
	    ret_val = x *
		( (1.4746534962808867968093553547516276F +
		   0.88448230566266954369275385126995949F * x) /
		  (1.4748112585424901821814921394271614F +
		   (1.6236853656071691949535451706453173F +
		    0.32718223771357054736555395914792412F * x) * x) );
	}
	else if (x <= -0.125F)
	{				/* Error = 2.71e-08F */
	    ret_val = x *
		( (1.2357131357382299902461782387182508F +
		   0.68708088029093348394608680435774906F * x) /
		  (1.2357248949825236518184645728330858F +
		   (1.3051889681657165816778917610303364F +
		    0.24247340593982537421177619833538793F * x) * x) );
	}
	else if (x <= 0.0)
	{				/* Error = 1.43e-08F */
	    ret_val =  x *
		( (1.0667661286203383437571039039285692F +
		   0.55244609971880183399930139728961283F * x) /
		  (1.0667661438284791826242325107357420F +
		   (1.0858327708284892089817975860353228F +
		    0.18746100877677106127015908547679758F * x) * x) );
	}
	else if (x <= 0.125F)
	{				/* Error = 8.11e-09F */
	    ret_val = x *
		( (0.94121756541660035694204188352844201F +
		   0.45588735903651176366090289165588144F * x) /
		  (0.94121757304588981064668045300480278F +
		   (0.92649404977401920962504720212091401F +
		    0.14959766924526741363269919789057705F * x) * x) );
	}
	else if (x <= 0.25F)
	{				/* Error = 4.90e-09F */
	    ret_val = x *
		( (0.84432884002116162624703175033288772F +
		   0.38392969153520705923590142660778150F * x) /
		  (0.84433240161647717793705279243111788F +
		   (0.80600965533917018067971882580766014F +
		    0.12236228735807092373557699988064569F * x) * x) );
	}
	else if (x <= 0.375F)
	{				/* Error = 3.11e-09F */
	    ret_val = x *
		( (0.76730866518998691725895923891413971F +
		   0.32865832520209022084183755285071336F * x) /
		  (0.76733068406296199932506051878478341F +
		   (0.71200363629751288434657889681106415F +
		    0.10208054808159597745326256651805156F * x) * x) );
	}
	else if (x <= 0.5F)
	{				/* Error = 2.06e-09F */
	    ret_val = x *
		( (0.70460450455917704266914770297991494F +
		   0.28515096330679809329680289760735998F * x) /
		  (0.70466985626426048549413388847823773F +
		   (0.63678903226789881509779816408981123F +
		    0.86548387522114109546430912555803740e-1F * x) * x) );
	}
	else
	    ret_val = (float)Math.log((double)(ONE + x));

	return (ret_val);
    }


    public static float al1p10(float x)
    {
	/* (log1p10) */
	/* Return alog10(1 + x), taking care to avoid subtraction loss. */
	/* (17-Jun-2002) */

	return (alog1p(x) * LOG10E);
    }
}
