import java.lang.Math;

public class expm1
{
    final private static double ONE = 1.0D;

    public static float expm1f(float x)
    {				// TO DO: replace with more accurate algorithm
	return ((float)(Math.exp((double)x) - ONE));
    }
}
