import java.lang.Math;

public class expm1
{
    private static float EXP(float x) {return ((float)Math.exp(x)); }

    final private static float ONE = 1.0F;
    final private static float ZERO = 0.0F;

    public static float expm1f(float x)
    {
	/*
	 * (expm1)
	 * Return (exp(x) - 1), taking care to avoid subtraction loss.
	 *
	 * This version uses minimax rational polynomials computed by Maple,
	 * e.g.,
	 *
	 *     with(numapprox):
	 *     Digits := 20:
	 *     minimax((exp(x)-1-x)/x^2, x = -0.5 .. -0.25, [2,2], 1, 'err');
	 *     printf("%.2e\n", err):
	 *
	 * on 5 subintervals, chosen to have accuracy adequate for IEEE 754
	 * and VAX 32-bit arithmetic.
	 * (28-Jun-2002)
	 */

	float ret_val;

	/*
	 * We handle the computation in three regions:
	 *
	 * x in [-Infinity, -0.75):  exp(x) - 1
	 * x in [-0.75, 0.50):       minimax rational polynomials in 5 blocks
	 * x in [0.50, Infinity]:    exp(x) - 1
	 *
	 * The central region suffers loss of one or more bits if the
	 * simple formula is used.
	 *
	 * The following IF statements handle the case of NaN, signed zero,
	 * and the three regions above.
	 */

	if (x != x)			/* then x is a NaN */
	    ret_val = x;
	else if (x == ZERO)		/* then x is +0 or -0 */
	    ret_val = x;		/* preserve sign of zero */
	else if (x < -0.75F)
	    ret_val = EXP(x) - ONE;
	else if (x < -0.50F)	/* [-0.75,-0.50) Error = 1.42e-11 */
	    ret_val = x + (x * x *
		(
		 (  4.04382035e-01F +
		    ( -8.21183611e-03F +
		      (  1.67522215e-03F
			 ) * x) * x)
		 /
		 (  8.08765766e-01F +
		    ( -2.85997735e-01F +
		      (  3.13365322e-02F
			 ) * x) * x) ) );
	else if (x < -0.25F)	/* [-0.50,-0.25) Error = 1.79e-11 */
	    ret_val = x + (x * x *
		(
		 (  4.40557596e-01F +
		    ( -5.30346777e-03F +
		      (  2.05099129e-03F
			 ) * x) * x)
		 /
		 (  8.81115328e-01F +
		    ( -3.04310057e-01F +
		      (  3.21239583e-02F
			 ) * x) * x) ) );
	else if (x < 0.0F)		/* [-0.25,-0.0) Error = 2.25e-11  */
	    ret_val = x + (x * x *
		(
		 (  4.79403173e-01F +
		    ( -1.88783908e-03F +
		      (  2.51101778e-03F
			 ) * x) * x)
		 /
		 (  9.58806346e-01F +
		    ( -3.23377784e-01F +
		      (  3.29143962e-02F
			 ) * x) * x) ) );
	else if (x < 0.25F)		/* [0.0,0.25) Error = 2.83e-11  */
	    ret_val = x + (x * x *
		(
		 (  5.21055248e-01F +
		    (  2.08307010e-03F +
		       (  3.07424218e-03F
			  ) * x) * x)
		 /
		 (  1.04211050e+00F +
		    ( -3.43204014e-01F +
		      (  3.37069272e-02F
			 ) * x) * x) ) );
	else if (x < 0.50F)		/* [0.25,0.50) Error = 3.56e-11  */
	    ret_val = x + (x * x *
		(
		 (  5.65650116e-01F +
		    (  6.65361369e-03F +
		       (  3.76388598e-03F
			  ) * x) * x)
		 /
		 (  1.13130002e+00F +
		    ( -3.63789880e-01F +
		      (  3.45006083e-02F
			 ) * x) * x) ) );
	else
	    ret_val = EXP(x) - ONE;

	return (ret_val);
    }
}
