import java.lang.Math;

public class alog1p
{
    final private static double ONE = 1.0D;
    final private static float LOG10E = 0.43429448190325182765112891891660508229439700580366e+00F;

    public static float alog1p(float x)
    {
	double u;
	double xx = (double)x;

	// This algorithm, from the HP15C Advanced Functions Handbook,
	// is the simplest way to get a reasonably accurate log1p()
	// function without a lot of extra work.

	u = ONE + xx;
	if (u == ONE)
	    return (x);
	else
	    return ((float)(Math.log((double)u) * (xx / (u - ONE))));
    }

    public static float al1p10(float x)
    {
	return (alog1p(x) * LOG10E);
    }
}
