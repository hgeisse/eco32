#include "mymath.h"

#define EXP(x)	(expl(x))

long double
expm1l(long double x)
{
    /*
     * (expm1)
     * Return (exp(x) - 1), taking care to avoid subtraction loss.
     *
     * This version uses a [16,3]-degree rational minimax polynomial
     * computed in Maple by
     *
     *     with(numapprox):
     *     Digits := 45:
     *     minimax((exp(x)-1)/x, x = ln(1/2)..ln(3/2), [16,3], 1, 'err');
     *     printf("%.2e\n", err);
     *
     * The reported absolute error is 1.79e-34, below the IEEE 754
     * machine epsilon of 2**(-112) = 1.93e-34.  This is the lowest
     * degree, and thus optimal, minimax polynomial whose error is below
     * that limit.
     * (28-Jun-2002)
     */

    long double ret_val;

    /*
     *
     * CUTLO = ln(0.5) (really, ln(1-1/beta) for arbitrary base beta)
     *
     */
    static const long double CUTLO = -0.6931471805599453094172321214581765680755001343603L;

    /*
     *
     * CUTHI = ln(1.5) (really, ln(1+1/beta) for arbitrary base beta)
     *
     */
    static const long double CUTHI = 0.4054651081081643819780131154643491365719904234625L;

    static const long double ONE = 1.0L;
    static const long double ZERO = 0.0L;

    /*
     *
     *     We handle the computation in three regions:
     *
     *     x in [-Infinity, CUTLO):  exp(x) - 1
     *     x in [CUTLO, CUTHI]:      minimax rational polynomial
     *     x in (CUTHI, Infinity]:   exp(x) - 1
     *
     *     The central region suffers loss of one or more bits if the
     *     simple formula is used.
     *
     *     The following IF statements handle the case of NaN, signed zero,
     *     and the three regions above.
     *
     */

    if (x != x)				/* then x is a NaN */
	ret_val = x;
    else if (x == ZERO)			/* then x is +0 or -0 */
	ret_val = x;			/* preserve sign of zero */
    else if (x < CUTLO)
	ret_val = EXP(x) - ONE;
    else if (x <= CUTHI)		/* region of accuracy loss from exp(x)-1 */
    {
          ret_val = x * 
	      ( (0.977437767816176824295873914911988946241517177e+00L +
		 (0.341249477070054781594573071011547578509688257e+00L +
		  (0.969832573769649287009304893648381750511229289e-1L +
		   (0.199084700196738286625079657452060261515764989e-1L +
		    (0.322984935039008252880960031302270225901780136e-2L +
		     (0.429843113930631628077154601253015572936683138e-3L +
		      (0.481437355047781886597085107690793011459159782e-4L +
		       (0.461755613370702817496765907010648170877678603e-5L +
			(0.383650621839688779748186280241425562044254436e-6L +
			 (0.278020382750811047387420504738603357739202135e-7L +
			  (0.176147252163317448447125213953304575796339455e-8L +
			   (0.973229604078564896345151127298606649989229928e-10L +
			    (0.464593682046213391221412581979315973603548365e-11L +
			     (0.187840424970267763244417494151527326352840751e-12L +
			      (0.617846968083500940047937565071896416137175389e-14L +
			       (0.151394203519577830639754336238265133841807061e-15L +
				0.215321782518817187702460410333236625856044521e-17L *
				x) * x) * x) * x) * x) * x) * x) * x) * x) * x) * x) * x) * x) * x) * x) * x) /
		(0.977437767816176824295873914911988876537811096e+00L +
		 (-0.147469406838033630553363886444452909213849417e+00L +
		  (0.781166615995227326163344676844896041757614925e-2L -
		   0.145702246304070555076189684817139689836002352e-3L *
		   x) * x) * x) );
    }
    else
	ret_val = EXP(x) - ONE;

    return (ret_val);
}
