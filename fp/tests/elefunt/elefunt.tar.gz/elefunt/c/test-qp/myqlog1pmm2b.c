#include "mymath.h"

long double
qlog1p(long double x)
{
    /* (log1p)
     * Return qlog(1 + x), taking care to avoid subtraction loss.
     * This version uses a [13,16]-degree rational minimax polynomial
     * computed in Maple by
     *
     *     with(numapprox):
     *     Digits := 50:
     *     minimax((ln(1+x)-x)/x^2, x = -0.5..0.5, [13,16], 1, 'err');
     *     printf("%0.2e\n", err);
     *
     * The reported absolute error is 4.76e-35, below the IEEE 754
     * machine epsilon of 2**(-112) = 1.93e-34.  This is the lowest
     * degree, and thus optimal, minimax polynomial whose error is below
     * that limit.
     * (24-Jun-2002)
     */

    /* Initialized data */

    static long double CUTLO = -0.5L;	/* CUTLO = -1/beta, for arbitrary base beta */
    static long double CUTHI = 0.5L;	/* CUTHI = 1/beta, for arbitrary base beta */
    static long double ONE = 1.0L;
    static long double ZERO = 0.0L;

    /* System generated locals */
    long double ret_val;

    /*
     *     We handle the computation in three regions:
     *
     *     x in [-Infinity, CUTLO):  log(1+x)
     *     x in [CUTLO, CUTHI]:      Taylor series
     *     x in (CUTHI, Infinity]:   log(1+x)
     *
     *     The central region suffers loss of ONE or more bits if the
     *     simple formula is used.
     *
     *     We also handle the cases of log1p(NaN) and log1p(0) specially,
     *     so as to preserve NaNs, and the sign of ZERO.
     */

    if (x != x)
	ret_val = x;
    else if (x == ZERO)
	ret_val = x;
    else if (x < CUTLO)
	ret_val = LOG(ONE + x);
    else if (x <= CUTHI)
    {
	ret_val = x +
	    (x * x * (
		      ( -7.2127225466752091973424044620547141e-02L +
		       ( -5.2414940858747900761508666119120248e-01L +
			( -1.7084901039153933072091165407637983e+00L +
			 ( -3.2970451940574646235968976311080633e+00L +
			  ( -4.1873079897829938985416808845565590e+00L +
			   ( -3.6794856515875892361638108343727440e+00L +
			    ( -2.2892426417201371004698519190005838e+00L +
			     ( -1.0143529857947273708942728451276634e+00L +
			      ( -3.1747423951627214200992153271841804e-01L +
			       ( -6.8595253801737287846238168377906009e-02L +
				( -9.8091818672043807414520881430024418e-03L +
				 ( -8.6290079772865518048040073290053314e-04L +
				  ( -4.0764123835752846114183798674710899e-05L +
				   ( -7.5076500857563971711384175217725898e-07L
				    ) * x) * x) * x) * x) * x) * x) * x) * x) * x) * x) * x) *
	       x) * x)
		      /
		      (  1.4425445093350418394684808924109428e-01L +
		       (  1.1444684511306274711947387152098013e+00L +
			(  4.1078319497844528365746348470469177e+00L +
			 (  8.8181125761126524095582550383388746e+00L +
			  (  1.2609144285556612578997160494152057e+01L +
			   (  1.2658870059103071921763022585886469e+01L +
			    (  9.1620549338848719662219185632679028e+00L +
			     (  4.8312001233824804623928730320880535e+00L +
			      (  1.8531992036736316463847982884952034e+00L +
			       (  5.1052564736058827368350067114963373e-01L +
				(  9.8421823983303890188112636618004405e-02L +
				 (  1.2705969068664639936309479091137197e-02L +
				  (  1.0198185828755564128130510896009376e-03L +
				   (  4.4400309095414284636769948146449737e-05L +
				    (  7.6015559597348728607158681702928999e-07L +
				     ( -8.2437333527694039012604926066861111e-11L +
				      (  7.5222803138709395012596952692689134e-13L
				       ) * x) * x) * x) * x) * x) * x) * x) * x) * x) * x) * x
	      ) * x) * x) * x) * x) * x) ) );
   }
    else
	ret_val = LOG(ONE + x);

    return (ret_val);
}


long double
ql1p10(long double x)
{
    /* (log1p10) */
    /* Return qlog10(1 + x), taking care to avoid subtraction loss. */
    /* (17-Jun-2002) */

    static long double LOG10E = 0.43429448190325182765112891891660508229439700580366L;

    return (qlog1p(x) * LOG10E);
}
