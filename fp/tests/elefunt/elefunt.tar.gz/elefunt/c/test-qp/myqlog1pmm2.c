#include "mymath.h"

long double
qlog1p(long double x)
{
    /* (log1p)
     * Return qlog(1 + x), taking care to avoid subtraction loss.
     * This version uses a [12,17]-degree rational minimax polynomial
     * computed in Maple by
     *
     *     with(numapprox):
     *     Digits := 50:
     *     minimax((ln(1+x)-x)/x^2, x = -0.5..0.5, [12,17], 1, 'err');
     *     printf("%0.2e\n", err);
     *
     * The reported absolute error is 7.22e-35, below the IEEE 754
     * machine epsilon of 2**(-112) = 1.93e-34.  This is the lowest
     * degree, and thus optimal, minimax polynomial whose error is below
     * that limit.
     * (24-Jun-2002)
     */

    /* Initialized data */

    static long double CUTLO = -0.5L;	/* CUTLO = -1/beta, for arbitrary base beta */
    static long double CUTHI = 0.5L;	/* CUTHI = 1/beta, for arbitrary base beta */
    static long double ONE = 1.0L;
    static long double ZERO = 0.0L;

    /* System generated locals */
    long double ret_val;

    /*
     *     We handle the computation in three regions:
     *
     *     x in [-Infinity, CUTLO):  log(1+x)
     *     x in [CUTLO, CUTHI]:      Taylor series
     *     x in (CUTHI, Infinity]:   log(1+x)
     *
     *     The central region suffers loss of ONE or more bits if the
     *     simple formula is used.
     *
     *     We also handle the cases of log1p(NaN) and log1p(0) specially,
     *     so as to preserve NaNs, and the sign of ZERO.
     */

    if (x != x)
	ret_val = x;
    else if (x == ZERO)
	ret_val = x;
    else if (x < CUTLO)
	ret_val = LOG(ONE + x);
    else if (x <= CUTHI)
    {
	ret_val = x +
	    (x * x * (
		      ( -7.6023399555445503312840482632220622e-02L +
		       ( -5.4188438193478341642265359571746971e-01L +
			( -1.7272686776177026275023076764264041e+00L +
			 ( -3.2473031202003540634848548764640785e+00L +
			  ( -3.9982594410025757948167893874035092e+00L +
			   ( -3.3844156775570200024869354997662068e+00L +
			    ( -2.0108893613528585226369405055820907e+00L +
			     ( -8.4062759618942433576022187305640916e-01L +
			      ( -2.4381738352227114281233457737562423e-01L +
			       ( -4.7466394575514122897305225475319958e-02L +
				( -5.8271025273284854140559758224776300e-03L +
				 ( -3.9955401374228824364371766038653918e-04L +
				  ( -1.1360275745255318998392498905879510e-05L
				   ) * x) * x) * x) * x) * x) * x) * x) * x) * x) * x) * x) * x)
		      /
		      (  1.5204679911089100662568096526444124e-01L +
		       (  1.1851332966101608372624278349445671e+00L +
			(  4.1686028200867336432000600935169674e+00L +
			 (  8.7419268584644732064554749505728429e+00L +
			  (  1.2163539763211867571700276173985888e+01L +
			   (  1.1822733073124133343917631722755233e+01L +
			    (  8.2296651734122162825409884000520762e+00L +
			     (  4.1363066211501447903787846330640509e+00L +
			      (  1.4934161807086644670671191764299290e+00L +
			       (  3.8013506677759407121375255485598016e-01L +
				(  6.5776707908187545233682940194756659e-02L +
				 (  7.2507994119284613886721544546824525e-03L +
				  (  4.4986651441130270834132104986947298e-04L +
				   (  1.1591102875470817656540789798455765e-05L +
				    ( -3.9661053699328316225448355875185740e-09L +
				     (  1.0581884511872563845911359369876249e-10L +
				      ( -2.9187242983451395765187205589816685e-12L +
				       (  5.5714787307466127434224882091781997e-14L
					) * x) * x) * x) * x) * x) * x) * x) * x) * x) * x) *
			       x) * x) * x) * x) * x) * x) * x) ) );
   }
    else
	ret_val = LOG(ONE + x);

    return (ret_val);
}


long double
ql1p10(long double x)
{
    /* (log1p10) */
    /* Return qlog10(1 + x), taking care to avoid subtraction loss. */
    /* (17-Jun-2002) */

    static long double LOG10E = 0.43429448190325182765112891891660508229439700580366L;

    return (qlog1p(x) * LOG10E);
}
