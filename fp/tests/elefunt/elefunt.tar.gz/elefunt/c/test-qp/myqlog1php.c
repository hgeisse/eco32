#include "mymath.h"

long double
qlog1p(long double x)
{
    /*
     * (log1p)
     * Return qlog(1 + x), taking care to avoid subtraction loss.
     *
     * This version uses an algorithm developed for the HP-15C
     * calculator, mentioned in the log1p implementation in Sun's
     * Freely-Distributable Math Library, FDLIBM:
     *
     *  >> Note: Assuming log() return [sic] accurate answer, the
     *  >>       following algorithm can be used to compute log1p(x)
     *  >>       to within a few ULP:
     *  >>
     *  >>                u = 1+x;
     *  >>                if(u==1.0L) return x ; else
     *  >>                           return log(u)*(x/(u-1.0L));
     *  >>
     *  >>       See HP-15C Advanced Functions Handbook, p. 193.
     *
     * (22-Jun-2002)
     */

    /* Initialized data */

    static long double ONE = 1.0L;

    /* System generated locals */
    long double ret_val;

    /* Local variables */
    long double u;

    u = ONE + x;
    if (u == ONE)
	ret_val = x;
    else
	ret_val = LOG(u) * (x / (u - ONE));

    return (ret_val);
}


long double
ql1p10(long double x)
{
    /* (log1p10) */
    /* Return qlog10(1 + x), taking care to avoid subtraction loss. */
    /* (17-Jun-2002) */

    static long double LOG10E = 0.43429448190325182765112891891660508229439700580366L;

    return (qlog1p(x) * LOG10E);
}
