#include "mymath.h"

long double
qexpm1(long double x)
{
    return (expm1l(x));
}
