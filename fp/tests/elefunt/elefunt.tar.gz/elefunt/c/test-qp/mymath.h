#include <math.h>

#if defined(__sun)
#include <sunmath.h>
#endif

#define LOG(x) logl(x)
