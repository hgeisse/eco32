#include "mymath.h"

#define EXP(x)	(expl(x))

long double
expm1l(long double x)
{
    /*
     * (expm1)
     * Return (exp(x) - 1), taking care to avoid subtraction loss.
     *
     * This version uses a [23,4]-degree Pad� approximation computed in
     * Maple by
     *
     *     with(numapprox):
     *     Digits := 65:
     *     pade((exp('x') - 1)/'x', 'x' = 0, [23,4]);
     *
     * The computed relative error is 1.13e-34, below the IEEE 754
     * machine epsilon of 2**(-112) = 1.93e-34.  This is the lowest
     * degree, and thus optimal, Pad� approximation whose error is below
     * that limit.
     * (29-Jun-2002)
     */

    long double ret_val;

    /*
     *
     * CUTLO = ln(0.5) (really, ln(1-1/beta) for arbitrary base beta)
     *
     */
    static const long double CUTLO = -0.6931471805599453094172321214581765680755001343603L;

    /*
     *
     * CUTHI = ln(1.5) (really, ln(1+1/beta) for arbitrary base beta)
     *
     */
    static const long double CUTHI = 0.4054651081081643819780131154643491365719904234625L;

    static const long double ONE = 1.0L;
    static const long double ZERO = 0.0L;

    /*
     *
     *     We handle the computation in three regions:
     *
     *     x in [-Infinity, CUTLO):  exp(x) - 1
     *     x in [CUTLO, CUTHI]:      Pad� approximation
     *     x in (CUTHI, Infinity]:   exp(x) - 1
     *
     *     The central region suffers loss of one or more bits if the
     *     simple formula is used.
     *
     *     The following IF statements handle the case of NaN, signed zero,
     *     and the three regions above.
     *
     */

    if (x != x)				/* then x is a NaN */
	ret_val = x;
    else if (x == ZERO)			/* then x is +0 or -0 */
	ret_val = x;			/* preserve sign of zero */
    else if (x < CUTLO)
	ret_val = EXP(x) - ONE;
    else if (x <= CUTHI)		/* region of accuracy loss from exp(x)-1 */
    {
	ret_val = x *
	    (
	     ( 1.0592686586172154118162395247036826028389289915809078093e+00L +
	       ( 3.8017150148754008921082481615405288321779945357630501841e-01L +
		 ( 1.1000701726826047659822763733467674828255874068119348401e-01L +
		   ( 2.3115453106226218891631229191030230181743134445132413290e-02L +
		     ( 3.8637206121050670724628150998898360759414002064123863520e-03L +
		       ( 5.3358852148859875249939513979525008359574964290641590797e-04L +
			 ( 6.2576341569198701074533125176406579463412954575598645462e-05L +
			   ( 6.3554477297942000061558171379780334549213571225144512879e-06L +
			     ( 5.6722730905060526209884473081880868126024670184493451306e-07L +
			       ( 4.4983497594153389253831356698341787259591565924761412898e-08L +
				 ( 3.1967135102635480980585516024443732983268984223166886446e-09L +
				   ( 2.0486918373735891829757496505983707263899860048079587517e-10L +
				     ( 1.1895444312645733723467345704151977384414131308239200673e-11L +
				       ( 6.2767726991635422584619159909468878177137427567050227342e-13L +
					 ( 3.0143041181939435361781240611006190270814432047732898079e-14L +
					   ( 1.3171821283155159300137408471331554325344324220829235376e-15L +
					     ( 5.2259059497297198078066003228700519330426836533318715155e-17L +
					       ( 1.8735311445694303286760197235511181578385796887139325844e-18L +
						 ( 6.0183248784747991504239705702546661789030662806620688142e-20L +
						   ( 1.7078714020147202678301612938084699494112807781720855910e-21L +
						     ( 4.1799647062291262413558313058884057693921737826890229844e-23L +
						       ( 8.4493747226951915719148027837225629054761528526636060601e-25L +
							 ( 1.2904806470840679584215922294963062487170995191593693222e-26L +
							   ( 1.1667453221168003768521989168294672097600757989825133161e-28L
							     ) * x) * x) * x) * x) * x) * x) * x) * x) * x) * x) * x) * x) * x) * x) * x) * x) * x) * x) * x) * x) * x) * x) * x)
	     /
	     ( 1.0592686586172154118162395247036826028389289916617508163e+00L +
	       (-1.4946282782106761669729494619778841820166504782397210882e-01L +
		( 8.1936547425917163108351896496238569102366176077891243905e-03L +
		  (-2.0709707060901197324718813013707035805698353968123663580e-04L +
		   ( 2.0390277119759378658376090648908380693478688423498374501e-06L
		     ) * x) * x) * x) * x) );
    }
    else
	ret_val = EXP(x) - ONE;

    return (ret_val);
}
