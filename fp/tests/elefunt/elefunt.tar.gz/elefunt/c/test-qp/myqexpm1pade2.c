#include "mymath.h"

#define EXP(x)	(expl(x))

long double
expm1l(long double x)
{
    /*
     * (expm1)
     * Return (exp(x) - 1), taking care to avoid subtraction loss.
     *
     * This version uses a [10,11]-degree Pad� approximation computed in
     * Maple by
     *
     *     with(numapprox):
     *     Digits := 200:
     *     pade((exp('x') - 1 - 'x')/'x'^2, 'x' = (ln(1/2)+ln(3/2))/2, [10,11]);
     *
     * The computed relative error is 5.76e-36, below the IEEE 754
     * machine epsilon of 2**(-112) = 1.93e-34.  This is the lowest
     * degree, and thus optimal, Pad� approximation whose error is below
     * that limit.
     * (29-Jun-2002)
     */

    long double ret_val;

    /*
     *
     * CUTLO = ln(0.5) (really, ln(1-1/beta) for arbitrary base beta)
     *
     */
    static const long double CUTLO = -0.6931471805599453094172321214581765680755001343603L;

    /*
     *
     * CUTHI = ln(1.5) (really, ln(1+1/beta) for arbitrary base beta)
     *
     */
    static const long double CUTHI = 0.4054651081081643819780131154643491365719904234625L;

    static const long double ONE = 1.0L;
    static const long double ZERO = 0.0L;

    /*
     *
     *     We handle the computation in three regions:
     *
     *     x in [-Infinity, CUTLO):  exp(x) - 1
     *     x in [CUTLO, CUTHI]:      Pad� approximation
     *     x in (CUTHI, Infinity]:   exp(x) - 1
     *
     *     The central region suffers loss of one or more bits if the
     *     simple formula is used.
     *
     *     The following IF statements handle the case of NaN, signed zero,
     *     and the three regions above.
     *
     */

    if (x != x)				/* then x is a NaN */
	ret_val = x;
    else if (x == ZERO)			/* then x is +0 or -0 */
	ret_val = x;			/* preserve sign of zero */
    else if (x < CUTLO)
	ret_val = EXP(x) - ONE;
    else if (x <= CUTHI)		/* region of accuracy loss from exp(x)-1 */
    {
	ret_val = x + (x * x * (
	( -4.6671405424051156668730159042291780e-01L +
	 (  6.8337863211040179823187490406114809e-02L +
	  ( -1.5319269505231415700726414750723420e-02L +
	   (  1.1817856792635574933144347874442489e-03L +
	    ( -1.1438436363142454913478722626777282e-04L +
	     (  5.2401026279573950882200824193551581e-06L +
	      ( -2.7142918889149747680364799956132681e-07L +
	       (  7.2357627494303094155140359107322077e-09L +
	        ( -1.9248316357971163827328383303209631e-10L +
	         (  2.3933939585787640183645444984492744e-12L +
	          ( -1.9768083650308227979896913770261041e-14L
	           ) * x) * x) * x) * x) * x) * x) * x) * x) * x) * x)
	/
	( -9.3342810848102313337460318084583559e-01L +
	 (  4.4781842924908807077124270776084148e-01L +
	  ( -1.0212567305340692721065013368457437e-01L +
	   (  1.4644395080255803715485408170440424e-02L +
	    ( -1.4705456301572766560240134404100820e-03L +
	     (  1.0885827448563351701431532968952325e-04L +
	      ( -6.0790353304653367005261737668494578e-06L +
	       (  2.5691264540061093410646108934357269e-07L +
	        ( -8.0816910913936563611496162207120016e-09L +
	         (  1.8095429198546028101568066654688430e-10L +
	          ( -2.6077074178924979470877789761666163e-12L +
	           (  1.8422518470679519420745580156208582e-14L
	            ) * x) * x) * x) * x) * x) * x) * x) * x) * x) * x) * x) ) );
    }
    else
	ret_val = EXP(x) - ONE;

    return (ret_val);
}
