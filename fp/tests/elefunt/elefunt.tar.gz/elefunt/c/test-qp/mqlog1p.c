#include <stdlib.h>

extern void tqlog1p(void);

int
main(void)
{
    tqlog1p();
    return (EXIT_SUCCESS);
}
