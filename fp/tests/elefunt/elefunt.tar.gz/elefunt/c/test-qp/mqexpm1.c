#include <stdlib.h>

extern void tqexpm1(void);

int
main(void)
{
    tqexpm1();
    return (EXIT_SUCCESS);
}
