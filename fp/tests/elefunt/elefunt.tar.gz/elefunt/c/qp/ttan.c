/* -*-C-*- ttan.c */

#include "elefunt.h"

/*#     program to test tan/cotan
#
#     data required
#
#        none
#
#     subprograms required from this package
#
#        machar - an environmental inquiry program providing
#                 information on the floating-point arithmetic
#                 system.  note that the call to machar can
#                 be deleted provided the following three
#                 parameters are assigned the values indicated
#
#                 ibeta  - the radix of the floating-point system
#                 it     - the number of base-ibeta digits in the
#                          significand of a floating-point number
#                 minexp - the largest in magnitude negative
#                          integer such that float(ibeta)**minexp
#                          is a positive floating-point number
#
#        ran(k) - a function subprogram returning random real
#                 numbers uniformly distributed over (0,1)
#
#
#     standard fortran subprograms required
#
#         abs, alog, amax1, cotan, float, tan, sqrt
#
#
#     latest revision - december 6, 1979
#
#     author - w. j. cody
#              argonne national laboratory
#
# */

void
ttan(VOID_ARG)
{
    int i,
        ibeta,
        iexp,
        irnd,
        it,
        j,
        k1,
        k2,
        k3,
        machep,
        maxexp,
        minexp,
        n,
        negep,
        ngrd;

    qp_t
        eps,
        epsneg,
        xmax,
        xmin;

    volatile qp_t 
	a,
        ait,
        albeta,
        b,
        beta,
        betap,
        c1,
        c2,
        del,
        half,
        pi,
        r6,
        r7,
        w,
        x,
        xl,
        xn,
        x1,
        y,
        z,
        zz;

    /*******************************************************************/

    (void)qranset(initseed());
    macharl(&ibeta, &it, &irnd, &ngrd, &machep, &negep, &iexp, &minexp,
        &maxexp, &eps, &epsneg, &xmin, &xmax);

    beta = TO_FP_T(ibeta);
    albeta = ALOG(beta);
    half = 0.5e+00L;
    ait = TO_FP_T(it);
    pi = 3.141592653589793238462643383279502884197169399375105821e+00L;
    a = ZERO;
    b = pi * 0.25e+00L;
    n = maxtest();
    xn = TO_FP_T(n);
    z = ZERO;

    /* random argument accuracy tests */

    for (j = 1; j <= 4; ++j)
    {
	k1 = 0;
	k3 = 0;
	x1 = ZERO;
	r6 = ZERO;
	r7 = ZERO;
	del = (b - a) / xn;
	xl = a;

	for (i = 1; i <= n; ++i)
	{
	    x = del * RAN() + xl;
	    y = x * half;
	    x = y + y;
	    if (j == 4)
	    {
		z = COTAN(x);
		zz = COTAN(y);
		w = 1.0e+00L;
		if (z != ZERO)
		{
		    w = ((half - zz) + half) * ((half + zz) + half);
		    w = (z + w / (zz + zz)) / z;
		}
	    }
	    else
	    {
		z = TAN(x);
		zz = TAN(y);
		w = 1.0e+00L;
		if (z != ZERO)
		{
		    w = ((half - zz) + half) * ((half + zz) + half);
		    w = (z - (zz + zz) / w) / z;
		}
	    }
	    if (w > ZERO)
		k1 = k1 + 1;
	    if (w < ZERO)
		k3 = k3 + 1;
	    w = ABS(w);
	    if (w > r6)
	    {
		r6 = w;
		x1 = x;
	    }
	    r7 = r7 + w * w;
	    xl = a + TO_FP_T(i) * del;	/* OLD: xl = xl + del (bad for large n) */
	}

	k2 = n - k3 - k1;
	r7 = SQRT(r7 / xn);
	if (j != 4)
	    (void)printf("1TEST OF TAN(X) VS 2*TAN(X/2)/(1-TAN(X/2)**2)\n\n\n");
	if (j == 4)
	    (void)printf("1TEST OF COT(X) VS (COT(X/2)**2-1)/(2*COT(X/2))\n\n\n");
	(void)printf("%7d RANDOM ARGUMENTS WERE TESTED FROM THE INTERVAL\n", n);
	(void)printf("    (%15.4Le,%15.4Le)\n\n\n", a, b);
	if (j != 4)
	{
	    (void)printf(" TAN(X) WAS LARGER%6d TIMES,\n", k1);
	    (void)printf("            AGREED%6d TIMES, AND\n", k2);
	    (void)printf("       WAS SMALLER%6d TIMES.\n\n", k3);
	}
	if (j == 4)
	{
	    (void)printf(" COT(X) WAS LARGER%6d TIMES,\n", k1);
	    (void)printf("            AGREED%6d TIMES, AND\n", k2);
	    (void)printf("       WAS SMALLER%6d TIMES.\n\n\n", k3);
	}
	(void)printf(" THERE ARE%4d BASE%4d SIGNIFICANT DIGITS IN A FLOATING-POINT NUMBER\n\n\n",
	    it, ibeta);
	w = -999.0e+00L;
	if (r6 != ZERO)
	    w = ALOG(ABS(r6)) / albeta;
	(void)printf(" THE MAXIMUM RELATIVE ERROR OF%15.4Le = %4d **%7.2Lf\n",
	    r6, ibeta, w);
	(void)printf("    OCCURRED FOR X =%17.6Le\n", x1);
	w = AMAX1(ait + w, ZERO);
	(void)printf(
	    " THE ESTIMATED LOSS OF BASE%4d SIGNIFICANT DIGITS IS%7.2Lf\n\n\n",
	    ibeta, w);
	w = -999.0e+00L;
	if (r7 != ZERO)
	    w = ALOG(ABS(r7)) / albeta;
	(void)printf(" THE ROOT MEAN SQUARE RELATIVE ERROR WAS%15.4Le = %4d **%7.2Lf\n",
	    r7, ibeta, w);
	w = AMAX1(ait + w, ZERO);
	(void)printf(
	    " THE ESTIMATED LOSS OF BASE%4d SIGNIFICANT DIGITS IS%7.2Lf\n\n\n",
	    ibeta, w);
	if (j != 1)
	{
	    a = pi * 6.0e+00L;
	    b = a + pi * 0.25e+00L;
	}
	else
	{
	    a = pi * 0.875e+00L;
	    b = pi * 1.125e+00L;
	}
    }

    /* special tests */

    (void)printf("1SPECIAL TESTS\n\n\n");
    (void)printf(" THE IDENTITY  TAN(-X) = -TAN(X)  WILL BE TESTED.\n\n");
    (void)printf("        X         F(X) + F(-X)\n\n");

    for (i = 1; i <= 5; ++i)
    {
	x = RAN() * a;
	z = TAN(x) + TAN(-x);
	(void)printf("%15.7Le%15.7Le\n\n", x, z);
    }

    (void)printf(" THE IDENTITY TAN(X) = X , X SMALL, WILL BE TESTED.\n\n");
    (void)printf("        X         X - F(X)\n\n");
    betap = IPOW(beta, it);
    x = RAN() / betap;

    for (i = 1; i <= 5; ++i)
    {
	z = x - TAN(x);
	(void)printf("%15.7Le%15.7Le\n\n", x, z);
	x = x / beta;
    }

    (void)printf(" TEST OF UNDERFLOW FOR VERY SMALL ARGUMENT.\n\n");
    x = POW(beta, TO_FP_T(minexp) * 0.75e+00L);
    y = TAN(x);
    (void)printf("       TAN(%13.6Le) =%13.6Le\n\n", x, y);
    c1 = -225.0e+00L;
    c2 = -0.9508464541951420257954832034531539516575098851311946e+00L;
    x = 11.0e+00L;
    y = TAN(x);
    w = ((c1 - y) + c2) / (c1 + c2);
    z = ALOG(ABS(w)) / albeta;
    (void)printf(" THE RELATIVE ERROR IN TAN(11) IS%15.7Le = %4d **%7.2Lf WHERE\n\n",
        w, ibeta, z);
    (void)printf("      TAN(%13.6Le) =%13.6Le\n\n", x, y);
    w = AMAX1(ait + z, ZERO);
    (void)printf(
        " THE ESTIMATED LOSS OF BASE%4d SIGNIFICANT DIGITS IS%7.2Lf\n\n\n",
        ibeta, w);

    /* test of error returns */

    (void)printf("1TEST OF ERROR RETURNS\n\n\n");

    x = POW(beta, TO_FP_T(it / 2));
    (void)printf(" TAN WILL BE CALLED WITH THE ARGUMENT%15.4Le\n",x);
    (void)printf(" THIS SHOULD NOT TRIGGER AN ERROR MESSAGE\n\n\n");
    fflush(stdout);
    errno = 0;
    y = TAN(x);
    if (errno)
	perror("TAN()");
    (void)printf(" TAN RETURNED THE VALUE%15.4Le\n\n\n\n", y);

    x = betap;
    (void)printf("\nTAN WILL BE CALLED WITH THE ARGUMENT%15.4Le\n", x);
    (void)printf(" THIS SHOULD TRIGGER AN ERROR MESSAGE\n\n\n");
    fflush(stdout);
    errno = 0;
    y = TAN(x);
    if (errno)
	perror("TAN()");
    (void)printf(" TAN RETURNED THE VALUE%15.4Le\n\n\n\n", y);

    (void)printf(" THIS CONCLUDES THE TESTS\n");
}
