/* -*-C-*- store.c */

#include "elefunt.h"

#if STDC
qp_t
(storel)(qp_t* p)
#else /* NOT STDC */
qp_t
(storel)(p)
qp_t* p;
#endif /* STDC */
{
    /* NO-OP -- want to force memory store of argument */
    /* Needed for IEEE arithmetic plus Intel, Honeywell, Motorola */
    /* (floating point registers larger than memory word size) */
    return (*p);
}
