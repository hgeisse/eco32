/* -*-C-*- tsmach.c */

#include "elefunt.h"

void
tmacha(VOID_ARG)
{
    int ibeta,
        iexp,
        irnd,
        it,
        machep,
        maxexp,
        minexp,
        negep,
        ngrd;

    qp_t
        eps,
        epsneg,
        xmax,
        xmin;

    macharl(&ibeta, &it, &irnd, &ngrd, &machep, &negep, &iexp, &minexp,
        &maxexp, &eps, &epsneg, &xmin, &xmax);

    (void)printf("ibeta............%8d\n",ibeta);
    (void)printf("it...............%8d\n",it);
    (void)printf("irnd.............%8d\n",irnd);
    (void)printf("ngrd.............%8d\n",ngrd);
    (void)printf("machep...........%8d\n",machep);
    (void)printf("negep............%8d\n",negep);
    (void)printf("iexp.............%8d\n",iexp);
    (void)printf("minexp...........%8d\n",minexp);
    (void)printf("maxexp...........%8d\n",maxexp);
    (void)printf("eps..............%45.34Le\n",eps);
    (void)printf("epsneg...........%45.34Le\n",epsneg);
    (void)printf("xmin.............%45.34Le\n",xmin);
    (void)printf("xmax.............%45.34Le\n",xmax);
}
