/* -*-C-*- talog.c */

#include "elefunt.h"

/*#     program to test alog
#
#     data required
#
#        none
#
#     subprograms required from this package
#
#        machar - an environmental inquiry program providing
#                 information on the floating-point arithmetic
#                 system.  note that the call to machar can
#                 be deleted provided the following four
#                 parameters are assigned the values indicated
#
#                 ibeta - the radix of the floating-point system
#                 it    - the number of base-ibeta digits in the
#                         significand of a floating-point number
#                 xmin  - the smallest non-vanishing floating-point
#                         power of the radix
#                 xmax  - the largest finite floating-point no.
#
#        ran(k) - a function subprogram returning random real
#                 numbers uniformly distributed over (0,1)
#
#
#     standard fortran subprograms required
#
#         abs, alog, alog10, amax1, float, sign, sqrt
#
#
#     latest revision - december 6, 1979
#
#     author - w. j. cody
#              argonne national laboratory
#
#*/

void
talog(VOID_ARG)
{
    int i,
        ibeta,
        iexp,
        irnd,
        it,
        j,
        k1,
        k2,
        k3,
        machep,
        maxexp,
        minexp,
        n,
        negep,
        ngrd;

    qp_t
        eps,
        epsneg,
        xmax,
        xmin;

    volatile qp_t 
	a,
        ait,
        albeta,
        b,
        beta,
        c,
        del,
        eight,
        half,
        r6,
        r7,
        tenth,
        w,
        x,
        xl,
        xn,
        x1,
        y,
        z,
        zz;

    /*******************************************************************/

    (void)qranset(initseed());
    macharl(&ibeta, &it, &irnd, &ngrd, &machep, &negep, &iexp, &minexp,
        &maxexp, &eps, &epsneg, &xmin, &xmax);

    beta = TO_FP_T(ibeta);
    albeta = ALOG(beta);
    ait = TO_FP_T(it);
    j = it / 3;
    half = 0.5e+00L;
    eight = 8.0e+00L;
    tenth = 0.1e+00L;
    c = ONE;

    for (i = 1; i <= j; ++i)
	c = c / beta;

    b = ONE + c;
    a = ONE - c;
    n = maxtest();
    xn = TO_FP_T(n);

    /* random argument accuracy tests */

    for (j = 1; j <= 4; ++j)
    {
	k1 = 0;
	k3 = 0;
	x1 = ZERO;
	r6 = ZERO;
	r7 = ZERO;
	del = (b - a) / xn;
	xl = a;

	for (i = 1; i <= n; ++i)
	{
	    x = del * RAN() + xl;
	    if (j == 1)
	    {
		y = (x - half);
		y -= half;
		zz = ALOG(x);
		z = ONE / 3.0e+00L;
		z = y * (z - y / 4.0e+00L);
		z = (z - half) * y * y + y;
	    }
	    else if (j == 2)
	    {
		x += eight;
		x -= eight;
		y = x + x / 16.0e+00L;
		z = ALOG(x);
		zz = ALOG(y) - 7.77468164348425806061320404202632862024751447237708145e-05L;
		zz = zz - 31.0e+00L / 512.0e+00L;
	    }
	    else
	    if (j != 3)
	    {
		z = ALOG(x * x);
		zz = ALOG(x);
		zz = zz + zz;
	    }
	    else
	    {
		x += eight;
		x -= eight;
		y = x + x * tenth;
		z = ALOG10(x);
		zz = ALOG10(y) - 3.770601582250407501999712430242417067021904664530945966e-04L;
		zz = zz - 21.0e+00L / 512.0e+00L;
	    }
	    w = ONE;
	    if (z != ZERO)
		w = (z - zz) / z;
	    z = SIGN(w, z);
	    if (z > ZERO)
		k1 = k1 + 1;
	    if (z < ZERO)
		k3 = k3 + 1;
	    w = ABS(w);
	    if (w > r6)
	    {
		r6 = w;
		x1 = x;
	    }
	    r7 = r7 + w * w;
	    xl = a + TO_FP_T(i) * del;	/* OLD: xl = xl + del (bad for large n) */
	}

	k2 = n - k3 - k1;
	r7 = SQRT(r7 / xn);
	if (j == 1)
	    (void)printf("1TEST OF ALOG(X) VS T.S. EXPANSION OF ALOG(1+Y)\n\n\n");
	else if (j == 2)
	    (void)printf("1TEST OF ALOG(X) VS ALOG(17X/16)-ALOG(17/16)\n\n\n");
	else if (j == 3)
	    (void)printf("1TEST OF ALOG10(X) VS ALOG10(11X/10)-ALOG10(11/10)\n\n\n");
	else if (j == 4)
	    (void)printf("1TEST OF ALOG(X*X) VS 2 * LOG(X)\n\n\n");
	if (j == 1)
	{
	    (void)printf("%7d RANDOM ARGUMENTS WERE TESTED FROM THE INTERVAL\n",n);
	    (void)printf("      (1-EPS,1+EPS), WHERE EPS =%15.4Le\n\n\n", c);
	}
	else
	{
	    (void)printf("%7d RANDOM ARGUMENTS WERE TESTED FROM THE INTERVAL\n", n);
	    (void)printf("      (%15.4Le,%15.4Le)\n\n\n", a, b);
	}
	if (j != 3)
	{
    	    (void)printf(" ALOG(X) WAS LARGER%6d TIMES,\n", k1);
	    (void)printf("             AGREED%6d TIMES, AND\n", k2);
	    (void)printf("        WAS SMALLER%6d TIMES.\n\n\n", k3);
	}
	else
	{
    	    (void)printf(" ALOG10(X) WAS LARGER%6d TIMES,\n", k1);
	    (void)printf("               AGREED%6d TIMES, AND\n", k2);
	    (void)printf("          WAS SMALLER%6d TIMES.\n\n\n", k3);
	}
	(void)printf(" THERE ARE%4d BASE%4d SIGNIFICANT DIGITS IN A FLOATING-POINT NUMBER\n\n\n",
	    it, ibeta);
	w = -999.0e+00L;
	if (r6 != ZERO)
	    w = ALOG(ABS(r6)) / albeta;
	(void)printf(" THE MAXIMUM RELATIVE ERROR OF%15.4Le = %4d **%7.2Lf\n",
	    r6, ibeta, w);
	(void)printf("    OCCURRED FOR X =%17.6Le\n", x1);
	w = AMAX1(ait + w, ZERO);
	(void)printf(
	    " THE ESTIMATED LOSS OF BASE%4d SIGNIFICANT DIGITS IS%7.2Lf\n\n\n",
	    ibeta, w);
	w = -999.0e+00L;
	if (r7 != ZERO)
	    w = ALOG(ABS(r7)) / albeta;
	(void)printf(" THE ROOT MEAN SQUARE RELATIVE ERROR WAS%15.4Le = %4d **%7.2Lf\n",
	    r7, ibeta, w);
	w = AMAX1(ait + w, ZERO);
	(void)printf(
	    " THE ESTIMATED LOSS OF BASE%4d SIGNIFICANT DIGITS IS%7.2Lf\n\n\n",
	    ibeta, w);
	if (j <= 1)
	{
	    a = SQRT(half);
	    b = 15.0e+00L / 16.0e+00L;
	}
	else if (j > 2)
	{
	    a = 16.0e+00L;
	    b = 240.0e+00L;
	}
	else
	{
	    a = SQRT(tenth);
	    b = 0.9e+00L;
	}
    }

    /* special tests */

    (void)printf("1SPECIAL TESTS\n\n\n");
    (void)printf(" THE IDENTITY  ALOG(X) = -ALOG(1/X)  WILL BE TESTED.\n\n");
    (void)printf("        X         F(X) + F(1/X)\n\n");

    for (i = 1; i <= 5; ++i)
    {
	x = RAN();
	x = x + x + 15.0e+00L;
	y = ONE / x;
	z = ALOG(x) + ALOG(y);
	(void)printf("%15.7Le%15.7Le\n\n", x, z);
    }

    (void)printf("\n\n TEST OF SPECIAL ARGUMENTS\n\n\n");
    x = ONE;
    y = ALOG(x);
    (void)printf(" ALOG(1.0) = %15.7Le\n\n\n", y);
    x = xmin;
    y = ALOG(x);
    (void)printf(" ALOG(XMIN) = ALOG(%15.7Le) = %15.7Le\n\n\n", x, y);
    x = xmax;
    y = ALOG(x);
    (void)printf(" ALOG(XMAX) = ALOG(%15.7Le) = %15.7Le\n\n\n", x, y);

    /* test of error returns */

    (void)printf("1TEST OF ERROR RETURNS\n\n\n");

    x = -2.0e+00L;
    (void)printf(" ALOG WILL BE CALLED WITH THE ARGUMENT%15.4Le\n",x);
    (void)printf(" THIS SHOULD TRIGGER AN ERROR MESSAGE\n\n\n");
    fflush(stdout);
    errno = 0;
    y = ALOG(x);
    if (errno)
	perror("ALOG()");
    (void)printf(" ALOG RETURNED THE VALUE%15.4Le\n\n\n", y);

    x = ZERO;
    (void)printf(" ALOG WILL BE CALLED WITH THE ARGUMENT%15.4Le\n",x);
    (void)printf(" THIS SHOULD TRIGGER AN ERROR MESSAGE\n\n\n");
    fflush(stdout);
    errno = 0;
    y = ALOG(x);
    if (errno)
	perror("ALOG()");
    (void)printf(" ALOG RETURNED THE VALUE%15.4Le\n\n\n\n", y);

    (void)printf(" THIS CONCLUDES THE TESTS\n");
}
