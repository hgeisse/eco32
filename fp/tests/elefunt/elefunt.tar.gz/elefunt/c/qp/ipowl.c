/* -*-C-*- ipowl.c */

#include "elefunt.h"

#if STDC
qp_t
(ipowl)(qp_t x, int n)
#else /* NOT STDC */
qp_t
(ipowl)(x, n)
qp_t x;
int n;
#endif /* STDC */
{
    qp_t value;
    int k;

    value = 1.0L;
    for (k = 1; k <= ABS(n); ++k)
	value *= x;
    if (n < 0)
	value = 1.0L / value;
    return (value);
}
