#if defined(__TURBOC__)

#include <math.h>

int
matherr(struct exception *e)
{
    union dword
    {
	long w[2];
	dp_t d;
    }
    NaN;

    NaN.w[0] = 0x0L;
    NaN.w[1] = 0xFFF00000L;

    switch (e->type)
    {
    case DOMAIN:
    case SING:
    case OVERFLOW:
    case TLOSS:
    case PLOSS:
	e->retval = NaN.d; return(1);
    case UNDERFLOW:
	e->retval = 0.0; return(1);
    default:	/* should never happen */
	return (0);
    }
}
#endif /* defined(__TURBOC__) */

