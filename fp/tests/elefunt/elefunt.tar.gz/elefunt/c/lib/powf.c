/* -*-C-*- pow.c */

/*
	computes a^b.
	uses log and exp
*/

#include "elefunt.h"

#if STDC
sp_t
powf(sp_t arg1, sp_t arg2)
#else /* NOT STDC */
sp_t
powf(arg1, arg2)
sp_t arg1,
    arg2;
#endif /* STDC */
{
    sp_t temp;
    long l;

    if (arg1 <= 0.0F)
    {
	if (arg1 == 0.0F)
	{
	    if (arg2 <= 0.0F)
		goto domain;
	    return (0.0F);
	}
	l = arg2;
	if (l != arg2)
	    goto domain;
	temp = expf(arg2 * logf(-arg1));
	if (l & 1)
	    temp = -temp;
	return (temp);
    }
    return (expf(arg2 * logf(arg1)));

domain:
    errno = EDOM;
    return (0.0F);
}
