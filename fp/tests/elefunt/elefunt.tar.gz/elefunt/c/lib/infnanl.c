#include "elefunt.h"

#if STDC
qp_t	infnanl(int iarg)
#else /* NOT STDC */
qp_t	infnanl(iarg)
int	iarg ;
#endif /* STDC */
{
	switch(iarg) {
	case	 ERANGE:	errno = ERANGE;	return(HUGE_VALL);
	case	-ERANGE:	errno = EDOM;	return(-HUGE_VALL);
	default:		errno = EDOM;	return(HUGE_VALL); /* HUGE_VALL instead of NaN */
	}
}
