/* -*-C-*- pow.c */

/*
	computes a^b.
	uses log and exp
*/

#include "elefunt.h"

#if STDC
qp_t
pow(qp_t arg1, qp_t arg2)
#else /* NOT STDC */
qp_t
pow(arg1, arg2)
qp_t arg1,
    arg2;
#endif /* STDC */
{
    qp_t temp;
    long l;

    if (arg1 <= 0.0)
    {
	if (arg1 == 0.0)
	{
	    if (arg2 <= 0.0)
		goto domain;
	    return (0.0);
	}
	l = arg2;
	if (l != arg2)
	    goto domain;
	temp = expl(arg2 * logl(-arg1));
	if (l & 1)
	    temp = -temp;
	return (temp);
    }
    return (expl(arg2 * logl(arg1)));

domain:
    errno = EDOM;
    return (0.0);
}
