#include <math.h>

#if defined(__sun)
#include <sunmath.h>
#endif

extern double log1p (double x);

double
dlog1p(double x)
{
    return (log1p(x));
}

#define LOG10E		0.43429448190325182765112891891660508229439700580366e+00

/* Represent LOG10E as C7BY16 (exactly representable) + LOG10E_C7BY16 (small correction) */
#define C7BY16		0.4375e+00
#define LOG10E_C7BY16	-3.20551809674817234887108108339491770560299419633343388554621683414e-03

double
dl1p10(double x)
{
    double y;

    y = dlog1p(x);

#if 0
    return ((y * C7BY16) + (y * LOG10E_C7BY16));
#else
    return (y * LOG10E);
#endif

}
