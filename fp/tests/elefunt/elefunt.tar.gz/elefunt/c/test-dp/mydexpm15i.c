#include "mymath.h"

#define EXP(x)	(exp(x))

double
expm1(double x)
{
    /*
     * (expm1)
     * Return (exp(x) - 1), taking care to avoid subtraction loss.
     *
     * This version uses minimax rational polynomials computed by Maple,
     * e.g.,
     *
     *     with(numapprox):
     *     Digits := 20:
     *     minimax((exp(x)-1)/x, x = -0.5 .. -0.25, [3,4], 1, 'err');
     *     printf("%.2e\n", err):
     *
     * on 5 subintervals, chosen to have accuracy adequate for IEEE 754
     * and VAX 32-bit arithmetic.
     * (28-Jun-2002)
     */

    double ret_val;

    /*
     *
     * CUTLO = ln(0.5) (really, ln(1-1/beta) for arbitrary base beta)
     *
     */
    static const double CUTLO = -0.6931471805599453094172321214581765680755001343603;

    /*
     *
     * CUTHI = ln(1.5) (really, ln(1+1/beta) for arbitrary base beta)
     *
     */
    static const double CUTHI = 0.4054651081081643819780131154643491365719904234625;

    static const double ONE = 1.0;
    static const double ZERO = 0.0;

    /*
     *
     *     We handle the computation in three regions:
     *
     *     x in [-Infinity, -0.75): exp(x) - 1
     *     x in [-0.75, 0.50]:      minimax rational polynomials in 5 blocks
     *     x in (0.50, Infinity]:   exp(x) - 1
     *
     *     The central region suffers loss of one or more bits if the
     *     simple formula is used.
     *
     *     The following IF statements handle the case of NaN, signed zero,
     *     and the three regions above.
     *
     */

    if (x != x)				/* then x is a NaN */
	ret_val = x;
    else if (x == ZERO)			/* then x is +0 or -0 */
	ret_val = x;			/* preserve sign of zero */
    else if (x < CUTLO)
	ret_val = EXP(x) - ONE;
    else if (x < -0.50e+00) /* [-0.75,-0.50) Error = 9.803e-18 */
	ret_val = x * (
		       (0.7270714865303511841506443 +
			(-0.1437874896706767654611944e-1 +
			 (0.1753397279104422220917067e-1 -
			  0.2443068424020968040603144e-3 * x) * x) * x)/
		       (0.7270714871417784291186079 +
			(-0.3779144842243250741113991 +
			 (0.8531268356334744015060081e-1 +
			  (-0.1020937349543036617343177e-1 +
			   0.5737977118888511659922010e-3 * x) * x) * x) * x) );
    else if (x < -0.25e+00) /* [-0.50,-0.25) Error = 1.260e-17 */
	ret_val = x * (
		       (0.8267341890887513302664630 +
			(-0.9810644134524772363947486e-2 +
			 (0.1977502353601237585456958e-1 -
			  0.1646300741504487627041575e-3 * x) * x) * x)/
		       (0.8267341890986551152860481 +
			(-0.4231777384541288910664028 +
			 (0.9357486357313039451230188e-1 +
			  (-0.1086968318449647411531185e-1 +
			   0.5820343382724776914808861e-3 * x) * x) * x) * x) );
    else if (x < 0.0e+00) /* [-0.25,-0.0) Error = 1.618e-17 */
	ret_val = x * (
		       (0.9384292274697662411377895 +
			(-0.3694737068103811360949703e-2 +
			 (0.2235417709781174515831376e-1 -
			  0.6161602487968699799555098e-4 * x) * x) * x)/
		       (0.9384292274697662563194148 +
			(-0.4729093508029789286869177 +
			 (0.1024039812550319575325402 +
			  (-0.1154659930704505646928994e-1 +
			   0.5902825344533886777277899e-3 * x) * x) * x) * x) );
    else if (x < 0.25e+00) /* [0.0,0.25) Error = 2.077e-17 */
	ret_val = x * (
		       (1.063367267784660568276289 +
			(0.4252558535599912167225393e-2 +
			 (0.2533071873968516895047860e-1 +
			  0.7092034687485436259795215e-4 * x) * x) * x)/
		       (1.063367267784660590365104 +
			(-0.5274310753567413537913216 +
			 (0.1118183784548419811485111 +
			  (-0.1224005917333723764271851e-1 +
			   0.5985345105621870365010141e-3 * x) * x) * x) * x) );
    else if (x < 0.50e+00) /* [0.25,0.50) Error = 2.666e-17 */
	ret_val = x * (
		       (1.202849217490482178673070 +
			(0.1434834723626745472294180e-1 +
			 (0.2877287916966200762991924e-1 +
			  0.2407937596206295223775439e-3 * x) * x) * x)/
		       (1.202849217505523524344182 +
			(-0.5870762618485206535997149 +
			 (0.1218361436665972844215946 +
			  (-0.1294996865584199605445696e-1 +
			   0.6067824561421203486911816e-3 * x) * x) * x) * x) );
    else
	ret_val = EXP(x) - ONE;

    return (ret_val);
}
