#include "mymath.h"

double
dexpm1(double x)
{
    return (expm1(x));
}
