#include "mymath.h"

double
dlog1p(double x)
{
    /*
     * (log1p)
     * Return dlog(1 + x), taking care to avoid subtraction loss.
     *
     * This version uses a [6,7]-degree rational minimax polynomial
     * computed in Maple by
     *
     *     with(numapprox):
     *     Digits := 50:
     *     minimax(log(1+x)/x, x = -0.5..0.5, [6,7], 1, 'err');
     *     printf("%0.2e\n", err);
     *
     * The reported absolute error is 1.53e-16, below the IEEE 754
     * machine epsilon of 2**(-52) = 2.22e-16. This is the lowest
     * degree, and thus optimal, minimax polynomial whose error is below
     * that limit.
     * (24-Jun-2002)
     */

    /* Initialized data */

    static double CUTLO = -0.5;	/* CUTLO = -1/beta, for arbitrary base beta */
    static double CUTHI = 0.5;	/* CUTHI = 1/beta, for arbitrary base beta */
    static double ONE = 1.0;
    static double ZERO = 0.0;

    /* System generated locals */
    double ret_val;

    /*
     *     We handle the computation in three regions:
     *
     *     x in [-Infinity, CUTLO):  log(1+x)
     *     x in [CUTLO, CUTHI]:      minimax rational polynomial
     *     x in (CUTHI, Infinity]:   log(1+x)
     *
     *     The central region suffers loss of ONE or more bits if the
     *     simple formula is used.
     *
     *     We also handle the cases of log1p(NaN) and log1p(0) specially,
     *     so as to preserve NaNs, and the sign of ZERO.
     */

    if (x != x)
	ret_val = x;
    else if (x == ZERO)
	ret_val = x;
    else if (x < CUTLO)
	ret_val = LOG(ONE + x);
    else if (x <= CUTHI)
    {					/* Error = 1.53e-16 */
	ret_val = x * 
	    (
	     (0.59191287082336836213148725163038094120532003077663e+00 +
	      (1.8525928469565746496637786464514220934673132428372e+00 +
	       (2.2243024716646743184461712743074542256258031977682e+00 +
		(1.2770092305895025601997657819423992919675850915520e+00 +
		 (0.35409021136952430154728749845941591396573063595194e+00 +
		  (0.41506710883165824678607999661088304692680917047711e-1 +
		   0.13349894595234518937286437375837525816855394897071e-2 *
		   x) * x) * x) * x) * x) * x) /
	     (0.59191287082336842190677856754645813330381431123305e+00 +
	      (2.1485492823682572712593093134610412971573349210275e+00 +
	       (3.1012728225743201454493621002964834154368577536190e+00 +
		(2.2594407654598893534537064563519411307643560742201e+00 +
		 (0.86880773300378740595284526938423863790694708855636e+00 +
		  (0.16702414986890620279109493110849979893046417729021e+00 +
		   (0.13382679053371921414422305851053402241924541755786e-1 +
		    0.26270394985604291296168292547664155581505354531371e-3 *
		    x) * x) * x) * x) * x) * x) * x) );
    }
    else
	ret_val = LOG(ONE + x);

    return (ret_val);
}


double
dl1p10(double x)
{
    /* (log1p10) */
    /* Return dlog10(1 + x), taking care to avoid subtraction loss. */
    /* (17-Jun-2002) */

    static double LOG10E = 0.43429448190325182765112891891660508229439700580366;

    return (dlog1p(x) * LOG10E);
}
