#include <stdlib.h>

extern void tdexpm1(void);

int
main(void)
{
    tdexpm1();
    return (EXIT_SUCCESS);
}
