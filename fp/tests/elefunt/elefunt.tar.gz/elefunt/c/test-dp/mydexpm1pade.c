#include "mymath.h"

#define EXP(x)	(exp(x))

double
expm1(double x)
{
    /*
     * (expm1)
     * Return (exp(x) - 1), taking care to avoid subtraction loss.
     *
     * This version uses a [2,10]-degree Pad� approximation computed in
     * Maple by
     *
     *     with(numapprox):
     *     Digits := 20:
     *     pade((exp('x') - 1)/'x', 'x' = 0, [2,10]);
     *
     * The computed relative error is 7.84e-18, below the IEEE 754
     * machine epsilon of 2**(-52) = 2.22e-16.  This is the lowest
     * degree, and thus optimal, Pad� approximation whose error is below
     * that limit.
     * (29-Jun-2002)
     */

    double ret_val;

    /*
     *
     * CUTLO = ln(0.5) (really, ln(1-1/beta) for arbitrary base beta)
     *
     */
    static const double CUTLO = -0.6931471805599453094172321214581765680755001343603;

    /*
     *
     * CUTHI = ln(1.5) (really, ln(1+1/beta) for arbitrary base beta)
     *
     */
    static const double CUTHI = 0.4054651081081643819780131154643491365719904234625;

    static const double ONE = 1.0;
    static const double ZERO = 0.0;

    /*
     *
     *     We handle the computation in three regions:
     *
     *     x in [-Infinity, CUTLO):  exp(x) - 1
     *     x in [CUTLO, CUTHI]:      Pad� approximation
     *     x in (CUTHI, Infinity]:   exp(x) - 1
     *
     *     The central region suffers loss of one or more bits if the
     *     simple formula is used.
     *
     *     The following IF statements handle the case of NaN, signed zero,
     *     and the three regions above.
     *
     */

    if (x != x)				/* then x is a NaN */
	ret_val = x;
    else if (x == ZERO)			/* then x is +0 or -0 */
	ret_val = x;			/* preserve sign of zero */
    else if (x < CUTLO)
	ret_val = EXP(x) - ONE;
    else if (x <= CUTHI)		/* region of accuracy loss from exp(x)-1 */
	ret_val = x *
	    (
	     (-9.3965310353200729329617197454858765e-01 +
	      ( 4.790113120356638942401341058467e-07 +
		(-2.378341854819067690906237454356683e-02
		 ) * x) * x)
	     /
	     (-9.396531035320072932961719954056874e-01 +
	      ( 4.6982703077731568231197807103480641e-01 +
		(-1.0208808334818063584912661626995755e-01 +
		 ( 1.1891749191704674756865350265684362e-02 +
		   (-6.768777907769907831654798944041775e-04 +
		    (-6.6529348978053854734191511681874141e-10 +
		     ( 1.9593411207583912138726386005488577e-06 +
		       ( 1.5840251875165278058658960246497444e-11 +
			 (-9.6590929931077714088354599587181712e-09 +
			  (-3.97731786797138105962752989302728e-13 +
			   ( 4.5303052500322555269993618146754378e-11
			     ) * x) * x) * x) * x) * x) * x) * x) * x) * x) * x) );
    else
	ret_val = EXP(x) - ONE;

    return (ret_val);
}
