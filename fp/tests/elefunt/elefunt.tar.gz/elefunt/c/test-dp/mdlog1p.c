#include <stdlib.h>

extern void tdlog1p(void);

int
main(void)
{
    tdlog1p();
    return (EXIT_SUCCESS);
}
