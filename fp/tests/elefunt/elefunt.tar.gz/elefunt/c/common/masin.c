/* -*-C-*- masin.c */

#include "elefunt.h"

int
main()
{
    tasin();
    return (EXIT_SUCCESS);
}
