#! /bin/sh
### ====================================================================
### Run the ELEFUNT tests for multiple compilers and optimization
### levels, automatically selecting them according to the host
### operating system.
###
### Usage:
###	./elefunt.sh
###
### [27-May-2002]
### ====================================================================

machine=`uname -m`
os=`uname -s`
MAKE='make distclean all'

case $os in
	AIX*)
		osmajor=`uname -v`
		osminor=`uname -r`
		$MAKE CC='xlC -+' NAME=ibm-aix${osmajor}${osminor}-xlC-O3 OPT=-O3
		$MAKE CC='xlC -+' NAME=ibm-aix${osmajor}${osminor}-xlC-g OPT=-g
		$MAKE CC=c89 NAME=ibm-aix${osmajor}${osminor}-c89-O3 OPT=-O3
		$MAKE CC=c89 NAME=ibm-aix${osmajor}${osminor}-c89-g OPT=-g
		$MAKE CC=g++ NAME=ibm-aix${osmajor}${osminor}-g++-O4 OPT=-O4
		$MAKE CC=g++ NAME=ibm-aix${osmajor}${osminor}-g++-g OPT=-g
		;;

	Darwin*)
		$MAKE CC=g++ NAME=apple-powerpc-darwin-gnu-linux-g++-O4 OPT=-O4
		$MAKE CC=g++ NAME=apple-powerpc-darwin-gnu-linux-g++-g OPT=-g
		;;

	FreeBSD*)
		$MAKE CC=CC NAME=intel-ia32-freebsd-CC-O3 OPT=-O3
		$MAKE CC=CC NAME=intel-ia32-freebsd-CC-g OPT=-g
		$MAKE CC=c89 NAME=intel-ia32-freebsd-c89-O3 OPT=-O3
		$MAKE CC=c89 NAME=intel-ia32-freebsd-c89-g OPT=-g
		$MAKE CC=g++ NAME=intel-ia32-freebsd-g++-O4 OPT=-O4
		$MAKE CC=g++ NAME=intel-ia32-freebsd-g++-g OPT=-g
		;;

	HP-UX*)
		;;

	IRIX*)
		$MAKE CC=CC NAME=sgi-irix-CC-O3 OPT=-O3
		$MAKE CC=CC NAME=sgi-irix-CC-g OPT=-g
		$MAKE CC=g++ NAME=sgi-irix-g++-O4 OPT=-O4
		$MAKE CC=g++ NAME=sgi-irix-g++-g OPT=-g
		;;

	Linux*)
		case $machine in
			alpha)
				$MAKE CC=g++ NAME=dec-alpha-gnu-linux-g++-O3 OPT=-O3 XCFLAGS=-mieee
				$MAKE CC=g++ NAME=dec-alpha-gnu-linux-g++-g OPT=-g XCFLAGS=-mieee
				;;
			i486 | i586 | i686)
				$MAKE CC=g++ NAME=intel-ia32-gnu-linux-g++-O3 OPT=-O3
				$MAKE CC=g++ NAME=intel-ia32-gnu-linux-g++-g OPT=-g
				## Temporarily suppress pgCC: compiler broken after O/S upgrade
				## $MAKE CC=pgCC NAME=intel-ia32-gnu-linux-pgCC-O3 OPT=-O3
				## $MAKE CC=pgCC NAME=intel-ia32-gnu-linux-pgCC-g OPT=-g
				;;
			ppc)
				$MAKE CC=g++ NAME=apple-powerpc-gnu-linux-g++-O3 OPT=-O3
				$MAKE CC=g++ NAME=apple-powerpc-gnu-linux-g++-g OPT=-g
				;;
			sparc)
				$MAKE CC=g++ NAME=sun-sparc-gnu-linux-g++-O3 OPT=-O3
				$MAKE CC=g++ NAME=sun-sparc-gnu-linux-g++-g OPT=-g
				;;
			*)
				echo "Unknown machine = $machine"
				exit 1
				;;
		esac
		;;

	OSF1*)
		osversion=`uname -r`
		$MAKE CC='cxx -x cxx' NAME=dec-alpha-osf-${osversion}-cxx-O3 OPT=-O3 XCFLAGS=-ieee
		$MAKE CC='cxx -x cxx' NAME=dec-alpha-osf-${osversion}-cxx-g OPT=-g XCFLAGS=-ieee
		$MAKE CC=c89 NAME=dec-alpha-osf-${osversion}-c89-O3 OPT=-O3 XCFLAGS=-ieee
		$MAKE CC=c89 NAME=dec-alpha-osf-${osversion}-c89-g OPT=-g XCFLAGS=-ieee
		$MAKE CC=g++ NAME=dec-alpha-osf-${osversion}-g++-O3 OPT=-O3 XCFLAGS=-mieee
		$MAKE CC=g++ NAME=dec-alpha-osf-${osversion}-g++-g OPT=-g XCFLAGS=-mieee
		;;

	Rhapsody*)
		$MAKE CC=g++ NAME=apple-powerpc-rhapsody-gnu-linux-g++-O4 OPT=-O4
		$MAKE CC=g++ NAME=apple-powerpc-rhapsody-gnu-linux-g++-g OPT=-g
		;;

	SunOS*)
		osversion=`uname -r`
		sunmath=`find /opt/SUNWspro/ -name sunmath.h | head -1`
		incdir=`dirname ${sunmath}`
		libdir=${incdir}/../../lib
		$MAKE CC=CC NAME=sun-sparc-solaris-${osversion}-CC-O5 OPT=-O5 XLIBS="-lsunmath"
		$MAKE CC=CC NAME=sun-sparc-solaris-${osversion}-CC-g OPT=-g XLIBS="-lsunmath"
		$MAKE CC=c89 NAME=sun-sparc-solaris-${osversion}-c89-O5 OPT=-xO5 XLIBS="-lsunmath"
		$MAKE CC=c89 NAME=sun-sparc-solaris-${osversion}-c89-g OPT=-g XLIBS="-lsunmath"
		$MAKE CC=cc NAME=sun-sparc-solaris-${osversion}-cc-O5 OPT=-xO5 XLIBS="-lsunmath"
		$MAKE CC=cc NAME=sun-sparc-solaris-${osversion}-cc-g OPT=-g XLIBS="-lsunmath"
		$MAKE CC=g++ NAME=sun-sparc-solaris-${osversion}-g++-O5 OPT=-O5 XINCLUDES=-I${incdir} XLIBS="-L${libdir} -lsunmath"
		$MAKE CC=g++ NAME=sun-sparc-solaris-${osversion}-g++-g OPT=-g XINCLUDES=-I${incdir} XLIBS="-L${libdir} -lsunmath"
		;;

	*)
		echo "Unknown O/S = $os"
		exit 1
		;;

esac
echo ""
echo "Output files:"
ls -l tall[dsq]p.lst*
echo ""
for f in tall[dsq]p.lst*
do
	echo ==================== $f
	awk -f ../common/elefunt.awk $f
done
