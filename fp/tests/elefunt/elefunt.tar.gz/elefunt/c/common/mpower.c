/* -*-C-*- mpower.c */

#include "elefunt.h"

int
main()
{
    tpower();
    return (EXIT_SUCCESS);
}
