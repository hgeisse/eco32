/* -*-C-*- mtan.c */

#include "elefunt.h"

int
main()
{
    ttan();
    return (EXIT_SUCCESS);
}
