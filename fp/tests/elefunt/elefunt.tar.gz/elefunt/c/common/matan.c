/* -*-C-*- matan.c */

#include "elefunt.h"

int
main()
{
    tatan();
    return (EXIT_SUCCESS);
}
