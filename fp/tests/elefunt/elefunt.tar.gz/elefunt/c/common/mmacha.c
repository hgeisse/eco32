/* -*-C-*- mmacha.c */

#include "elefunt.h"

int
main(VOID_ARG)
{
    tmacha();
    return (EXIT_SUCCESS);
}
