/* -*-C-*- msinh.c */

#include "elefunt.h"

int
main()
{
    tsinh();
    return (EXIT_SUCCESS);
}
