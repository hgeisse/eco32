/* -*-C-*- talldp.c */

#include "elefunt.h"

int
main(VOID_ARG)
{
    tmacha ();
    talog ();
    tasin ();
    tatan ();
    texp ();
    tpower ();
    tsin ();
    tsinh ();
    tsqrt ();
    ttan ();
    ttanh ();
    return (EXIT_SUCCESS);
}
