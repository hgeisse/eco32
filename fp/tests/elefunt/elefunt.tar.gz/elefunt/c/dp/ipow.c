/* -*-C-*- ipow.c */

#include "elefunt.h"

#if STDC
dp_t
(ipow)(dp_t x, int n)
#else /* NOT STDC */
dp_t
(ipow)(x, n)
dp_t x;
int n;
#endif /* STDC */
{
    dp_t value;
    int k;

    value = 1.0;
    for (k = 1; k <= ABS(n); ++k)
	value *= x;
    if (n < 0)
	value = 1.0 / value;
    return (value);
}
