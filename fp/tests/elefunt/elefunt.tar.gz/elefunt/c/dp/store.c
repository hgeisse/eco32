/* -*-C-*- store.c */

#include "elefunt.h"

#if STDC
dp_t
(store)(dp_t* p)
#else /* NOT STDC */
dp_t
(store)(p)
dp_t* p;
#endif /* STDC */
{
    /* NO-OP -- want to force memory store of argument */
    /* Needed for IEEE arithmetic plus Intel, Honeywell, Motorola */
    /* (floating point registers larger than memory word size) */
    return (*p);
}
