#include "mymath.h"

float
alog1p(float x)
{
    /*
     * (log1p)
     * Return alog(1 + x), taking care to avoid subtraction loss.
     *
     * This version uses an algorithm developed for the HP-15C
     * calculator, mentioned in the log1p implementation in Sun's
     * Freely-Distributable Math Library, FDLIBM:
     *
     *  >> Note: Assuming log() return [sic] accurate answer, the
     *  >>       following algorithm can be used to compute log1p(x)
     *  >>       to within a few ULP:
     *  >>
     *  >>                u = 1+x;
     *  >>                if(u==1.0F) return x ; else
     *  >>                           return log(u)*(x/(u-1.0F));
     *  >>
     *  >>       See HP-15C Advanced Functions Handbook, p0.193F.0F
     *
     * (22-Jun-2002)
     */

    /* Initialized data */

    static float ONE = 1.0F;

    /* System generated locals */
    float ret_val;

    /* Local variables */
    float u;

    u = ONE + x;
    if (u == ONE)
	ret_val = x;
    else
	ret_val = LOG(u) * (x / (u - ONE));

    return (ret_val);
}


float
al1p10(float x)
{
    /* (log1p10) */
    /* Return alog10(1 + x), taking care to avoid subtraction loss. */
    /* (17-Jun-2002) */

    static float LOG10E = 0.43429448190325182765112891891660508229439700580366F;

    return (alog1p(x) * LOG10E);
}
