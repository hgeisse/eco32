#include <stdlib.h>

extern void texpm1(void);

int
main(void)
{
    texpm1();
    return (EXIT_SUCCESS);
}
