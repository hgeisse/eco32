#include <stdlib.h>

extern void talog1p(void);

int
main(void)
{
    talog1p();
    return (EXIT_SUCCESS);
}
