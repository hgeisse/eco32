#include "mymath.h"

#define EXP(x)	(expf(x))

float
expm1f(float x)
{
    /*
     * (expm1)
     * Return (exp(x) - 1), taking care to avoid subtraction loss.
     *
     * This version uses minimax rational polynomials computed by Maple,
     * e.g.,
     *
     *     with(numapprox):
     *     Digits := 20:
     *     minimax((exp(x)-1)/x, x = -0.5 .. -0.25, [1,2], 1, 'err');
     *     printf("%.2e\n", err):
     *
     * on 5 subintervals, chosen to have accuracy adequate for IEEE 754
     * and VAX 32-bit arithmetic.
     * (28-Jun-2002)
     */

    float ret_val;

    static const float ONE = 1.0F;
    static const float ZERO = 0.0F;

    /*
     * We handle the computation in three regions:
     *
     * x in [-Infinity, -0.75):  exp(x) - 1
     * x in [-0.75, 0.50):       minimax rational polynomials in 5 blocks
     * x in [0.50, Infinity]:    exp(x) - 1
     *
     * The central region suffers loss of one or more bits if the
     * simple formula is used.
     *
     * The following IF statements handle the case of NaN, signed zero,
     * and the three regions above.
     */

    if (x != x)			/* then x is a NaN */
	ret_val = x;
    else if (x == ZERO)		/* then x is +0 or -0 */
	ret_val = x;		/* preserve sign of zero */
    else if (x < -0.75F)
	ret_val = EXP(x) - ONE;
    else if (x < -0.50F)	/* [-0.75,-0.50) Error = 2.263e-08 */
	ret_val = x * ((0.72398429448554013817F -
			0.30630721706274652555e-1F * x) /
		       (0.72413139623665203158F +
			(-0.39165639644042519576F +
			 0.78013128754402437197e-1F * x) * x));
    else if (x < -0.25F)	/* [-0.50,-0.25) Error = 2.911e-08 */
	ret_val = x * ((0.82562418824542054841F -
			0.20664899132331724367e-1F * x) /
		       (0.82564402707873235008F +
			(-0.43325113721993670596F +
			 0.80079470913963015987e-1F * x) * x));
    else if (x < 0.0F)		/* [-0.25,-0.0) Error = 3.740e-08 */
	ret_val = x * ((0.93845866710096830732F -
			0.77019300962535958606e-2F * x) /
		       (0.93845870220378715115F +
			(-0.47692651942711079084F +
			 0.82153935693823999558e-1F * x) * x));
    else if (x < 0.25F)		/* [0.0,0.25) Error = 4.803e-08 */
	ret_val = x * ((1.0633610712663070587F +
			0.90044313563210714744e-2F * x) /
		       (1.0633611223371643824F +
			(-0.52268229164307795069F +
			 0.84231002377402090362e-1F * x) * x));
    else if (x < 0.50F)		/* [0.25,0.50) Error = 6.161e-08 */
	ret_val = x * ((1.2010991039052164176F +
			0.30381836994345986972e-1F * x) /
		       (1.2011292322093891862F +
			(-0.57050706011328737770F +
			 0.86305113822946226054e-1F * x) * x));
    else
	ret_val = EXP(x) - ONE;

    return (ret_val);
}
