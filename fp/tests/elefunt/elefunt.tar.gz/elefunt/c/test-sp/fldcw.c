/***********************************************************************
[06-Jul-2002]
***********************************************************************/

#if defined(__i386__) && defined(__linux__)
#include <fpu_control.h>
#endif

#include <stdio.h>
#include <stdlib.h>

#if defined(__STDC__) || defined(__cplusplus)
#define ARGS(parenthesized_list) parenthesized_list
#else
#define ARGS(parenthesized_list) ()
#endif

#ifndef EXIT_SUCCESS
#define EXIT_SUCCESS 0
#endif

int	main ARGS((int argc, char* argv[]));

int
main(int argc, char* argv[])
{
    short cw;
    cw = 0xffff;
    _FPU_GETCW(cw);
    (void)printf("cw = 0x%04hx\n", cw);
    return (EXIT_SUCCESS);
}
