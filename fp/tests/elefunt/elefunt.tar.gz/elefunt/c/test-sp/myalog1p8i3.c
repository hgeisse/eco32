#include "mymath.h"

float
alog1p(float x)
{
    /*
     * (log1p)
     * Return alog(1 + x), taking care to avoid subtraction loss.
     *
     * This version uses minimax rational polynomials computed by Maple,
     * e.g.,
     *
     *     with(numapprox):
     *     Digits := 35:
     *     minimax((log(1+x) - x + x^2/2)/x^3,
     *             x = -0.5 .. -0.375, [2,2], 1, 'err');
     *     printf("%0.2e\n", err):
     *
     * on 8 subintervals, chosen to have accuracy adequate for IEEE 754
     * and VAX 32-bit arithmetic.
     * (25-Jun-2002)
     */

    /* Initialized data */

    static float ONE = 1.0F;
    static float ZERO = 0.0F;

    /* System generated locals */
    float ret_val;

    /*
     * We handle the computation in three regions:
     *
     * x in [-Infinity, -0.5):  log(1+x)
     * x in [-0.5, 0.5]:        minimax rational polynomials in 8 blocks
     * x in (0.5, Infinity]:    log(1+x)
     *
     * The central region suffers loss of ONE or more bits if the
     * simple formula is used.
     *
     * We also handle the cases of log1p(NaN) and log1p(0) specially,
     * so as to preserve NaNs, and the sign of ZERO.
     */

    if (x != x)
	ret_val = x;
    else if (x == ZERO)
	ret_val = x;
    else if (x < -0.5F)
	ret_val = LOG(ONE + x);
    else if (x <= -0.375F)
    {				/* Error = 6.05e-10 */
          ret_val =  x - 0.5e+00F * x * x + (x * x * x *
	      (
	       (  7.68347536e-01F +
		  (  6.13870275e-01F +
		     (  1.24874124e-02F
			) * x) * x)
	       /
	       (  2.30489245e+00F +
		  (  3.56887723e+00F +
		     (  1.32650068e+00F
			) * x) * x) ) );
    }
    else if (x <= -0.25F)
    {				/* Error = 1.76e-10 */
          ret_val =  x - 0.5e+00F * x * x + (x * x * x *
	      (
	       (  5.72025244e-01F +
		  (  4.33490959e-01F +
		     (  6.15881244e-03F
			) * x) * x)
	       /
	       (  1.71606366e+00F +
		  (  2.58734997e+00F +
		     (  9.28458855e-01F
			) * x) * x) ) );
    }
    else if (x <= -0.125F)
    {				/* Error = 6.26e-11 */
          ret_val =  x - 0.5e+00F * x * x + (x * x * x *
	      (
	       (  4.48745153e-01F +
		  (  3.24469606e-01F +
		     (  3.38820663e-03F
			) * x) * x)
	       /
	       (  1.34623503e+00F +
		  (  1.98307385e+00F +
		     (  6.89618750e-01F
			) * x) * x) ) );
    }
    else if (x <= 0.0F)
    {				/* Error = 2.56e-11 */
          ret_val =  x - 0.5e+00F * x * x + (x * x * x *
	      (
	       (  3.65225142e-01F +
		  (  2.53047526e-01F +
		     (  2.01694814e-03F
			) * x) * x)
	       /
	       (  1.09567542e+00F +
		  (  1.58089912e+00F +
		     (  5.34318110e-01F
			) * x) * x) ) );
    }
    else if (x <= 0.125F)
    {				/* Error = 1.16e-11 */
          ret_val =  x - 0.5e+00F * x * x + (x * x * x *
	      (
	       (  3.05462850e-01F +
		  (  2.03477922e-01F +
		     (  1.27461719e-03F
			) * x) * x)
	       /
	       (  9.16388551e-01F +
		  (  1.29772517e+00F +
		     (  4.27285548e-01F
			) * x) * x) ) );
    }
    else if (x <= 0.25F)
    {				/* Error = 5.74e-12 */
          ret_val =  x - 0.5e+00F * x * x + (x * x * x *
	      (
	       (  2.60898041e-01F +
		  (  1.67545983e-01F +
		     (  8.44225312e-04F
			) * x) * x)
	       /
	       (  7.82694202e-01F +
		  (  1.08965620e+00F +
		     (  3.50188060e-01F
			) * x) * x) ) );
    }
    else if (x <= 0.375F)
    {				/* Error = 3.03e-12 */
          ret_val =  x - 0.5e+00F * x * x + (x * x * x *
	      (
	       (  2.26575319e-01F +
		  (  1.40599008e-01F +
		     (  5.80770352e-04F
			) * x) * x)
	       /
	       (  6.79726685e-01F +
		  (  9.31578715e-01F +
		     (  2.92692995e-01F
			) * x) * x) ) );
    }
    else if (x <= 0.5F)
    {				/* Error = 1.69e-12 */
          ret_val =  x - 0.5e+00F * x * x + (x * x * x *
	      (
	       (  1.99445677e-01F +
		  (  1.19830005e-01F +
		     (  4.12231312e-04F
			) * x) * x)
	       /
	       (  5.98339725e-01F +
		  (  8.08208504e-01F +
		     (  2.48599554e-01F
			) * x) * x) ) );
    }
    else
	ret_val = LOG(ONE + x);

    return (ret_val);
}


float
al1p10(float x)
{
    /* (log1p10) */
    /* Return alog10(1 + x), taking care to avoid subtraction loss. */
    /* (17-Jun-2002) */

    static float LOG10E = 0.43429448190325182765112891891660508229439700580366F;

    return (alog1p(x) * LOG10E);
}
