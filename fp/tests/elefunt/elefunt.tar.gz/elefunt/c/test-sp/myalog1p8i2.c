#include "mymath.h"

float
alog1p(float x)
{
    /*
     * (log1p)
     * Return alog(1 + x), taking care to avoid subtraction loss.
     *
     * This version uses minimax rational polynomials computed by Maple,
     * e.g.,
     *
     *     with(numapprox):
     *     Digits := 35:
     *     minimax((ln(1+x)-x)/x^2, x = -0.5 .. -0.375, [2,2], 1, 'err');
     *     printf("%0.2e\n", err):
     *
     * on 8 subintervals, chosen to have accuracy adequate for IEEE 754
     * and VAX 32-bit arithmetic.
     * (25-Jun-2002)
     */

    /* Initialized data */

    static float ONE = 1.0F;
    static float ZERO = 0.0F;

    /* System generated locals */
    float ret_val;

    /*
     * We handle the computation in three regions:
     *
     * x in [-Infinity, -0.5):  log(1+x)
     * x in [-0.5, 0.5]:        minimax rational polynomials in 8 blocks
     * x in (0.5, Infinity]:    log(1+x)
     *
     * The central region suffers loss of ONE or more bits if the
     * simple formula is used.
     *
     * We also handle the cases of log1p(NaN) and log1p(0) specially,
     * so as to preserve NaNs, and the sign of ZERO.
     */

    if (x != x)
	ret_val = x;
    else if (x == ZERO)
	ret_val = x;
    else if (x < -0.5F)
	ret_val = LOG(ONE + x);
    else if (x <= -0.375F)
    {				/* Error = 1.12e-09 */
          ret_val = x + (x * x *
	      (
	       ( -1.10319634e+00F +
		 ( -8.94165943e-01F +
		   ( -3.48931302e-02F
		     ) * x) * x)
	       /
	       (  2.20619640e+00F +
		  (  3.25727364e+00F +
		     (  1.13188626e+00F
			) * x) * x) ) );
    }
    else if (x <= -0.25F)
    {				/* Error = 3.47e-10 */
          ret_val = x + (x * x *
	      (
	       ( -8.32017042e-01F +
		 ( -6.33426416e-01F +
		   ( -1.85316714e-02F
		     ) * x) * x)
	       /
	       (  1.66401760e+00F +
		  (  2.37596297e+00F +
		     (  7.87785527e-01F
			) * x) * x) ) );
    }
    else if (x <= -0.125F)
    {				/* Error = 1.30e-10 */
          ret_val = x + (x * x *
	      (
	       ( -6.61029376e-01F +
		 ( -4.75789993e-01F +
		   ( -1.08806554e-02F
		     ) * x) * x)
	       /
	       (  1.32205814e+00F +
		  (  1.83293608e+00F +
		     (  5.82531387e-01F
			) * x) * x) ) );
    }
    else if (x <= 0.0F)
    {				/* Error = 5.59e-11 */
          ret_val = x + (x * x *
	      (
	       ( -5.44649263e-01F +
		 ( -3.72368610e-01F +
		   ( -6.86612228e-03F
		     ) * x) * x)
	       /
	       (  1.08929852e+00F +
		  (  1.47093619e+00F +
		     (  4.49704447e-01F
			) * x) * x) ) );
    }
    else if (x <= 0.125F)
    {				/* Error = 2.66e-11 */
          ret_val = x + (x * x *
	      (
	       ( -4.60965125e-01F +
		 ( -3.00442156e-01F +
		   ( -4.57525128e-03F
		     ) * x) * x)
	       /
	       (  9.21930250e-01F +
		  (  1.21550446e+00F +
		     (  3.58523131e-01F
			) * x) * x) ) );
    }
    else if (x <= 0.25F)
    {				/* Error = 1.37e-11 */
          ret_val = x + (x * x *
	      (
	       ( -3.98247626e-01F +
		 ( -2.48181185e-01F +
		   ( -3.18151103e-03F
		     ) * x) * x)
	       /
	       (  7.96495375e-01F +
		  (  1.02735556e+00F +
		     (  2.93064970e-01F
			) * x) * x) ) );
    }
    else if (x <= 0.375F)
    {				/* Error = 7.53e-12 */
          ret_val = x + (x * x *
	      (
	       ( -3.49698421e-01F +
		 ( -2.08891064e-01F +
		   ( -2.28959247e-03F
		     ) * x) * x)
	       /
	       (  6.99398007e-01F +
		  (  8.84026296e-01F +
		     (  2.44392417e-01F
			) * x) * x) ) );
    }
    else if (x <= 0.5F)
    {				/* Error = 4.36e-12 */
          ret_val = x + (x * x *
	      (
	       ( -3.11127985e-01F +
		 ( -1.78532909e-01F +
		   ( -1.69493026e-03F
		     ) * x) * x)
	       /
	       (  6.22260383e-01F +
		  (  7.71847181e-01F +
		     (  2.07160762e-01F
			) * x) * x) ) );
    }
    else
	ret_val = LOG(ONE + x);

    return (ret_val);
}


float
al1p10(float x)
{
    /* (log1p10) */
    /* Return alog10(1 + x), taking care to avoid subtraction loss. */
    /* (17-Jun-2002) */

    static float LOG10E = 0.43429448190325182765112891891660508229439700580366F;

    return (alog1p(x) * LOG10E);
}
