/* -*-C-*- randl.c */

#include "elefunt.h"

/***********************************************************************

Returns pseudo  random numbers  logarithmically distributed  over
(1,exp(x)).  Thus a*randl(ln(b/a)) is logarithmically distributed
in (a,b).

Other subroutines required:

	exp(x) - The exponential routine.

	ran(k) - A function program returning random real
		numbers uniformly distributed over (0,1).  The
		argument k is a dummy.

***********************************************************************/

#if STDC
sp_t
(srandl)(sp_t x)
#else /* NOT STDC */
sp_t
(srandl)(x)
sp_t x;
#endif /* STDC */
{
    return (EXP(x * RAN()));
}
