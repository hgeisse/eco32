/* -*-C-*- ipowl.c */

#include "elefunt.h"

#if STDC
sp_t
(ipowf)(sp_t x, int n)
#else /* NOT STDC */
sp_t
(ipowf)(x, n)
sp_t x;
int n;
#endif /* STDC */
{
    sp_t value;
    int k;

    value = 1.0F;
    for (k = 1; k <= ABS(n); ++k)
	value *= x;
    if (n < 0)
	value = 1.0F / value;
    return (value);
}
