extern double expm1(double);

double
dexpm1c_(double *x)
{
    return (expm1(*x));
}

double
dexpm1c(double *x)			/* alternate underscore-less interface */
{
    return (expm1(*x));
}
