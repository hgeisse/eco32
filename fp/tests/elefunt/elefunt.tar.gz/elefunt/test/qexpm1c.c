extern long double expm1l(long double);

long double
qexpm1c_(long double *x)
{
    return (expm1l(*x));
}

long double
qexpm1c(long double *x)			/* alternate underscore-less interface */
{
    return (expm1l(*x));
}
