/***********************************************************************
[03-Jul-2002]
***********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#if defined(__STDC__) || defined(__cplusplus)
#define ARGS(parenthesized_list) parenthesized_list
#else
#define ARGS(parenthesized_list) ()
#endif

#ifndef EXIT_SUCCESS
#define EXIT_SUCCESS 0
#endif

int	main ARGS((int argc, char* argv[]));

int
main(int argc, char* argv[])
{
    union {
	float x;
	unsigned int i;
    } u;
    union {
	float y;
	unsigned int i;
    } v;
    int k;
    int n;

    k = 0;
    u.x = 1.0F;
    while (u.x > 0.0F)
    {
	v.y = frexpf(u.x, &n);
	(void)printf("2^%d = %.7e [0x%08x] = %.7e [0x%08x] * 2^%d\n",
		     k, (double)u.x, u.i, (double)v.y, v.i, n);
	u.x /= 2.0F;
	k--;
    }
    u.x = 0.0F;
    u.x /= u.x;
    v.y = frexpf(u.x, &n);
    (void)printf("frexpf(%g,&n) -> %g\tn = %d\n", (double)u.x, (double)v.y, n);

    u.x = 0.0F;
    u.x = 1.0/u.x;
    v.y = frexpf(u.x, &n);
    (void)printf("frexpf(%g,&n) -> %g\tn = %d\n", (double)u.x, (double)v.y, n);

    u.x = 0.0F;
    u.x = -1.0/u.x;
    v.y = frexpf(u.x, &n);
    (void)printf("frexpf(%g,&n) -> %g\tn = %d\n", (double)u.x, (double)v.y, n);

    u.x = 0.0F;
    v.y = frexpf(u.x, &n);
    (void)printf("frexpf(%g [0x%08x],&n) -> %g [0x%08x]\tn = %d\n",
		 (double)u.x, u.i, (double)v.y, v.i, n);

    u.x = 0.0F;
    u.x = -u.x;
    v.y = frexpf(u.x, &n);
    (void)printf("frexpf(%g [0x%08x],&n) -> %g [0x%08x]\tn = %d\n",
		 (double)u.x, u.i, (double)v.y, v.i, n);

    return (EXIT_SUCCESS);
}
