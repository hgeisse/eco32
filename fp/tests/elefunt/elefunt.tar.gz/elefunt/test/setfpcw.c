/*
 * (Set Intel IA-32 floating-point control word)
 * In the following descriptions, routine names that end in an
 * underscore correspond to calls from Fortran to the name without an
 * underscore.  Arguments to such routines are always pointers, since
 * Fortran uses call-by-reference for all arguments.
 * ---------------------------------------------------------------------
 * getrawfpcw() and getrawfpcw_()
 * Return the raw IA-32 floating-point control word as an integer.
 *
 * This description of the flag bits is borrowed, with some editing,
 * from /usr/include/fpu_control.h on GNU/Linux (Red Hat 7.2); for
 * more explanation of the flags, see the ``IA-32 Intel Architecture
 * Software Developer's Manual Volume 1: Basic Architecture'' (Order
 * Number 245470), p. 8-9 (sequential page 195), Intel Corporation,
 * 2001, available at
 *
 *	ftp://download.intel.com/design/Pentium4/manuals/24547004.pdf
 *	http://developer.intel.com/design/litcentr/index.htm
 *
 * The control word is a 16-bit field with these bit assignments:
 *
 *	    15-13    12  11-10  9-8     7-6     5    4    3    2    1    0
 *	| reserved | IC | RC  | PC | reserved | PM | UM | OM | ZM | DM | IM
 *
 *	IM: Invalid operation mask
 *	DM: Denormalized operand mask
 *	ZM: Zero-divide mask
 *	OM: Overflow mask
 *	UM: Underflow mask
 *	PM: Precision (inexact result) mask
 *
 *	Mask bit set to 1 means no interrupt.
 *
 *	PC: Precision control
 *	11 - round to extended precision
 *	10 - round to double precision
 *	00 - round to single precision
 *
 *	RC: Rounding control
 *	00 - rounding to nearest
 *	01 - rounding down (toward - infinity)
 *	10 - rounding up (toward + infinity)
 *	11 - rounding toward zero
 *
 *	IC: Infinity control
 *	That is for 8087 and 80287 only.
 *
 *	The hardware default is 0x037f (IC=0, RC=00, PC=11,
 *      PM=UM=OM=ZM=DM=IM=1).
 *
 * ---------------------------------------------------------------------
 * setfpcw(mode)
 * Set flags in the Intel IA-32 floating-point control word, according
 * to the mode argument, a two-character string.  Recognized values
 * are:
 *
 *	"80"	set precision control to round to extended (80-bit) precision
 *	"64"	set precision control to round to double (64-bit) precision
 *	"32"	set precision control to round to single (32-bit) precision
 *	"RN"	set rounding control to round to nearest even
 *	"RD"	set rounding control to round down (toward -infinity)
 *	"RU"	set rounding control to round up (toward +infinity)
 *	"RZ"	set rounding control to round toward zero
 *
 * Any other string leaves the floating-point control word unchanged,
 * without any indication of the erroneous argument.
 *
 * Only the first two characters of mode are examined, making it easy
 * to call this routine from Fortran, as well as from C and C++.
 * ---------------------------------------------------------------------
 * setrawfpcw(int mode)
 * Set the raw IA-32 floating-point control word from the mode argument.
 * ---------------------------------------------------------------------
 * setrawfpcw_(int *mode)
 * Set the raw IA-32 floating-point control word from the *mode argument.
 * ---------------------------------------------------------------------
 *
 * WARNING: Extreme caution should be used in changing these flags
 * from their defaults (equivalent to successive calls to setfpcw()
 * with arguments "80" and "RN").  Most code assumes these settings,
 * and some code will behave unpredictably (e.g., loops might not
 * terminate) if they are altered.
 *
 * (07-Jul-2002)
 */

#include <string.h>
#include <fpu_control.h>

#if defined(DEBUG)
#include <stdio.h>
#endif

#undef strncmp
#define strncmp(a,b,n) (((a[0] == b[0]) && (a[1] == b[1])) ? 0 : 1)

int
getrawfpcw(void)
{
    short old_fpcw;

    _FPU_GETCW(old_fpcw);

    return ((int)old_fpcw);
}


int
getrawfpcw_(void)			/* alternate interface for Fortran */
{
    return (getrawfpcw());
}


void
setfpcw(char *mode)
{
    short fpcw;
    short new_fpcw;

    _FPU_GETCW(fpcw);

    new_fpcw = fpcw;

    if (strncmp(mode,"80",2) == 0)
    {
	new_fpcw &= ~_FPU_EXTENDED;	/* clear PC bits */
	new_fpcw |= _FPU_EXTENDED;
    }
    else if (strncmp(mode,"64",2) == 0)
    {
	new_fpcw &= ~_FPU_EXTENDED;	/* clear PC bits */
	new_fpcw |= _FPU_DOUBLE;
    }
    else if (strncmp(mode,"32",2) == 0)
    {
	new_fpcw &= ~_FPU_EXTENDED;	/* clear PC bits */
	new_fpcw |= _FPU_SINGLE;
    }
    else if (strncmp(mode,"RN",2) == 0)
    {
	new_fpcw &= ~_FPU_RC_ZERO;	/* clear RC bits */
	new_fpcw |= _FPU_RC_NEAREST;
    }
    else if (strncmp(mode,"RD",2) == 0)
    {
	new_fpcw &= ~_FPU_RC_ZERO;	/* clear RC bits */
	new_fpcw |= _FPU_RC_DOWN;
    }
    else if (strncmp(mode,"RU",2) == 0)
    {
	new_fpcw &= ~_FPU_RC_ZERO;	/* clear RC bits */
	new_fpcw |= _FPU_RC_UP;
    }
    else if (strncmp(mode,"RZ",2) == 0)
    {
	new_fpcw &= ~_FPU_RC_ZERO;	/* clear RC bits */
	new_fpcw |= _FPU_RC_ZERO;
    }
    _FPU_SETCW(new_fpcw);
    _FPU_GETCW(new_fpcw);

#if defined(DEBUG)
    fprintf(stderr,"Old FPWC = 0x%04x\tNew FPWC = 0x%04x\n", fpcw, new_fpcw);
#endif

}


void
setfpcw_(char *mode)			/* alternate interface for Fortran */
{
    setfpcw(mode);
}


int
setrawfpcw(int fpcw)
{
    short new_fpcw;
    short old_fpcw;

    _FPU_GETCW(old_fpcw);

    new_fpcw = (short)fpcw;
    _FPU_SETCW(new_fpcw);

    return ((int)old_fpcw);
}


int
setrawfpcw_(int *fpcw)			/* alternate interface for Fortran */
{
    return (setrawfpcw(*fpcw));
}
