#! /bin/sh
### ====================================================================
### Convert an old-style Fortran carriage-control-in-column-1 file to
### an ASCII file for printing.
###
###	cvtprt.sh < infile > outfile
###	cvtprt.sh infile(s) > outfile
###
### [11-Jun-2002]
### ====================================================================

awk '
/^1/	{print ((NR == 1) ? "" : "\f") substr($0,2); next }
/^-/	{print "\n\n" substr($0,2); next }
/^0/	{print "\n" substr($0,2); next }
	{print substr($0,2); next }
' "$@"
