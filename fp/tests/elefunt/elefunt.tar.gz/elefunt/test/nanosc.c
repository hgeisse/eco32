#include <sys/time.h>

double
nanosc_(void)
{
    return ((double)gethrtime());
}

double
nanosc(void)			/* alternate underscore-less interface */
{
    return ((double)gethrtime());
}
