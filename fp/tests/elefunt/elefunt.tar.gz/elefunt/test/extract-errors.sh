#! /bin/sh
### ====================================================================
### Extract RMS and MRE errors from one or more t[adq]log1p*.lst ELEFUNT
### listings.
### [22-Jun-2002]
### ====================================================================

test $# -eq 0 && echo "Usage: $0 file(s)" && exit 1

for f in "$@"
do
	echo ==================== $f
	awk -f elefunt.awk -v MREMAX=-1 -v RMSMAX=-1 $f | \
		grep LOSS  | \
			awk '{print $NF " & " }' | \
				fmt -w 16 | \
					awk '{print $3, $4, $1, $2}'
done
