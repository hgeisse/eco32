extern float expm1f(float);

float
expm1c_(float *x)
{
#if 0
    double d;
    d = (double)(*x);
    return ((float)expm1(d));
#else
    return (expm1f(*x));
#endif
}

float
expm1c(float *x)			/* alternate underscore-less interface */
{
#if 0
    double d;
    d = (double)(*x);
    return ((float)expm1(d));
#else
    return (expm1f(*x));
#endif
}
