#! /bin/csh -f

set TIMOPS=timops
set TMP=tmp-

foreach f (${TIMOPS}*.sed)
	echo ==================== $f
	sed -f $f ${TIMOPS}.f > ${TMP}${TIMOPS}.f
	grep '^ *parameter'  ${TMP}${TIMOPS}.f

	make clean >/dev/null
	make ${TIMOPS} TMP=${TMP} FFLAGS=-xO5 CFLAGS=-xO5
	repeat 5 time ./${TIMOPS} >${TIMOPS}.tmp
	cat ${TIMOPS}.tmp
	awk -f timops.awk ${TIMOPS}.tmp
	
	make clean >/dev/null
	make ${TIMOPS} TMP=${TMP} FFLAGS=-xO5 CFLAGS=-xO5 P=my 
	repeat 5 time ./${TIMOPS} >${TIMOPS}.tmp
	cat ${TIMOPS}.tmp
	awk -f timops.awk ${TIMOPS}.tmp

	make clean >/dev/null
	make ${TIMOPS} TMP=${TMP} FFLAGS=-xO5 CFLAGS=-xO5 P=my S=r
	repeat 5 time ./${TIMOPS} >${TIMOPS}.tmp
	cat ${TIMOPS}.tmp
	awk -f timops.awk ${TIMOPS}.tmp

	make clean >/dev/null
	make ${TIMOPS} TMP=${TMP} FFLAGS=-xO5 CFLAGS=-xO5 P=my S=t
	repeat 5 time ./${TIMOPS} >${TIMOPS}.tmp
	cat ${TIMOPS}.tmp
	awk -f timops.awk ${TIMOPS}.tmp

	make clean >/dev/null
	make ${TIMOPS} TMP=${TMP} FFLAGS=-xO5 CFLAGS=-xO5 P=my S=rt
	repeat 5 time ./${TIMOPS} >${TIMOPS}.tmp
	cat ${TIMOPS}.tmp
	awk -f timops.awk ${TIMOPS}.tmp

	/bin/rm -f ${TMP}${TIMOPS}.f
end
