/***********************************************************************
[13-Jun-2002]
***********************************************************************/

#include <stdio.h>
#include <stdlib.h>

#if defined(__STDC__) || defined(__cplusplus)
#define ARGS(parenthesized_list) parenthesized_list
#else
#define ARGS(parenthesized_list) ()
#endif

#ifndef EXIT_SUCCESS
#define EXIT_SUCCESS 0
#endif

int	main ARGS((int argc, char* argv[]));

#if defined(__sgi)
#include <sys/fpu.h>

void
flush_to_zero(int on_off)
{
union fpc_csr  n;

     n.fc_word = get_fpc_csr();
     if ( on_off == 0 ) {
	  n.fc_struct.flush = 0;
     } else {
	  n.fc_struct.flush = 1;
     }
     set_fpc_csr(n.fc_word);
}
#endif


int
main(int argc, char* argv[])
{
    float x;

#if defined(__sgi)
    flush_to_zero(0);
#endif

    x = 1.0;
    while (x > 0.0)
    {
	(void)printf("%g\n", (double)x);
	x *= 0.5;
    }

    return (EXIT_SUCCESS);
}
